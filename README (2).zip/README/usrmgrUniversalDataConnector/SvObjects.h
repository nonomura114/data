#pragma once

#include <map>
#include <vector>
#include <iostream>
#include <fstream>
#include <deque>
#include <string>

extern IAPIMgr* svmgrAPI;
using namespace std;
const int MaxLen = 1024;

class _Group;

////////////////////////////////////////////////////////////////////////////////
// _Var: Base variable class 

class _Var
{
public:
    CString m_strName;

    _Var(LPCTSTR pszName);
    ~_Var();

    void Advise();
    void Unadvise();

    void virtual OnChange(_svmgrVarValue2* pVarValue, _svmgrVarStatus varStatus) {}
};

////////////////////////////////////////////////////////////////////////////////
// _VarAdvised: Variable to be advised and read

class _VarAdvised : _Var
{
public:
    CString m_strValue;
    CString m_strConnectCnxName;
    CString m_strColumnName;

    _VarAdvised(LPCTSTR pszName);
    ~_VarAdvised();

    void OnChange(_svmgrVarValue2* pVarValue, _svmgrVarStatus varStatus);
};

////////////////////////////////////////////////////////////////////////////////
// _VarTrigger: Variables that trig Group

class _VarTrigger : _Var
{
public:
    CString m_strName;
    _Group* m_pGroup;

    _VarTrigger(LPCTSTR pszName, _Group* pGroup);
    ~_VarTrigger();

    void OnChange(_svmgrVarValue2* pVarValue, _svmgrVarStatus varStatus);
};

////////////////////////////////////////////////////////////////////////////////
// _Group

class _Group
{
private:
    bool            m_bUseUTC = false;
    CString         m_strName;
    _VarTrigger*    m_pVarTriggerRead = NULL;
    _VarTrigger*    m_pVarTriggerWrite = NULL;
    int             m_iTimerPeriodSec;
    CString         m_strDbConnectCnx;
    CString         m_strTableName;
    CString         m_strReadTriggerVarName;
    CString         m_strWriteTriggerVarName;
    CString         m_strCSVFileName;
    CString         m_strCommandW1;
    CString         m_strCommandW2;

public:
    std::map<_VarAdvised*, CString> mapVariables;   // Mapping table: Key=Variable / Value=Column

    _Group(LPCTSTR pszName, LPCTSTR pszCnx, LPCTSTR pszTableName, LPCTSTR pszReadTriggerVarName, LPCTSTR pszWriteTriggerVarName, int iPeriod, int iUseUtc, LPCTSTR pszCSVFileName, LPCTSTR pszCommandW1, LPCTSTR pszCommandW2);
    ~_Group();

    void Init();
    void PrepareTables();
    void StartAcquisition();
    ULONG GetTimerPeriod();
    void AddVariable(CString strVarName, CString strColumnName);
    void OnTriggerVariable(_VarTrigger* pVarTrigger);
    void OnTimer();
    void OnSqlCmdExecuteNonQueryCompleted(BOOL bResult, LPCTSTR pszErrorMsg, _svmgrSqlCmdExecuteNonQueryResult* pResult);
    void OnSqlCmdExecuteDataReaderCompleted(BOOL bResult, LPCTSTR pszErrorMsg, _svmgrSqlCmdExecuteDataReaderResult* pResult);

private :
    void DbWrite();
    void DbRead();
    void DbUpdate();
    void CSVWrite();
};

////////////////////////////////////////////////////////////////////////////////
// _Tools: Some tools and useful functions

class _Tools
{
public:
    static CString StringFromVariant(const VARIANT& vr);
    static std::vector<CString> Split(const CString& str, LPCTSTR pszDelimiter);
};

////////////////////////////////////////////////////////////////////////////////
// _Tools: CSV file read function
class MyCSV_a {
private:
    deque<deque<string>> csvfile;
    char comma; //��؂�ƂȂ�J���}�B
public:
    bool Load(string fname);
    string w(int y, int x);
    int i(int y, int x);
    int size_y();
    int size_x(int y);
    void SetComma(char c) { comma = c; }
    MyCSV() { comma = L','; }
    MyCSV(string fname) { comma = ','; Load(fname); }
};
