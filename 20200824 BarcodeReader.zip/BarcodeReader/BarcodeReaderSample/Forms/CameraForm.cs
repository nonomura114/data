﻿using AForge.Video;
using AForge.Video.DirectShow;
using BarcodeReaderSample.Common;
using BarcodeReaderSample.Services;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BarcodeReaderSample.Forms
{
    public partial class CameraForm : Form
    {
        private System.Threading.SemaphoreSlim semaphore = new System.Threading.SemaphoreSlim(1, 1);
        private VideoCaptureDevice videoDevice;
        private BarcodeService barcodeService;
        private string lastDetectedBarcodeValue;
	private BarcodeDetectedResult lastdetectedBarcode;

        public CameraForm()
        {
            InitializeComponent();
            this.ShowIcon = false;
            barcodeService = new BarcodeService();
            pictureBox1.Image = FontIcon.CreateGlyphIcon(FontIcon.Glyphs.Camera, iconWidth: 50, iconHeight: 50, emSize: 28, fontColor: Color.Red).ToBitmap();
        }

        private void CameraForm_Load(object sender, EventArgs e)
        {
            StartCapture();
            this.lbReadBarcodeData.Text = "Please wait... Camera Starting";
        }

        private void StartCapture()
        {
            videoDevice = GetCaptureDevice();
            if (videoDevice != null)
            {
                CloseCurrentVideoSource();
                videoDevice.NewFrame += new NewFrameEventHandler(VideoDevice_FrameArrived);
                videoSourcePlayer1.VideoSource = videoDevice;
                videoSourcePlayer1.Start();
                this.lbReadBarcodeData.Text = "Scanning";
            }
        }

        private VideoCaptureDevice GetCaptureDevice()
        {
            VideoCaptureDevice videoCaptureDevice = null;

            if (!string.IsNullOrEmpty(SettingService.CameraDeviceName))
            {
                videoCaptureDevice = new VideoCaptureDevice(SettingService.CameraDeviceName);
            }

            if (videoCaptureDevice == null)
            {
                var videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                if (videoDevices.Count != 0)
                {
                    SettingService.CameraDeviceName = videoDevices[0].MonikerString;
                    videoCaptureDevice = new VideoCaptureDevice(SettingService.CameraDeviceName);
                }
            }

            return videoCaptureDevice;
        }

        private async void VideoDevice_FrameArrived(object sender, NewFrameEventArgs eventArgs)
        {
            if (SettingService.IsMirror)
                eventArgs.Frame.RotateFlip(RotateFlipType.RotateNoneFlipX);

            if (!await semaphore.WaitAsync(0))
                return;

            try
            {
                using (Bitmap bitmap = (Bitmap)eventArgs.Frame.Clone())
                {
                    var detectedBarcode = barcodeService.DetectBarcodeFromBitmap(bitmap); 
                    if (detectedBarcode != null)
                    {
                        if (lastDetectedBarcodeValue != detectedBarcode.BarcodeValue)
                        {
                            WriteTextSafe(detectedBarcode.BarcodeValue);
                            this.lbReadBarcodeData.Text = detectedBarcode.BarcodeValue.ToString();

                            if (SettingService.IsSaveToCSV)
                                ExportCSV(detectedBarcode);

                            if (SettingService.IsCopyToClipboard)
                                CopyToClipboard(detectedBarcode);

				            WriteToDatabase(lastdetectedBarcode,detectedBarcode);
				            lastdetectedBarcode = detectedBarcode;
				            lastDetectedBarcodeValue = detectedBarcode.BarcodeValue;

                        }
                    }
                }
            }
            finally
            {
                semaphore.Release();
            }
        }

        public delegate void SafeCallDelegate(string text);

        private void WriteTextSafe(string text)
        {
            if (label1.InvokeRequired)
            {
                var d = new SafeCallDelegate(WriteTextSafe);
                label1.Invoke(d, new object[] { text });
            }
            else
            {
                label1.Text = text;
            }
        }

        private void ExportCSV(BarcodeDetectedResult barcodeDetectedResult)
        {
            if (string.IsNullOrEmpty(SettingService.CSVExportPath))
                SettingService.CSVExportPath = AppDomain.CurrentDomain.BaseDirectory;

            var filePathName = Path.Combine(SettingService.CSVExportPath, string.Format("{0}.csv", DateTime.Now.ToString("yyyyMMdd")));
            using (StreamWriter w = File.AppendText(filePathName))
            {
                w.WriteLine($"{barcodeDetectedResult.DetectedDateTime.ToString("yyyyMMdd hh:mm:ss")},{barcodeDetectedResult.BarcodeValue}");
            }
        }

        private void CopyToClipboard(BarcodeDetectedResult barcodeDetectedResult)
        {
            //Clipboard.SetText(detectedBarcode.BarcodeValue);

            Thread thread = new Thread(() => Clipboard.SetText(barcodeDetectedResult.BarcodeValue));
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
        }
		
		private void WriteToDatabase(BarcodeDetectedResult lastbarcodeDetectedResult, BarcodeDetectedResult barcodeDetectedResult)
        {
            //Clipboard.SetText(detectedBarcode.BarcodeValue);
            string strDetectedVal = barcodeDetectedResult.BarcodeValue.ToString();
            string strlastDetectedVal = lastbarcodeDetectedResult.BarcodeValue.ToString();

            string strSQL = string.Format("UPDATE T01_SNJ SET KS0ZT03= %s , KS0ZT04= %s, KS0ZT05= %s, KS0ZT06= %s, KS0ZT07= %s, KS0ZT08= %s, KS0ZT09= %s, TDS0BT02= '%s', TDS0BT03= %s, TDS0BT04= %s, TDS0BT05= %s, TDS0BT06= %s, TDS0BT07= %s, TDS0BT08= %s WHERE KS0ZT02 IS NULL;", strDetectedVal.Substring(0,4), strDetectedVal.Substring(4), barcodeDetectedResult.DetectedDateTime.Year.ToString(), barcodeDetectedResult.DetectedDateTime.Month.ToString(), barcodeDetectedResult.DetectedDateTime.Day.ToString(), barcodeDetectedResult.DetectedDateTime.Hour.ToString(), barcodeDetectedResult.DetectedDateTime.Minute.ToString(), barcodeDetectedResult.DetectedDateTime.Second.ToString(), barcodeDetectedResult.BarcodeValue, barcodeDetectedResult.DetectedDateTime.Year.ToString(), barcodeDetectedResult.DetectedDateTime.Month.ToString(), barcodeDetectedResult.DetectedDateTime.Day.ToString(), barcodeDetectedResult.DetectedDateTime.Hour.ToString(), barcodeDetectedResult.DetectedDateTime.Minute.ToString(), barcodeDetectedResult.DetectedDateTime.Second.ToString());
            string strlastSQL1 = string.Format("UPDATE T01_2KS SET KS0ZT03= %s , KS0ZT04= %s, KS0ZT05= %s, KS0ZT06= %s, KS0ZT07= %s, KS0ZT08= %s, KS0ZT09= %s WHERE KS0ZT02 IS NULL;", strlastDetectedVal, lastbarcodeDetectedResult.DetectedDateTime.Year.ToString(), lastbarcodeDetectedResult.DetectedDateTime.Month.ToString(), lastbarcodeDetectedResult.DetectedDateTime.Day.ToString(), lastbarcodeDetectedResult.DetectedDateTime.Hour.ToString(), lastbarcodeDetectedResult.DetectedDateTime.Minute.ToString(), lastbarcodeDetectedResult.DetectedDateTime.Second.ToString());
            string strlastSQL2 = string.Format("UPDATE T01_TDS SET TDS0BT02= '%s', TDS0BT03= %s, TDS0BT04= %s, TDS0BT05= %s, TDS0BT06= %s, TDS0BT07= %s, TDS0BT08= %s WHERE TDS0BT02 IS NULL;", barcodeDetectedResult.BarcodeValue, barcodeDetectedResult.DetectedDateTime.Year.ToString(), barcodeDetectedResult.DetectedDateTime.Month.ToString(), barcodeDetectedResult.DetectedDateTime.Day.ToString(), barcodeDetectedResult.DetectedDateTime.Hour.ToString(), barcodeDetectedResult.DetectedDateTime.Minute.ToString(), barcodeDetectedResult.DetectedDateTime.Second.ToString());

            SqlConnection conn;
            SqlConnection lastconn1;
            SqlConnection lastconn2;
            SqlCommand comm;
            SqlCommand lastcomm1;
            SqlCommand lastcomm2;

            string connstring = "Data Source=(LOCAL);Initial Catalog=TEST_UD_DB;Integrated Security=True";
            conn = new SqlConnection(connstring);
            conn.Open();
            lastconn1 = new SqlConnection(connstring);
            lastconn1.Open();
            lastconn2 = new SqlConnection(connstring);
            lastconn2.Open();

            comm = new SqlCommand(strSQL, conn);
            lastcomm1 = new SqlCommand(strlastSQL1, lastconn1);
            lastcomm2 = new SqlCommand(strlastSQL2, lastconn2);

            try
            {
            if (barcodeDetectedResult != null)
            {
                if (strDetectedVal != null)
                {
                    comm.ExecuteNonQuery();
                }
            }                
                MessageBox.Show("Updated..");
            }
            catch (Exception)
            {
                MessageBox.Show(" Not Updated");
            }
            finally
            {
                conn.Close();
            }

            try
            {
            if (lastbarcodeDetectedResult != null)
            {
                if (strlastDetectedVal != null)
                {
                    lastcomm1.ExecuteNonQuery();
                }
            }
                MessageBox.Show("Updated..");
            }
            catch (Exception)
            {
                MessageBox.Show(" Not Updated");
            }
            finally
            {
                lastconn1.Close();
            }

            try
            {
                if (lastbarcodeDetectedResult != null)
                {
                    if (strlastDetectedVal != null)
                    {
                        lastcomm2.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Updated..");
            }
            catch (Exception)
            {
                MessageBox.Show(" Not Updated");
            }
            finally
            {
                lastconn2.Close();
            }

        }
		
		

        private void CameraForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            CloseCurrentVideoSource();
        }

        private void CloseCurrentVideoSource()
        {
            try
            {
                if (videoSourcePlayer1.VideoSource != null)
                {
                    videoSourcePlayer1.SignalToStop();
                    // wait ~ 3 seconds
                    for (int i = 0; i < 30; i++)
                    {
                        if (!videoSourcePlayer1.IsRunning)
                            break;
                        System.Threading.Thread.Sleep(100);
                    }
                    if (videoSourcePlayer1.IsRunning)
                    {
                        videoSourcePlayer1.Stop();
                    }
                    videoSourcePlayer1.VideoSource = null;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(string.Format("CloseCurrentVideoSource exception:{0}", ex.Message));
            };
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            StartCapture();
            pictureBox1.Visible = false;
            videoSourcePlayer1.Visible = true;
            label1.Visible = true;
        }

        private void videoSourcePlayer1_Click(object sender, EventArgs e)
        {
            CloseCurrentVideoSource();
            videoSourcePlayer1.Visible = false;
            label1.Visible = false;
            pictureBox1.Visible = true;
        }
    }
}
