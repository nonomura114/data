#include "stdafx.h"
#include "usrmgrUniversalDataConnectorImpl.h"
#include "svmgrDefaultImpl.h"
#include "SvObjects.h"
#include <vector>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

////////////////////////////////////////////////////////////////////////////////

#define NBMAX_GROUP 100

#define CONFIG_FILE     _T("usrmgrUniversalDataConnector.ini")
#define E_PARAM_SECTION _T("Parameters")
#define E_GROUP_SECTION _T("Group")

#define E_P_ATTR_NUM    _T("AttrNumber")
#define E_P_ATTR_KW     _T("AttrKeyword")
#define E_P_USE_UTC     _T("UseUTC")
#define E_P_CSV_FILENAME  _T("CSVFileName")

#define E_G_CONNECTION  _T("SqlConnection")
#define E_G_TABLE       _T("SqlTable")
#define E_G_WR_PERIOD   _T("Write_Period")
#define E_G_WR_TRIGGER  _T("Write_Trigger")
#define E_G_RD_TRIGGER  _T("Read_Trigger")
#define E_G_WR_COMMAND  _T("Write_Command")

////////////////////////////////////////////////////////////////////////////////
// Reads configuration file and loads objects

void LoadConfiguration()
{
    CString strIniFileName;
    CString strKeyWord;
    CString strGroupSection;
    CString strConnectionName;
    CString strTableName;
    CString strTriggerR;
    CString strTriggerW;
    CString strCSVFileName;

    int iAttNumber;
    int iUseUTC;
    int iPeriod;
    int iGroup = 0;

    TCHAR szProjectDirectory[MAX_PATH];
    TCHAR szKeyword[255 + 1];
    TCHAR szConnectionName[255 + 1];
    TCHAR szTableName[255 + 1];
    TCHAR szTriggerR[255 + 1];
    TCHAR szTriggerW[255 + 1];
    TCHAR szCommandW[255 + 1];

    std::map<CString, _Group*>::iterator itGroup;
    std::map<CString, _Group*> mapGroups;

    // 1) Read configuration file

    svmgrAPI->GetProjectDirectory(svmgrProjectDirectory_Cfg, szProjectDirectory, _countof(szProjectDirectory));
    strIniFileName.Format(_T("%s%s"), szProjectDirectory, CONFIG_FILE);

    iAttNumber = GetPrivateProfileInt(E_PARAM_SECTION, E_P_ATTR_NUM, 16, strIniFileName) - 3;
    GetPrivateProfileString(E_PARAM_SECTION, E_P_ATTR_KW, _T("DBCONNECT"), szKeyword, sizeof(szKeyword), strIniFileName);
    iUseUTC = GetPrivateProfileInt(E_PARAM_SECTION, E_P_USE_UTC, 0, strIniFileName);
    GetPrivateProfileString(E_PARAM_SECTION, E_P_CSV_FILENAME, _T(""), szKeyword, sizeof(szKeyword), strCSVFileName);

    strKeyWord = szKeyword;
    strKeyWord.MakeUpper();

    svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, _T("Read ini file %s"), strIniFileName);

    do
    {
        iGroup++;

        strGroupSection.Format(_T("%s%d"), E_GROUP_SECTION, iGroup);
        GetPrivateProfileString(strGroupSection, E_G_CONNECTION, _T(""), szConnectionName, sizeof(szConnectionName), strIniFileName);
        GetPrivateProfileString(strGroupSection, E_G_TABLE, strGroupSection, szTableName, sizeof(szTableName), strIniFileName);
        GetPrivateProfileString(strGroupSection, E_G_WR_TRIGGER, _T(""), szTriggerW, sizeof(szTriggerW), strIniFileName);
        GetPrivateProfileString(strGroupSection, E_G_RD_TRIGGER, _T(""), szTriggerR, sizeof(szTriggerR), strIniFileName);
        iPeriod = GetPrivateProfileInt(strGroupSection, E_G_WR_PERIOD, 0, strIniFileName);
 
        strTriggerR = szTriggerR;
        strTriggerW = szTriggerW;
        strTableName= szTableName;
        strConnectionName = szConnectionName;
        strGroupSection.MakeUpper();


        if (!svmgrAPI->VarIsExist(strTriggerR))
            strTriggerR.Empty();
        if (!svmgrAPI->VarIsExist(strTriggerW))
            strTriggerW.Empty();

        if (!strConnectionName.IsEmpty())
        {
            if (iPeriod > 0 || !strTriggerW.IsEmpty())
            {
                mapGroups[strGroupSection] = new _Group(strGroupSection, strConnectionName, strTableName, strTriggerR, strTriggerW, iPeriod, iUseUTC,strCSVFileName);

                CString strMessage;
                if (iPeriod > 0)
                    strMessage.Format(_T(" Period:%d"), iPeriod);
                if (!strTriggerW.IsEmpty())
                    strMessage.Format(_T("%s Trigger:%s"), strMessage, strTriggerW);

                svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, _T("[%s] Configuration loaded (sqlCnx:%s, sqlTable:%s,%s)"), strGroupSection, strConnectionName, strTableName, strMessage);
            }
            else
            {
                svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, _T("[%s] At least one field must be filled: %s or %s in file %s"), strGroupSection, E_G_WR_PERIOD, E_G_WR_TRIGGER, strIniFileName);
            }
        }
        else if (iPeriod == 0 && strTriggerW.IsEmpty())
        {
            iGroup = NBMAX_GROUP;
        }

    } while (iGroup < NBMAX_GROUP);

    // 2) Load variables

    HANDLE hEnum;
    BOOL bContinue = svmgrAPI->CreateVarEnum(hEnum);

    if (!bContinue)
        return;     // Error

    _svmgrVarEnum peVar[128];
    ULONG ulNbVar;
    LPCTSTR pszDelimiter = _T(":");

    do
    {
        // Parse all variables
        // Seached syntax = KeyWord:DbConnection:GroupName:ColumnName
        // Example = DBC:CnxAccess:Group1:Machine1.Humidity.Value
        bContinue = svmgrAPI->VarEnum(hEnum, 128, peVar, &ulNbVar);
        for (ULONG ulCount = 0; ulCount < ulNbVar; ulCount++)
        {
            _svmgrVarEnum varEnum = peVar[ulCount];

            CString strAttrib(varEnum.szAttrib[iAttNumber]);
            strAttrib.MakeUpper();

            int iPos = strAttrib.Find(pszDelimiter);

            // 1st search : begin with Keyword ("KeyWord:")
            if ((iPos > 0) && (strAttrib.Left(iPos) == strKeyWord))
            {
                std::vector<CString> vAttrFields = _Tools::Split(strAttrib, pszDelimiter);

                if (vAttrFields.size() < 3)
                {
                    svmgrAPI->LogMessage(SVMGR_LVL_WARNING, SVMGR_DEST_VIEWER, _T("Mapping failed : attribute %d (%s) bad configured [%s]"), iAttNumber, varEnum.szAttrib, varEnum.szName);
                }
                else
                {
                    CString strVarName(varEnum.szName);
                    CString strVarGroupName(vAttrFields[1]);
                    CString strVarColName(vAttrFields[2]);

                    itGroup = mapGroups.find(strVarGroupName);

                    if (itGroup != mapGroups.end())
                    {
                        _Group* pGroup = (*itGroup).second;
                        pGroup->AddVariable(strVarName, strVarColName);
                    }
                }
            }
        }

        svmgrAPI->ClearVarEnum(ulNbVar, peVar);

    } while (bContinue);

    svmgrAPI->CloseVarEnum(hEnum);

    // 3) Initialization phase => have to wait until DBConnect is initialized

    for (itGroup = mapGroups.begin(); itGroup != mapGroups.end(); itGroup++)
    {
        _Group* pGroup = (*itGroup).second;
        pGroup->Init();
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementation of the ISVMgr interface

struct IUsrMgr : public ISVMgr
{
    void __stdcall StartProject()
    {
        LoadConfiguration();
    }

    void __stdcall StopProject()
    {
        svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, _T("StopProject"));
    }

    // Fired when advised variables have changed
    BOOL __stdcall OnDataChange2(
        DWORD dwCount,
        ULONG* pulClientHandles,
        BOOL* pbResults,
        _svmgrVarValue2** pValues,
        _FILETIME* pftTimestamps,
        _svmgrVarStatus* pStatus)
    {
        for (DWORD i = 0; i < dwCount; i++)
        {
            _Var* pVar = (_Var*)pulClientHandles[i];
            _svmgrVarValue2* pValue = pValues[i];
            _svmgrVarStatus status = pStatus[i];

            // Launch OnChange methods... depending on the variable type
            pVar->OnChange(pValue, status);
        }
        return TRUE;
    }

    // Timer Tick, fired if svmgrAPI->SetTimer is used
    void __stdcall OnTimerElapsed(ULONG ulClientHandle)
    {
        // Handle corresponds on the associated Group
        _Group* pGroup = (_Group*)ulClientHandle;
        svmgrAPI->SetTimer(pGroup->GetTimerPeriod(), ulClientHandle);
        pGroup->OnTimer();
    }

    // DbConnect callback on NON QUERY command
    void __stdcall OnSqlCmdExecuteNonQueryCompleted(
        BOOL bResult,
        ULONG ulClientHandle,
        LPCTSTR pszErrorMsg,
        _svmgrSqlCmdExecuteNonQueryResult* pResult)
    {
        _Group* pGroup = (_Group*)ulClientHandle;
        pGroup->OnSqlCmdExecuteNonQueryCompleted(bResult, pszErrorMsg, pResult);
    }

    // DbConnect callback on DATAREADER command
    void __stdcall OnSqlCmdExecuteDataReaderCompleted(
        BOOL bResult,
        ULONG ulClientHandle,
        LPCTSTR pszErrorMsg,
        _svmgrSqlCmdExecuteDataReaderResult* pResult)
    {
        _Group* pGroup = (_Group*)(ulClientHandle - 1);
        pGroup->OnSqlCmdExecuteDataReaderCompleted(bResult, pszErrorMsg, pResult);
    }
};

////////////////////////////////////////////////////////////////////////////////
// The one and only IUsrMgr object instance

IUsrMgr theIUsrMgr;

////////////////////////////////////////////////////////////////////////////////
// Interface pointer to the manager toolkit API

IAPIMgr* svmgrAPI = NULL;

////////////////////////////////////////////////////////////////////////////////
// Exchanges the User DLL and manager toolkit interface pointers

HRESULT WINAPI svmgrExchangeInterface(LPVOID* ppvInterface, IAPIMgr* pSvAPI)
{
    *ppvInterface = &theIUsrMgr;
    svmgrAPI = pSvAPI;
    return S_OK;
}
