#pragma once

// Definiton specific to the driver
typedef struct
{
    CW_BYTE   ucFunction;
    CW_WORD   usQueryLength;
    CW_WORD   usResponseLength;
    CW_WORD   usLeftResponseLength;

} _sCurrentQuery;

typedef union
{
    CW_WORD Word;
    struct
    {
        CW_BYTE Low;
        CW_BYTE High;
    } Byte;

} _XBus_Value;

class PROT_EXPORT SerialDriverNetwork : public _ProtNetwork
{
private:
    static CW_BYTE  m_pucCRC_High_LookupTable[];
    static CW_BYTE  m_pucCRC_Low_LookupTable[];

    _sCurrentQuery  m_CurrentQuery;
    CW_BYTE         m_pucQuery[ 2048];
    CW_BYTE         m_pucResponse[ 2048];

    unsigned short m_usReceiveBufferSize;
    
    _XBus_Value   ErrorCheck_Generation(
        CW_LP_UCHAR lpucFrameBuffer,
        CW_WORD     usFrameBufferLength);

public:
    // Called on driver start-up
    _ProtRet Start_Async(
        _ProtStartNetworkCmd *pStartNetworkCmd);

    // Called on driver stopped
    _ProtRet Stop_Async(
        _ProtStopNetworkCmd *pStopNetworkCmd);

      // Called at the intitialization in order to instanciate all the Equipment classes
    _ProtEqt *CreateProtEqt(
        CW_USHORT usType);

    // Send the request and the serial port (if option tick on the network dialog box and waits to receive rxlength bytes
    CW_USHORT SendRcvFrame(
        _ProtEqt *pProtEqt,
        CW_LP_UCHAR txBuffer, CW_USHORT txLength, 
        CW_LP_UCHAR rxBuffer, CW_USHORT rxLength);

    // Callback called when the serial port received rxlength. Carry on receiving unitl usIndex_rcv_max == usIndex_rcv_current.
    // If after analysis
    //      - you need to discard the received some received caracter simply reduce usIndex_rcv_current by - nb caractere to discard
    //      - you need to receive more caracter simply increase usIndex_rcv_max by nb additional caracter to receive  
    void NotifyRcvData(
        CW_LP_UCHAR rxBuffer, 
        CW_USHORT *usIndex_rcv_max, 
        CW_USHORT *usIndex_rcv_current);

    // Tell the behaviour of the driver to CimWay 
    // CW_FLUX_MONO - For serial Driver : Serialisation of all the request at the network level
    // CW_FLUX_MULTI - For Tcp/Ip Driver : Serialisation of the request at the equipment level if you have 4 equipment you will e activated in parallel on your 4 equipment class.
    CW_USHORT GetFluxManagement();

    CW_WORD SendQueryAndTreatResponse(
        _ProtEqt *pSlaveEqt);
};
