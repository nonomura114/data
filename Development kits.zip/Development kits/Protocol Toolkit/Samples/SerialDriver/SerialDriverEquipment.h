#pragma once

class PROT_EXPORT SerialDriverEquipment : public _ProtEqt
{
private:
    unsigned char m_ucAddress;

public:
    // Called at the intitialization of the driver
    //void OnInitialize(
    //    _AD *adFile);

    // Called on driver close
    //void OnTerminate();

    // Called on driver start-up
    _ProtRet Start_Async(
        _ProtStartEqtCmd *pStartEqtCmd);

    // Called on driver stopped
    _ProtRet Stop_Async(
        _ProtStopEqtCmd *pStopEqtCmd);

    // Called at the intitialization in order to instanciate all the frame classes
    _ProtFrame *CreateProtFrame(
        CW_USHORT usProtocolDataType,
        CW_USHORT usCwDataType);

    unsigned char GetEqtAddress(void) {return m_ucAddress;}
};
