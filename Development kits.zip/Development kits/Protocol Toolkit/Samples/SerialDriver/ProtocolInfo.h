#pragma once

#define CWPI_MAJOR_VERSION  1
#define CWPI_MINOR_VERSION  0
#define CWPI_VENDOR_INFO    "SerialDriver"
