#include "stdafx.h"
#include "SerialDriver.h"
#include "SerialDriverEquipment.h"
#include "SerialDriverFrame.h"

/*
void SerialDriverEquipment::OnInitialize(_AD *adFile)
{
    CWTRACE(PUS_PROTOC1, LVL_BIT0, "SerialDriverEquipment::OnInitialize Name=%s",m_pCwEqt->GetGlobalName());
}

void SerialDriverEquipment::OnTerminate()
{
    CWTRACE(PUS_PROTOC1, LVL_BIT0, "SerialDriverEquipment::OnTerminate Name=%s",m_pCwEqt->GetGlobalName());
}
*/

_ProtRet SerialDriverEquipment::Start_Async(_ProtStartEqtCmd *pStartEqtCmd)
{
    CWTRACE(PUS_PROTOC1, LVL_BIT1, "SerialDriverEquipment::Start_Async Name=%s",m_pCwEqt->GetGlobalName());

    m_ucAddress = (unsigned char) pStartEqtCmd->m_EqtAddress;
    pStartEqtCmd->Ack();
    return PR_CMD_PROCESSED;
}

_ProtRet SerialDriverEquipment::Stop_Async(_ProtStopEqtCmd *pStopEqtCmd)
{
    CWTRACE(PUS_PROTOC1, LVL_BIT1, "SerialDriverEquipment::Stop_Async Name=%s",m_pCwEqt->GetGlobalName());

    pStopEqtCmd->Ack();
    return PR_CMD_PROCESSED;
}

_ProtFrame *SerialDriverEquipment::CreateProtFrame(CW_USHORT usProtocolDataType,CW_USHORT usCwDataType)
{
    CWTRACE(PUS_PROTOC1, LVL_BIT1, "SerialDriverEquipment::CreateProtFrame Name=%s ProtocolDataType=%d"
        "CwDataType=%d",m_pCwEqt->GetGlobalName(),usProtocolDataType,usCwDataType);

    // usCwDataType = ( CW_DATA_DWORD, CW_DATA_BIT, ...)
    // usProtocolDataType = ( DATA_TYPE_4, DATA_TYPE_5, ...)
    switch (usCwDataType)
    {
        case CW_DATA_BIT:
            switch (usProtocolDataType)
            {
                case 0:
                default:
                    return new SerialDriverBitFrame;
            }
            break;

        case CW_DATA_WORD:
            switch (usProtocolDataType)
            {
                case 0:
                default:
                    return new SerialDriverWordFrame;
            }
            break;
    }
    return NULL;
}
