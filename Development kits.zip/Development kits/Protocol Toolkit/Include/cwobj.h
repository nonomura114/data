
#ifndef _CWOBJ_H_

	#define _CWOBJ_H_

// Mode des commandes, synchrone ou asynchrone
#define CW_MODE_ASYNCHRONE      0
#define CW_MODE_SYNCHRONE       1


class _Cimway;	// Definition dans cw.h

#define SIGNATURE_SIZE	(32+1)

class CW_IMPORT_EXPORT _DefaultObject: public CObject
{
	DECLARE_DYNAMIC( _DefaultObject);

	//***
	//*** _DefaultObject - Configuration
	//***

private:

	CW_CHAR     m_pszSignature[ SIGNATURE_SIZE];
	CW_USHORT   m_usUserId;
	CW_ULONG	m_ulRank;		// #MODIF EG 12/06/97
	_Cimway     *m_lpBase;
	
protected:

	void        SetSignature( CW_LP_CHAR pszSignature);

	void        SetUserId( CW_USHORT usUserId);
	void        SetRank( CW_ULONG ulRank);
	void        SetBase( _Cimway *lpBase);

	virtual void        OnSetUserId( CW_USHORT usUserId) {}
	virtual void        OnSetRank( CW_ULONG ulRank) {}
	virtual void        OnSetBase( _Cimway *lpBase) {}

public:

	CW_LP_CHAR  GetSignature( void);

	void        Init( CW_USHORT usUserId, _Cimway *lpBase);

	CW_USHORT   GetUserId( void) { return m_usUserId; }
	CW_ULONG    GetRank( void)   { return m_ulRank; }
	_Cimway     *GetBase( void)  { return m_lpBase; }

protected:

	virtual void        ResetConfiguration( void);


	//***
	//*** _DefaultObject - Constructor & Destructor
	//***

public:

		_DefaultObject( void);
		virtual ~_DefaultObject( void);

	CW_USHORT   Initialize( CW_USHORT usUserId);

	virtual void        Reset( void);
	virtual void        Terminate( void) { _DefaultObject::AfterTerminate(); }
	virtual void        AfterTerminate( void) {}

	//***
	//*** _DefaultObject - Specific Method
	//***

public:
	virtual void        Dump( CW_LP_CHAR lpBuffer);

	//***
	//*** _DefaultObject - Description Method
	//***
private:

	CString     m_csName;
	CString     m_csGlobalName;

protected:

	void        SetName( CString &csName)             { m_csName = csName; m_csName.MakeUpper(); }
	void        SetGlobalName( CString &csGlobalName) { m_csGlobalName = csGlobalName; m_csGlobalName.MakeUpper();}
	void        SetName( char *pszName)               { m_csName = pszName; m_csName.MakeUpper();}
	void        SetGlobalName( char *pszGlobalName)   { m_csGlobalName = pszGlobalName; m_csGlobalName.MakeUpper();}
public:

	CString     &GetName( void)        { return m_csName; }
	CString     &GetGlobalName( void)  { return m_csGlobalName; }
};


// Defines for lComObjState
#define CW_COMOBJ_STOP_IN_PROGRESS    0L
#define CW_COMOBJ_STOP                1L
#define CW_COMOBJ_START_IN_PROGRESS   2L
#define CW_COMOBJ_START               3L


class CW_IMPORT_EXPORT _CommunicationObject: public _DefaultObject
{
	DECLARE_DYNAMIC( _CommunicationObject);

	//***
	//*** _CommunicationObject - Configuration
	//***

private:

	CW_USHORT            m_usType;
	_CommunicationObject *m_lpOwner;

protected:

	void       SetType( CW_USHORT usType);
	void       SetOwner( _CommunicationObject *lpOwner);

	virtual void    OnSetType( CW_USHORT usType) {}
	virtual void    OnSetOwner( _CommunicationObject *lpOwner) {}

public:

	void       Init(
		CW_USHORT usUserId,
		_CommunicationObject *lpOwner,
		_Cimway *lpBase,
		CW_USHORT usType);

	CW_USHORT            GetType( void)    { return m_usType; }
	_CommunicationObject *GetOwner( void)  { return m_lpOwner; }

protected:

	virtual void         ResetConfiguration( void);


	//***
	//*** _CommunicationObject - States
	//***

private:

	CW_BOOL     m_bEnabled;
	CW_BOOL     m_bCyclicEnabled;
	CW_BOOL     m_bCyclicActive;
	CW_BOOL     m_bWatchUnsolicitedEnabled;
	CW_BOOL     m_bWatchUnsolicitedActive;
	CW_BOOL     m_bInProgress;

	//#MODIFJS 23/03/98
//	CW_LBOOL    m_lbActive;     // CW_BOOL -> CW_LBOOL for Interlocked operations
//	CW_LBOOL    m_lbStartInProgress;
//	CW_LBOOL    m_lbStopInProgress;

private:

	CW_LONG     m_lcoState;

protected:

	void       coState_SetInitialState( void);
	void       coState_SetStartInProgress( void);
	void       coState_ResetStartInProgress( void);
	void       coState_SetStarted( void);
	void       coState_SetStopInProgress( void);
	void       coState_ResetStopInProgress( void);
	void       coState_SetStopped( void);

public:

	CW_BOOL    coState_IsActive( void);
	CW_BOOL    coState_IsFullActive( void);
	CW_BOOL    coState_IsStopInProgress( void);
	CW_BOOL    coState_IsStop( void);
	CW_BOOL    coState_IsStartInProgress( void);
	CW_BOOL    coState_IsInStop( void);
	CW_BOOL    coState_IsInStart( void);

protected:

	void        SetCyclicEnabled( void);
	void        ResetCyclicEnabled( void);
	void        SetCyclicActive( void);
	void        ResetCyclicActive( void);
	void        SetWatchUnsolicitedEnabled( void);
	void        ResetWatchUnsolicitedEnabled( void);
	void        SetWatchUnsolicitedActive( void);
	void        ResetWatchUnsolicitedActive( void);

public:

	void        SetEnabled( void);
	void        ResetEnabled( void);
	void        SetInProgress( void);
	void        ResetInProgress( void);

protected:

	virtual void    OnSetEnabled( void) {}
	virtual void    OnResetEnabled( void) {}
	virtual void    OnSetActive( void) {}
	virtual void    OnResetActive( void) {}
	virtual void    OnSetCyclicEnabled( void) {}
	virtual void    OnResetCyclicEnabled( void) {}
	virtual void    OnSetCyclicActive( void) {}
	virtual void    OnResetCyclicActive( void) {}
	virtual void    OnSetWatchUnsolicitedEnabled( void) {}
	virtual void    OnResetWatchUnsolicitedEnabled( void) {}
	virtual void    OnSetWatchUnsolicitedActive( void) {}
	virtual void    OnResetWatchUnsolicitedActive( void) {}

	virtual void    OnSetInProgress( void) {}
	virtual void    OnResetInProgress( void) {}

public:

	CW_BOOL      IsEnabled( void)                  { return m_bEnabled; }
	CW_BOOL      IsCyclicEnabled( void)            { return m_bCyclicEnabled; }
	CW_BOOL      IsCyclicActive( void)             { return m_bCyclicActive; }
	CW_BOOL      IsWatchUnsolicitedEnabled( void)  { return m_bWatchUnsolicitedEnabled; }
	CW_BOOL      IsWatchUnsolicitedActive( void)   { return m_bWatchUnsolicitedActive; }
	CW_BOOL      IsInProgress( void)               { return m_bInProgress; }


protected:

	virtual void    ResetStates( void);


	//***
	//*** _CommunicationObject - State Errors
	//***

private:

	CW_BOOL      m_bOutOfOrder;
	CW_BOOL      m_bInitError;
	CW_BOOL      m_bStopError;

public:

	void         SetOutOfOrder( void);
	void         ResetOutOfOrder( void);
	void         SetInitError( void);
	void         ResetInitError( void);
	void         SetStopError( void);
	void         ResetStopError( void);

protected:

	virtual void    OnSetOutOfOrder( void) {}
	virtual void    OnResetOutOfOrder( void) {}
	virtual void    OnSetInitError( void) {}
	virtual void    OnResetInitError( void) {}
	virtual void    OnSetStopError( void) {}
	virtual void    OnResetStopError( void) {}

public:

	CW_BOOL      IsOutOfOrder( void)  { return m_bOutOfOrder; }
	CW_BOOL      IsInitError( void)   { return m_bInitError; }
	CW_BOOL      IsStopError( void)   { return m_bStopError; }

	virtual void    ResetStateErrors(  BOOL bResetOutOfOrder = TRUE );//#MODIFFRM 02/07/04
	

	//***
	//*** _CommunicationObject - Error Counters
	//***

private:

	CW_ULONG     m_ulErrorCount;
	CW_ULONG     m_ulTransferErrorCount;
	CW_ULONG     m_ulNbAbortedCommand;
	//#MODIFED 28/10/09
	CW_USHORT	m_usNbRetry;

public:
	//#MODIFED 28/10/09
	virtual void		SetNbRetry(CW_USHORT usNbRetry){m_usNbRetry = usNbRetry;}
	virtual CW_USHORT	GetNbRetry(void) {return m_usNbRetry;}
	//#ENDMODIFED
	virtual void    IncrementErrorCounter( void);
	virtual void    ResetErrorCounter( void);
	virtual void    IncrementTransferErrorCounter( void);
	virtual void    ResetTransferErrorCounter( void);
	virtual void    IncrementAbortedCommandCounter( _ProtErrorLevel	ErrorLevel);
	virtual void    ResetAbortedCommandCounter( void);

protected:

	virtual void    OnIncrementErrorCounter( void) {}
	virtual void    OnResetErrorCounter( void) {}
	virtual void    OnIncrementTransferErrorCounter( void) {}
	virtual void    OnResetTransferErrorCounter( void) {}
	virtual void    OnIncrementAbortedCommandCounter( void) {}
	virtual void    OnResetAbortedCommandCounter( void) {}

public:

	CW_ULONG     GetErrorCounter( void)            { return m_ulErrorCount; }
	CW_ULONG     GetTransferErrorCounter( void)    { return m_ulTransferErrorCount; }
	CW_ULONG     GetAbortedCommandCounter( void)   { return m_ulNbAbortedCommand; }

protected:

	virtual void    ResetErrorCounters( void);


	//***
	//*** _CommunicationObject - Action Counters
	//***

private:

	CW_ULONG     m_ulReadCounter;
	CW_ULONG     m_ulFailedReadCounter;
	CW_ULONG     m_ulSuccessedReadCounter;

	CW_ULONG     m_ulWriteCounter;
	CW_ULONG     m_ulFailedWriteCounter;
	CW_ULONG     m_ulSuccessedWriteCounter;

public:

	virtual void    IncrementReadCounter( void);
	virtual void    IncrementFailedReadCounter( void);
	virtual void    IncrementSuccessedReadCounter( void);
	virtual void    ResetReadCounter( void);

	virtual void    IncrementWriteCounter( void);
	virtual void    IncrementFailedWriteCounter( void);
	virtual void    IncrementSuccessedWriteCounter();
	virtual void    ResetWriteCounter( void);

protected:

	virtual void    OnIncrementReadCounter( void) {}
	virtual void    OnIncrementFailedReadCounter( void) {}
	virtual void    OnIncrementSuccessedReadCounter( void) {}
	virtual void    OnResetReadCounter( void) {}

	virtual void    OnIncrementWriteCounter( void) {}
	virtual void    OnIncrementFailedWriteCounter( void) {}
	virtual void    OnIncrementSuccessedWriteCounter( void) {}
	virtual void    OnResetWriteCounter( void) {}

public:

	CW_ULONG     GetReadCounter( void)           { return m_ulReadCounter; }
	CW_ULONG     GetFailedReadCounter( void)     { return m_ulFailedReadCounter; }
	CW_ULONG     GetSuccessedReadCounter( void)  { return m_ulSuccessedReadCounter; }

	CW_ULONG     GetWriteCounter( void)          { return m_ulWriteCounter; }
	CW_ULONG     GetFailedWriteCounter( void)    { return m_ulFailedWriteCounter; }
	CW_ULONG     GetSuccessedWriteCounter( void) { return m_ulSuccessedWriteCounter; }

protected:

	virtual void    ResetActionCounters( void);


	//***
	//*** _CommunicationObject - Global Initialization
	//***

protected:

	CW_USHORT    Initialize(
		CW_USHORT usUserId,
		_CommunicationObject *lpOwner);

	virtual void    Reset( void);

public:
	virtual void    Terminate( void)	{ _CommunicationObject::AfterTerminate(); }
	virtual void    AfterTerminate( void);

	//***
	//*** _CommunicationObject - Constructor & destructor
	//***

public:

		_CommunicationObject( void);
		virtual ~_CommunicationObject( void);


	//***
	//*** _CommunicationObject - Management routines
	//***

public:

	CW_USHORT    CyclicActivate( CW_BOOL bReentrance);
	CW_USHORT    Start( CW_BOOL bFullStart, CW_USHORT usMode = CW_MODE_SYNCHRONE);
	CW_USHORT    Stop( CW_BOOL bFullStop, CW_BOOL bInternalStop, CW_USHORT usMode = CW_MODE_SYNCHRONE);
	CW_USHORT    StartCyclic( CW_BOOL bFullStart, CW_BOOL bInconditionalStart);
	CW_USHORT    StopCyclic( CW_BOOL bFullStop);
	CW_USHORT    StartWatchUnsolicited( CW_BOOL bFullStart);
	CW_USHORT    StopWatchUnsolicited( CW_BOOL bFullStop);
	CW_USHORT    ClearErrorCount( void);

protected:

	virtual void       SpecificCyclicActivate( CW_BOOL bReentrance) {}
	virtual void       OnCyclicActivate( void) {}

	virtual CW_USHORT  StartCommand( CW_USHORT usMode);
	virtual CW_USHORT  ReadyToBeActivate( void)  { return CW_OK; }
	virtual CW_USHORT  BeforeStartCommand( void);
	virtual CW_BOOL    IsFatalFailedStart( void) { return CW_FALSE; }
	virtual void       SpecificStart( void)      {}

	virtual CW_USHORT  StopCommand( CW_BOOL bInternalStop, CW_USHORT usMode);
	virtual CW_USHORT  ReadyToBeInactivate( void) { return CW_OK; }
	virtual CW_USHORT  BeforeStopCommand( void);  
	virtual void       SpecificStop( CW_BOOL bInternalStop) {}

	virtual void       SpecificStartCyclic( void) {}
	virtual CW_USHORT  IsCyclicReadyToBeActivate( CW_BOOL bFullStart, CW_BOOL bInconditionalStart) { return CW_OK; }
	virtual void       SpecificStopCyclic( void) {}
	virtual CW_USHORT  IsCyclicReadyToBeInactivate( void) { return CW_OK; }

	virtual void       SpecificFullStartCyclic( void) {}
	virtual void       SpecificFullStopCyclic( void) {}

	virtual void       SpecificStartWatchUnsolicited( void) {}
	virtual CW_USHORT  IsWatchUnsolicitedReadyToBeActivate( CW_BOOL bFullStart) { return CW_OK; }
	virtual void       SpecificStopWatchUnsolicited( void) {}
	virtual CW_USHORT  IsWatchUnsolicitedReadyToBeInactivate( void) { return CW_OK; }

	virtual void       OnClearErrorCount( void) {}

public:
	virtual CW_USHORT  AfterStartCommand( void);
	virtual CW_USHORT  AfterStopCommand(CW_BOOL bInternalStop);

	virtual void       Dump( CW_LP_CHAR lpBuffer);

	//#MODIFJS 22/04/98
	//*** Configuration methods

public:

	void               ModifyConfig( CW_LP_CHAR lpszConfigBuffer);
	virtual void       OnModifyConfig(CW_LPC_CHAR szConfiguration) {}

protected:

	virtual void       BeforeModifyConfig( void);
	virtual void       AfterModifyConfig( void);
	virtual void       ModifyConfigCommand(CW_LPC_CHAR szConfiguration) {}

	//*** User Attributes

protected:

	CW_USHORT    m_usNbUserAttributes;
	CString   ** m_ppszUserAttributes;

public:

	void          SetUserAttributes(
		CW_LPC_CHAR szUserAttributes,
		CW_BOOL     bInitialize);

	CW_USHORT     SetUserAttribute(
		CW_LPC_CHAR szUserAttribute,
		CW_USHORT   usIndex);

	void          GetUserAttributes(
		CString & szUserAttributes);

	CW_USHORT     GetUserAttribute(
		CString   & szUserAttribute,
		CW_USHORT   usIndex);

	CW_USHORT     GetUserAttribute(
		CW_USHORT          usIndex,
		CW_ENUMITEMTYPE    itUserAttributesType,
		_CwDataItem     ** diUserAttributes);
};


#endif /* _CWOBJ_H_ */
