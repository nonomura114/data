
#ifndef _CWERROR_H_

	#define _CWERROR_H_

// Les erreurs traitees par le protocole
// -------------------------------------


// Les differents niveaux d'erreur
enum _ProtErrorLevel
{
	PEL_FATAL	= 0,	// Erreur fatale
						// Il n'y a pas de repetition d'effectuer
						// pour ce type d'erreur
	PEL_WARNING	= 1,	// Une erreur est detectee
						// Une rpetition peut etre effectuee
						// pour ce type d'erreur
	PEL_INFO	= 2		// Signale une erreur
};


// Les differentes classes d'erreur
enum _ProtErrorClass
{
	PEC_NO_ERROR		= 0,	// Pas d'erreur
	PEC_TRANSMISSION	= 1,	// L'equipement signale une erreur
	PEC_PROTOCOL		= 2,	// Erreur de classe protocole
	PEC_PROVIDE_BY_EQT	= 3,	// L'equipement signale une erreur
	PEC_NETWORK			= 4,	// Erreur de classe reseau
	PEC_TIME_OUT		= 5,	// Erreur de time-out
	PEC_OTHER			= 6,	// Autre erreur
	PEC_SEND			= 7,	// Erreur d'emission
	PEC_RECEIVE			= 8,	// Erreur de reception
	PEC_SERIAL			= 9,	// Erreur lors d'une communication s�rie
	//#MODIFJS 04/12/98 - Gestion d'erreur 'DLL not found'
	PEC_LIBRARY         = 10,    // Erreur si une librairie n'a pu �tre charg�e
	//#ENDMODIFJS 04/12/98 - Gestion d'erreur 'DLL not found'
	PEC_NOT_IMPLEMENTED = 11    // Erreur fonction non support� par le driver
};


// Valeurs de ErrorCode lorsque la classe d'erreur est PEC_SERIAL
#define PECODE_SERIAL_RX_TIMEOUT	0x0001	// Time out on receive
#define PECODE_SERIAL_RX_OVERRUN	0x0002	// Receive Overrun Error
#define PECODE_SERIAL_RX_PARITY		0x0003	// Receive Parity Error
#define PECODE_SERIAL_RX_FRAME		0x0004	// Receive Framing Error
#define PECODE_SERIAL_RX_BREAK		0x0005	// Break Detected
#define PECODE_SERIAL_RX_OVERFLOW	0x0006	// Receive Queue overflow

#define PECODE_SERIAL_TX_TIMEOUT	0x0101	// Time out on talk
#define PECODE_SERIAL_TX_FULL		0x0102	// Talk Queue is full


// Structure retournee sur detection d'erreur du protocole
struct _ProtError
{
	_ProtErrorLevel	ErrorLevel;		// Niveau de l'erreur
	_ProtErrorClass	ErrorClass;		// Classe de l'erreur
	CW_LONG			ErrorCode;		// Code de l'erreur
	CW_LONG			ErrorMsgNumber;	// Numero du message d'erreur
									// Doit etre mis a 0 si non utilise
	CW_LONG			ErrorComp1;		// 1er code d'erreur complementaire
									// Doit etre mis a 0 si non utilise
	CW_LONG			ErrorComp2;		// 1er code d'erreur complementaire
									// Doit etre mis a 0 si non utilise
	CW_LONG			ErrorComp3;		// 1er code d'erreur complementaire
									// Doit etre mis a 0 si non utilise
	CW_LONG			Reserve[16];	// Champs reserves
									// Doit etre mis a 0 si non utilise
	//#MODIFJS 04/12/98 - Gestion d'erreur 'DLL not found'
	CHAR            ErrorDesc[ 64]; // Description de l'erreur
	//#ENDMODIFJS 04/12/98 - Gestion d'erreur 'DLL not found'
};


#endif /* _CWERROR_H_ */
