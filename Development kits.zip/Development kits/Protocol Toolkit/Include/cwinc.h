
//
// WARNING !!!
// 
// Ce fichier doit avoir aucune d�pendance sur un quelconque
// fichier de CW32 (comme INCLUDE.h de SV32)
//


#ifndef _CWINC_H_

	#define _CWINC_H_

#define CW_AUDIT_CPT	1
#define CW_AUDIT_TIM	1

//
// CLASSE Compteurs d'AUDIT
//
#define GBL_MAX_CW_STAT	64
#define	C_NULL			0
#define	C_DEFOBJECT		1
#define	C_COMMOBJECT	2
#define	C_BRDOBJECT		3
#define	C_NETOBJECT		4
#define	C_EQTOBJECT		5
#define	C_FRMOBJECT		6
#define	C_ITEMOBJECT	7
#define	C_LINKOBJECT	8
#define	C_DATAOBJECT	9

#define	C_CMDLSTLCK		20
#define	C_CMDLSTMSG		21

//
// FAMILY Compteurs
//
#define C_FAM_BASE		0
#define C_FAM_BK		1
#define C_FAM_NG		2

#define GBL_MAX_FAMILY	16	// used by FCElt and pcvstr

struct cwstat 
{
public:

	CW_ULONG	cpt;		// nombre d'instanci�s
	CW_ULONG	cptnew;		// bombre  d'instanciations
	CW_ULONG	cumul;		// cumul de la memoire utilis�e
	CW_ULONG	fcpt[GBL_MAX_FAMILY];
	CW_ULONG	fcptnew[GBL_MAX_FAMILY];
};


//
// Compteur d'AUDIT des temps
//
#define GBL_MAX_CW_STATTIME 64
#define T_NULL			0

#define GBL_MAX_BEST	5

struct cwstattime 
{
public:

	CW_ULONG		tim;				// time unix (sec. depuis 01/01/70)
	CW_USHORT		ms;					// millisecondes
	CW_ULONG		durebest[GBL_MAX_BEST];	// dur�e ecoul�e
	CW_ULONG		timebest[GBL_MAX_BEST];
	CW_USHORT		base; 				// base de temps en seconde
	CW_USHORT		cpt;  				// multiple de la base de temps
	CW_USHORT		associated_cpt;		// compteur associ� C_xxxxx
	CW_USHORT		family;				// famille de 1 � 15
	CW_ULONG		dureeworse[1];
	CW_ULONG		timeworse[1];
	CW_ULONG		nbevent;  			// pour correction du temps et non sur timer
	CW_ULONG		timeevent;
};


#endif