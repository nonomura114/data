
#ifndef _CWAD_H_

	#define _CWAD_H_

#define ADMAXFIELD      1024 			//#MODIFED 19/08/08 On augmente le nombre de champs possible de 256 � 1024
#define ADMAXBUF        (60 * (unsigned)1024)
#define LIGNE_LEN_MAXI  (4 * (unsigned)1024)	//#MODIFED 19/08/08 On augmente la taille de la ligne de 2048 � 4 *(unsigned)1024


class CW_IMPORT_EXPORT _AD: public CObject
{
	DECLARE_DYNAMIC( _AD)

protected:
	CW_LP_CHAR m_lpszAdContent;	// #MODIF EG 26/05/97
	CW_LP_CHAR m_tabAdContent[ ADMAXFIELD];
	CW_SHORT   m_tabAdSize[ ADMAXFIELD];

private:
	CW_SHORT    m_sEndOfFile;
	CW_SHORT    m_sErrorNumber;

	CW_SHORT    m_sFileTerminated;
	CW_SHORT    m_sExternalAllocation;
	CW_SHORT    m_sCursorInDoubleQuote;
	CW_SHORT    m_sCursorInBuffer;
	CW_USHORT   m_usWantedNumber;
	CW_USHORT   m_usReadNumber;

	CW_SHORT    m_sBufferType;		// 0= fichier, 1=buffer
	CW_CHAR     m_cSeparator;
	CW_SHORT    m_sNbLines;
	CW_SHORT    m_sNbFields;

	CW_LP_SHORT m_lpsBuffer;
	CW_LP_CHAR  m_lpszADBuffer;		// [ADMAXBUF+1]
	CW_LP_CHAR  m_lpszLast;
	CW_LP_CHAR  m_lpszCurrent;
	CW_LP_CHAR  m_lpszNext;
	CW_LP_CHAR  m_lpszMaximum;

	CW_SHORT Init( CW_LP_CHAR lpszFileName,
		CW_LP_SHORT ExternalBuffer = NULL,
		CW_CHAR	cSeparator = ',');

	CW_SHORT Init( CW_LP_CHAR lpszBuffer,
		CW_LONG lBufferSize,
		CW_LP_SHORT lpsExternalBuffer = NULL,
		CW_CHAR cSeparator = ',');

	HANDLE     hFile;

public:

		_AD( CW_LP_CHAR lpszFileName,
			CW_LP_SHORT lpsExternalBuffer = NULL,
			CW_CHAR cSeparator = ',');

		_AD( CW_LP_CHAR lpszBuffer,
			CW_LONG lBufferSize,
			CW_LP_SHORT lpsExternalBuffer = NULL,
			CW_CHAR cSeparator = ',');

		virtual ~_AD( void);

	CW_SHORT   TreatBuffer( void);
	CW_SHORT   Next( void);
	CW_SHORT   Eof( void);
	CW_SHORT   GetError( void);
	CW_SHORT   GetNbLines( void);  // Nombre de lignes lues
	CW_SHORT   GetNbFields( void); // Nombre de champs

	CW_LP_CHAR GetStr( CW_SHORT sPos);
	CW_LP_CHAR GetAdContent( void);	// #MODIF EG 26/05/97
	CW_SHORT   GetLen( CW_SHORT sPos);
	CW_INT     GetI( CW_SHORT sPos);
	CW_UINT    GetU( CW_SHORT sPos);
	CW_LONG    GetL( CW_SHORT sPos);
	CW_ULONG   GetUl( CW_SHORT sPos);
	CW_FLOAT   GetF( CW_SHORT sPos);
	CW_DOUBLE  GetD( CW_SHORT sPos);
	CW_BOOL    GetB( CW_SHORT sPos);
	CW_QINT    GetQi( CW_SHORT sPos);
	CW_BOOL    IsMark( CW_LP_CHAR lpszMark);

	//#MODIFJS 23/04/98
	CW_USHORT  GetVariant(
		CW_SHORT        sPos,
		CW_ENUMITEMTYPE itVariantType,
		_CwDataItem     **diVariant);
};

#define Ad_GetStr( ad, x)   ad->GetStr( x)
#define Ad_GetLen( ad, x)   ad->GetLen( x)
#define Ad_GetI( ad, x)     ad->GetI( x)
#define Ad_GetU( ad, x)     ad->GetU( x)
#define Ad_GetL( ad, x)     ad->GetL( x)
#define Ad_GetUl( ad, x)    ad->GetUl( x)
#define Ad_GetD( ad, x)     ad->GetD( x)
#define Ad_IsMark( ad, ref) (!strcmp( ad->m_tabAdContent[0], ref))
#define Ad_GetB( ad, x)     ad->GetB( x)

#define Ad_Next( ad)        ad->Next()
#define Ad_Error( ad)       ad->GetError()
#define Ad_Eof( ad)         ad->Eof()


//------------------------------------------------------------------------


#define ADS_CASE_INSENSITIVE  0

CW_IMPORT_EXPORT CW_LP_CHAR AdsNext(
	char * cad);

CW_IMPORT_EXPORT CW_LP_CHAR AdsGetS(
	char *cad, int n, char ** ncad = NULL);

CW_IMPORT_EXPORT CW_LP_CHAR AdsGetPS( 
	char * cad, int n, int nc, char *dst, char ** ncad = NULL);

CW_IMPORT_EXPORT CW_INT AdsGetI(
	char * cad, int n, char ** ncad = NULL);

CW_IMPORT_EXPORT CW_UINT AdsGetU(
	char * cad, int n, char ** ncad = NULL);

CW_IMPORT_EXPORT CW_LONG AdsGetL(
	char * cad, int n, char ** ncad = NULL);

CW_IMPORT_EXPORT CW_ULONG AdsGetUl(
	char * cad, int n, char ** ncad = NULL);

CW_IMPORT_EXPORT CW_DOUBLE AdsGetD(
	char * cad, int n, char ** ncad = NULL);

CW_IMPORT_EXPORT CW_BOOL AdsIsMark(
	char * cad, char * ref, int fCaseSensitive = 1);

#endif /* _CWAD_H_ */
