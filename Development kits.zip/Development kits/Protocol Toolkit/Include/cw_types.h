
#ifndef _CWTYPES_H_

	#define _CWTYPES_H_

	#define CW_BOOL_ENUM
	#ifdef CW_BOOL_ENUM
		typedef enum
		{
			CW_TRUE  = 0x0000,
			CW_FALSE = 0xFFFF
		} CW_BOOL;
	#else
		typedef unsigned short CW_BOOL;
		#define CW_TRUE 0x0000
		#define CW_FALSE 0xFFFF
	#endif

	typedef unsigned          CW_BIT;
	typedef short             CW_SHORT;
	typedef unsigned short    CW_USHORT;
	typedef int               CW_INT;
	typedef unsigned int      CW_UINT;
	typedef long              CW_LONG;
	typedef unsigned long     CW_ULONG;
	typedef __int64           CW_QINT;
	typedef unsigned __int64  CW_UQINT;
	typedef char              CW_CHAR;
	typedef unsigned char     CW_UCHAR;
	typedef void              CW_VOID;
	typedef float             CW_FLOAT;
	typedef double            CW_DOUBLE;

	//#MODIFJS 23/03/98
	typedef long              CW_LBOOL;

	typedef CW_UCHAR       CW_BYTE;  // 1 byte  ( for any OS)
	typedef CW_USHORT      CW_WORD;  // 2 bytes ( for any OS)
	typedef CW_ULONG       CW_DWORD; // 4 bytes ( for any OS)
	typedef CW_UQINT       CW_QWORD; // 8 bytes ( for any OS)
	typedef CW_FLOAT       CW_REAL;  // 4 bytes ( for any OS)

	typedef CW_BOOL       *CW_LP_BOOL;
	typedef CW_SHORT      *CW_LP_SHORT;
	typedef CW_USHORT     *CW_LP_USHORT;
	typedef CW_INT        *CW_LP_INT;
	typedef CW_UINT       *CW_LP_UINT;
	typedef CW_LONG       *CW_LP_LONG;
	typedef CW_ULONG      *CW_LP_ULONG;
	typedef CW_QINT       *CW_LP_QINT;
	typedef CW_UQINT      *CW_LP_UQINT;
	typedef CW_CHAR       *CW_LP_CHAR;
	typedef CW_CHAR const *CW_LPC_CHAR;
	typedef CW_UCHAR      *CW_LP_UCHAR;
	typedef CW_UCHAR const *CW_LPC_UCHAR;
	typedef CW_VOID       *CW_LP_VOID;

	typedef CW_BYTE       *CW_LP_BYTE;
	typedef CW_WORD       *CW_LP_WORD;
	typedef CW_DWORD      *CW_LP_DWORD;
	typedef CW_QWORD      *CW_LP_QWORD;
	typedef CW_REAL       *CW_LP_REAL;

	#define OCTET          CW_BYTE
	#define MOT            CW_WORD	
	#define DMOT           CW_DWORD	

	//#MODIFJS 23/03/98
	//Define for CW_LBOOL
	#define CW_LTRUE  0x00000000
	#define CW_LFALSE 0xFFFFFFFF

	#undef  NULL
	#define NULL 0

	#define BoolToBit( Bool)   ( Bool == CW_TRUE? 1: 0)
	#define BitToBool( Bit)    ( Bit == 0? CW_FALSE: CW_TRUE)


	typedef CW_USHORT		CW_RESULT;
	typedef CW_ULONG		CW_TRANSACTID;


	//**
	//** Object ID
	//**

	typedef char  *CW_ID;


	//**
	//** Handle Management
	//**

	typedef CW_ULONG  CW_HANDLE;
	typedef CW_HANDLE	*CW_LP_HANDLE;

	#define CW_INVALID_HANDLE  0xFFFFFFFF


	//**
	//** Basic Data Type
	//**

	#define CW_DATA_BIT      0 // Bit.
	#define CW_DATA_BYTE     1 // Byte (8 bits).
	#define CW_DATA_WORD     2 // Word (16 bits).
	#define CW_DATA_REAL     3 // Real (32 bits).
	#define CW_DATA_DWORD    4 // Double word (32 bits).

	#define CW_FRAME_BIT     1 // Bit.
	#define CW_FRAME_BYTE    2 // Byte (8 bits).
	#define CW_FRAME_WORD    3 // Word (16 bits).
	#define CW_FRAME_REAL    4 // Real (32 bits).
	#define CW_FRAME_DWORD   5 // Double word (32 bits).

	typedef CW_USHORT	       CW_ITEMTYPE;

	enum CW_ENUMITEMTYPE
	{
		CWIT_BOOL = CW_DATA_BIT,   // True = -1, False = 0 (short 2 bytes)
		CWIT_UI1  = CW_DATA_BYTE,  // Unsigned char		(1 byte) 
		CWIT_UI2  = CW_DATA_WORD,  // Unsigned short	(2 bytes) 
		CWIT_R4   = CW_DATA_REAL,  // Reel simple pr�cision(4 bytes) 
		CWIT_UI4  = CW_DATA_DWORD, // Unsigned long		(4 bytes) 
		CWIT_UI8,                  // Unsigned ultra long (8 bytes)
		CWIT_I1,                   // Signed char (1 byte) 
		CWIT_I2,                   // Signed short (2 bytes) 
		CWIT_I4,                   // Signed long (4 bytes)
		CWIT_I8,                   // Signed ultra long (8 bytes)
		CWIT_R8,                   // Reel double pr�cision (8 bytes)
		CWIT_CHAR,                 // char (1 byte)
		CWIT_P_BOOL,               // array of CWIT_BOOL
		CWIT_P_UI1,                // array of CWIT_UI1
		CWIT_P_UI2,                // array of CWIT_UI2
		CWIT_P_UI4,                // array of CWIT_UI4
		CWIT_P_UI8,                // array of CWIT_UI8
		CWIT_P_I1,                 // array of CWIT_I1
		CWIT_P_I2,                 // array of CWIT_I2
		CWIT_P_I4,                 // array of CWIT_I4
		CWIT_P_I8,                 // array of CWIT_I8
		CWIT_P_R4,                 // array of CWIT_R4
		CWIT_P_R8,                 // array of CWIT_R8
		CWIT_STR                   // String zero delimited
	};


	struct _CwDatation
	{
		CW_BYTE   dd;
		CW_BYTE   mm;
		CW_BYTE   hh;
		CW_BYTE   mn;
		CW_WORD   msec;
	};


	struct _CwUpdate
	{
		CW_USHORT dd;
		CW_USHORT mm;
		CW_USHORT hh;
		CW_USHORT mn;
		CW_USHORT msec;
	};


	typedef	CW_CHAR					CW_STMFORMATDATATIME;
	typedef	CW_STMFORMATDATATIME	*CW_LPSTMFORMATDATATIME;


	//**
	//** D�fintion du variant CW
	//**

	//#MODIFJS 23/04/98
	// Cette d�finition se trouvait pr�c�demment dans le fichier CWAPI.h

	typedef struct
	{
		CW_ITEMTYPE	ItemType;	// Type
		CW_ULONG    ulSize;     // Taille en elt de ItemType
		union
		{
   			CW_BOOL		bVal;		// CW_TRUE, CW_FALSE
			CW_UCHAR	ucVal;		// Unsigned char (1 byte) 
			CW_CHAR		cVal;		// Signed char (1 byte) 
			CW_USHORT	uiVal;		// Unsigned short (2 bytes) 
			CW_SHORT	iVal;		// Signed short	(2 bytes) 
			CW_ULONG	ulVal;		// Unsigned long (4 bytes) 
			CW_LONG		lVal;		// Signed long (4 bytes)
			CW_UQINT    uqVal;      // Unsigned ultra long (9 bytes)
			CW_QINT     qVal;       // Signed ultra long (9 bytes)
			CW_FLOAT	fltVal;		// Reel simple pr�cision (4 bytes) 
			CW_DOUBLE	dblVal;		// Reel double pr�cision (8 bytes) 
//#MODIFFRM 13/06/01
//			CW_CHAR		strVal;		// Chaine de caract�re termin�e par \0
			CW_CHAR		*strVal;		// Chaine de caract�re termin�e par \0
//#ENDMODIFFRM 13/06/01
			CW_DWORD 	dwRaw;    	// Valeur brute
		} CwValue;
	} _CwDataItem;



#endif /* _CWTYPES_H_ */
