
#ifndef _CWCMD_H_

	#define _CWCMD_H_


// Origin
#define CW_ORIGIN_APPLICATION  0
#define CW_ORIGIN_TIMER        1

// Type
#define CW_TYPE_NETSTART            1
#define CW_TYPE_UPHOLD              2
#define CW_TYPE_NETSTOP             3
#define CW_TYPE_EQTSTART            4
#define CW_TYPE_EQTSTOP             5
#define CW_TYPE_READ                6
#define CW_TYPE_WRITE               7
#define CW_TYPE_TSTDISPO            8
#define CW_TYPE_RAZDISPO            9   // 1 � 9 compatible avec CW DOS, apr�s libre
#define CW_TYPE_FRMSTART            10
#define CW_TYPE_FRMSTOP             11
#define CW_TYPE_NETINITIALIZE       12
#define CW_TYPE_NETTERMINATE        13
#define CW_TYPE_EQTINITIALIZE       14
#define CW_TYPE_EQTTERMINATE        15
#define CW_TYPE_FRMINITIALIZE       16
#define CW_TYPE_FRMTERMINATE        17
#define CW_TYPE_NETSTARTCYCLIC      18
#define CW_TYPE_NETSTOPCYCLIC       19
#define CW_TYPE_NETSTARTUNSOLICITED 20
#define CW_TYPE_NETSTOPUNSOLICITED  21
#define CW_TYPE_EQTSTARTCYCLIC      22
#define CW_TYPE_EQTSTOPCYCLIC       23
#define CW_TYPE_EQTSTARTUNSOLICITED 24
#define CW_TYPE_EQTSTOPUNSOLICITED  25
#define CW_TYPE_FRMSTARTCYCLIC      26
#define CW_TYPE_FRMSTOPCYCLIC       27
#define CW_TYPE_FRMSTARTUNSOLICITED 28
#define CW_TYPE_FRMSTOPUNSOLICITED  29
#define CW_TYPE_NETMSG              30
#define CW_TYPE_EQTMSG              31
#define CW_TYPE_FRMMSG              32
#define CW_TYPE_NETCFG              33
#define CW_TYPE_EQTCFG              34
#define CW_TYPE_FRMCFG              35
#define CW_TYPE_FRMCYCLICCFG        36
#define CW_TYPE_NETBROWSE			37
#define CW_TYPE_NETBROWSEDEVICE		38
#define CW_TYPE_DEVBROWSE			39

// Range
#define CW_RANGE_GLOBAL         1
#define CW_RANGE_PARTIAL        2

// Table
#define CW_TABLE_IMAGE          (( CW_USHORT)0)
#define CW_TABLE_USER           (( CW_USHORT)1)

// ComObject Level
#define CW_LEVEL_NET            1
#define CW_LEVEL_EQT            2
#define CW_LEVEL_FRM            3

#define CW_SIZEOF_CONFIG		1024 //#MODIFED 13/10/04
//
// D�finition des niveaux de chaque liste
// CMDRESP + prioritaire que TIMER.
//
#define CW_CMDLST_LVL_CMDRESP	0
#define CW_CMDLST_LVL_UPHOLD	1
#define CW_CMDLST_LVL_ULTRA		2
#define CW_CMDLST_LVL_PRIOR		3
#define CW_CMDLST_LVL_ONESHOT	4
#define CW_CMDLST_LVL_TIMER		5

typedef enum
{
	CW_CMD_PROGRESS__NOT_IN_PROGRESS   = 0,
	CW_CMD_PROGRESS__ACTIVE_SYNC       = 1,
	CW_CMD_PROGRESS__ACTIVE_ASYNC      = 2,
	CW_CMD_PROGRESS__ACK               = 3,
	CW_CMD_PROGRESS__NACK              = 4
} _CmdProgress;

#define CW_CMD_ABORT__NOT_ABORT            0


class _EltSingleList;

struct _ProtError;              // Definie dans cwerror.h
struct _ProtPartialDataTable;

#define NB_MAX_ELT_IN_SPOOL  32         // #MODIF EG 13/06/97   avant 200


class CW_IMPORT_EXPORT _Command: public _EltSingleList
{
	DECLARE_DYNAMIC( _Command)

private:

	_Elt                    *m_eltGlobalList;
	_Elt                    *m_eltSpecificList;

protected:

	CW_USHORT               m_Origin;
	CW_USHORT               m_Type;
	CW_USHORT               m_usLevel;
	CW_USHORT               m_Mode;
	CW_USHORT               m_Range;
	CW_ULONG                m_StartPosition;
	CW_ULONG                m_Length;
	CW_USHORT               m_Table;
	CW_BOOL                 m_HighPriority;
	CW_BOOL                 m_SequencementOblig;
	CW_BOOL                 m_Conditionnel;
	CW_BOOL                 m_bConfiguration;

	MSECS                   m_msTimeOut;
	MSECS                   m_msTimeOutStartTime;
	CW_BOOL                 m_bTimeOutError;
	CW_BOOL                 m_bTimeOutStarted;
	
	CW_BOOL                 m_bTurnAroundDisable;
	
	CW_USHORT               m_usComObjectLevel;
	_CwBaseNetwork          *m_Network;
	_CwBaseEqt              *m_Eqt;
	_CwBaseFrame            *m_Frame;
	_CwBaseLink             *m_Link;

	CW_USHORT               m_usRetryCount;

protected:

		_Command(
			CW_USHORT usType,
			CW_USHORT usComObjLevel,
			CW_USHORT usMode,
			CW_USHORT usOrigin,
			CW_USHORT usCmdLstLvl,
			CW_BOOL   bHighPriority = CW_FALSE,
			CW_BOOL   bConditionnel = CW_FALSE,
			CW_USHORT usTable = CW_TABLE_IMAGE,
			CW_USHORT usRange = CW_RANGE_GLOBAL,
			CW_ULONG  ulStartPosition = 0L,
			CW_ULONG  ulLength = 0L,
			CW_BOOL   bSequencementOblig = CW_FALSE);

public:

	virtual void NotifyCompleted( void){}; //#MODIFFRM 28/04/03
	virtual ~_Command( void);

public:

	void                    DumpInfo( CW_LP_CHAR lpszDumpReason);

	_CwBaseNetwork          *GetNet( void);
	_CwBaseEqt              *GetEqt( void);
	_CwBaseFrame            *GetFrm( void);

	CW_USHORT               GetTable( void);
	CW_USHORT               GetOrigin( void);
	CW_USHORT               GetType( void);
	CW_ULONG                GetEqtId( void);
	CW_ULONG                GetEqtRank( void);

	void                    SetSpecificListElt( _Elt *eltSpecificList);
	_Elt                    *GetSpecificListElt( void);
	void                    SetGlobalListElt( _Elt *eltGlobalList);
	_Elt                    *GetGlobalListElt( void);

	void                    SetRetryCount( CW_USHORT usRetryCount);
	CW_USHORT               DecrementRetryCount( void);
	CW_BOOL                 GoRetry( void);

	CW_BOOL                 VerifyTimeOut( void);
	CW_BOOL                 IsTimeOut( void);
	void                    StartTimeOut( void);
	void                    StopTimeOut( void);

	void                    SetTimeOutError( void);
	void                    ResetTimeOutError( void);

	virtual void            OnSetTimeOutError( void);
	virtual void            OnResetTimeOutError( void);
	
	CW_BOOL                 IsSynchro( void);
	CW_BOOL                 IsTimerCommand( void);
	CW_BOOL                 IsNetworkLevelCommand( void);
	CW_BOOL                 IsFrameLevelCommand( void);
	CW_BOOL                 IsConfigurationCommand( void);

    inline void             SetTurnAroundDisable()   { m_bTurnAroundDisable = CW_TRUE; }
    inline void             ResetTurnAroundDisable() { m_bTurnAroundDisable = CW_FALSE; }
    inline CW_BOOL          IsSetTurnAroundDisable() { return m_bTurnAroundDisable; }

public:

	CW_USHORT               m_CrExec;
	_ProtRet                m_prResult;
	_ProtError              m_peError;

	_CmdProgress            m_ecpProgressState;
	CW_USHORT               m_usAborted;

	virtual CW_USHORT       GetCommandListLevel( void);
	virtual void            SetCommandListLevel( CW_USHORT);

	CW_BOOL                 Activate( void);        // Ex�cution de la cmde
	CW_BOOL                 Acquit( void);          // Acquitement d'une cmde

	virtual _ProtRet        Treat( void);
	virtual CW_USHORT       FatalTest( void);
	virtual CW_BOOL         DynamicTest( void);

protected:

	virtual CW_USHORT       WriteResponseCmd( void);
public:

	virtual void      OnExtract( void);

protected:

	virtual void      OnSetInProgress( void);
	virtual void      OnResetInProgress( void);

public:

	CW_BOOL           IsInProgress( void);

	virtual void      OnFailedLinking( CW_USHORT usCmdListLevel);
	virtual void      OnSuccessedLinking( void);

	virtual void      Ack( void);                   // Acquittement positif d'une cmde
	virtual void      Nack( _ProtError *);  // Acquitement n�gatif d'une cmde
//      virtual void      Abort( void);                 // Abort d'une cmde par CW32
	virtual void      AckAbort( void);              // Acquittement de l'abort par le protocole

protected:

	virtual void      OnAck( void);
	virtual void      OnNack( void);
//      virtual void      OnAbort( void);
//      virtual void      OnAckAbort( _ProtError *pErr);
	virtual void      OnNotProcess();
	virtual void      OnNeverProcess();

public:

	CW_USHORT                 SetDataTable( CW_LP_VOID lpvSrc);
	CW_USHORT                 GetDataTable( CW_LP_VOID lpvDest);
};


//********************************
//**
//** Commande de niveau Network
//**
//********************************

class CW_IMPORT_EXPORT _BaseNetworkCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseNetworkCmd)

protected:

	_BaseNetworkCmd(                        // Constructeur
		_CwBaseNetwork *pCwNetwork,
		CW_USHORT      usType,
		CW_USHORT      usMode,
		CW_USHORT      usOrigin,
		CW_USHORT      usCmdLstLvl);

public:

	virtual CW_USHORT       FatalTest( void);

protected:

	virtual CW_USHORT       WriteResponseCmd( void);

	virtual void            OnSetInProgress( void);
	virtual void            OnResetInProgress( void);

	virtual void    OnAck( void);
	virtual void    OnNack( void);
};


class CW_IMPORT_EXPORT _BaseStartNetworkCmd: public _BaseNetworkCmd
{
	DECLARE_DYNAMIC( _BaseStartNetworkCmd)

protected:

	_BaseStartNetworkCmd(           // Constructeur
			_CwBaseNetwork *	pCwNetwork,
			CW_USHORT			usMode);

	virtual _ProtRet        Treat( void);

	virtual void    OnNack( void);
};


class CW_IMPORT_EXPORT _BaseStopNetworkCmd: public _BaseNetworkCmd
{
	DECLARE_DYNAMIC( _BaseStopNetworkCmd)

protected:

	_BaseStopNetworkCmd(            // Constructeur
			_CwBaseNetwork *	pCwNetwork,
			CW_USHORT			usMode);

	virtual _ProtRet        Treat( void);

	virtual void    OnNack( void);
};


class CW_IMPORT_EXPORT _BaseCycScanCmd: public _BaseNetworkCmd
{
	DECLARE_DYNAMIC( _BaseCycScanCmd)

private:
	static _LinkSingleList  *m_llSpool;
	//#MODIFJS 23/02/98
	static _CriticalSection *m_lSpoolLock;

public:

	static void     SpoolInitialize( void);
	static void     SpoolTerminate( void);

	void *operator  new( size_t);
	void operator   delete( void *);

protected:
	
	_BaseCycScanCmd(                // Constructeur
		_CwBaseNetwork *pCwNetwork);

	virtual _ProtRet  Treat( void);

public:

	CW_USHORT       FatalTest( void);

protected:

	virtual void    OnSuccessedLinking( void);
	virtual void    OnNack( void);
//      virtual void    OnAbort( void);
	virtual void    OnNeverProcess( void);

public:

	virtual void            OnExtract( void);
};


class CW_IMPORT_EXPORT _BaseBrowseNetworkCmd : public _BaseNetworkCmd
{
	DECLARE_DYNAMIC(_BaseBrowseNetworkCmd)

public:

	_BaseBrowseNetworkCmd(            // Constructeur
		_CwBaseNetwork *	pCwNetwork);
protected:

	virtual _ProtRet        Treat(void);

public:
	virtual void	Nack(_ProtError *pError);
	virtual void    Ack(LPCTSTR pDataBuf);
};


class CW_IMPORT_EXPORT _BaseBrowseNetworkDeviceCmd : public _BaseNetworkCmd
{
	DECLARE_DYNAMIC(_BaseBrowseNetworkDeviceCmd)
	CString m_szDeviceId;

public:

	_BaseBrowseNetworkDeviceCmd(            // Constructeur
		_CwBaseNetwork *	pCwNetwork,
		LPCTSTR szDeviceId);
protected:

	virtual _ProtRet        Treat(void);

public:
	virtual void	Nack(_ProtError *pError);
	virtual void    Ack(LPCTSTR pDataBuf);
};






//**********************************
//**
//** Commande de niveau Equipment
//**
//**********************************


class CW_IMPORT_EXPORT _BaseEqtCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseEqtCmd)

protected:

	_BaseEqtCmd(                    // Constructeur
			_CwBaseEqt *	pCwEqt,
			CW_USHORT		usType,
			CW_USHORT		usMode);

public:

	virtual CW_USHORT       FatalTest( void);

protected:

	virtual CW_USHORT       WriteResponseCmd( void);

	virtual void            OnSetInProgress( void);
	virtual void            OnResetInProgress( void);

	virtual void            OnAck( void);
	virtual void            OnNack( void);
};


class CW_IMPORT_EXPORT _BaseStartEqtCmd: public _BaseEqtCmd
{
	DECLARE_DYNAMIC( _BaseStartEqtCmd)

protected:

	_BaseStartEqtCmd(               // Constructeur
			_CwBaseEqt *	pCwEqt,
			CW_USHORT		usMode);

	virtual _ProtRet        Treat( void);

	virtual void    OnNack( void);
};


class CW_IMPORT_EXPORT _BaseStopEqtCmd: public _BaseEqtCmd
{
	DECLARE_DYNAMIC( _BaseStopEqtCmd)

protected:

	_BaseStopEqtCmd(                // Constructeur
			_CwBaseEqt *	pCwEqt,
			CW_USHORT		usMode);

	virtual _ProtRet        Treat( void);

	virtual void    OnNack( void);
};



class CW_IMPORT_EXPORT _BaseBrowseEqtCmd : public _BaseEqtCmd
{
	DECLARE_DYNAMIC(_BaseBrowseEqtCmd)

public:
	_BaseBrowseEqtCmd(                // Constructeur
		_CwBaseEqt *	pCwEqt);
protected:

	virtual _ProtRet        Treat(void);
public:
	virtual void    Nack(_ProtError *pError);
	virtual void    Ack(LPCTSTR pDataBuf);
};


//**********************************
//**
//** Commande de niveau Frame
//**
//**********************************


class CW_IMPORT_EXPORT _BaseFrameCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseFrameCmd)

	CW_BOOL m_bNackWithNotifyNoneAccessible;

protected:

		_BaseFrameCmd(                  // Constructeur
			_CwBaseFrame *pCwFrame,
			CW_USHORT    usType,
			CW_USHORT    usMode,
			CW_USHORT    usOrigin,
			CW_USHORT    usCmdLstLvl,
			CW_BOOL      bHighPriority = CW_FALSE,
			CW_BOOL      bConditionnel = CW_FALSE,
			CW_USHORT    usTable = CW_TABLE_IMAGE,
			CW_USHORT    usRange = CW_RANGE_GLOBAL,
			CW_ULONG     ulStartPosition = 0L,
			CW_ULONG     ulLength = 0L);

	void    OnSetTimeOutError( void);

	virtual void    OnSetInProgress( void);
	virtual void    OnResetInProgress( void);

	virtual void    OnAck( void);
	virtual void    OnNack( void);
//      virtual void    OnAckAbort( _ProtError *pErr);
//      virtual void    OnNotProcess( void);

	virtual CW_USHORT       WriteResponseCmd( void);

public:

	virtual CW_USHORT       FatalTest( void);
};


class CW_IMPORT_EXPORT _BaseStartFrameCmd: public _BaseFrameCmd
{
	DECLARE_DYNAMIC( _BaseStartFrameCmd)

protected:

	_BaseStartFrameCmd(     // Constructeur
			_CwBaseFrame *	pCwFrame,
			CW_USHORT			usMode);

	virtual _ProtRet        Treat( void);

	virtual void    OnNack( void);
};


class CW_IMPORT_EXPORT _BaseStopFrameCmd: public _BaseFrameCmd
{
	DECLARE_DYNAMIC( _BaseStopFrameCmd)

protected:

	_BaseStopFrameCmd(              // Constructeur
			_CwBaseFrame *	pCwFrame,
			CW_USHORT		usMode);

	virtual _ProtRet        Treat( void);

	virtual void    OnNack( void);
};



class CW_IMPORT_EXPORT _BaseReadWriteCmd: public _BaseFrameCmd
{
	DECLARE_DYNAMIC( _BaseReadWriteCmd)

protected:

	_BaseReadWriteCmd(              // Constructeur
		_CwBaseFrame *pCwFrame,
		CW_USHORT    usType,
		CW_BOOL      bSynchrone,
		CW_BOOL      bCyclic,
		CW_USHORT    usActionCode,
		CW_USHORT    usRange = CW_RANGE_GLOBAL,
		CW_ULONG     ulStartPosition = 0L,
		CW_ULONG     ulLength = 0L);

	virtual void    OnExtract( void);
	virtual void    OnSetInProgress( void);
	virtual void    OnResetInProgress( void);

public:

	virtual void    OnFailedLinking( CW_USHORT usCmdListLevel);
	virtual void    OnSuccessedLinking( void);

public:

	virtual CW_USHORT       FatalTest( void);
};


class CW_IMPORT_EXPORT _BaseReadCmd: public _BaseReadWriteCmd
{
	DECLARE_DYNAMIC( _BaseReadCmd)

private:
	static _LinkSingleList  *m_llSpool;
	//#MODIFJS 23/02/98
	static _CriticalSection *m_lSpoolLock;

public:

	static void       SpoolInitialize( void);
	static void       SpoolTerminate( void);

	void *operator    new( size_t);
	void operator     delete( void *);

protected:

	_BaseReadCmd(                   // Constructeur
		_CwBaseFrame *pCwFrame,
		CW_BOOL bSynchrone,
		CW_BOOL bCyclic,
		CW_USHORT usActionCode);

	_BaseReadCmd(                   // Constructeur
		_CwBaseFrame *pCwFrame,
		CW_BOOL bSynchrone,
		CW_BOOL bCyclic,
		CW_USHORT usActionCode,
		CW_ULONG ulIndex,
		CW_ULONG ulSize);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void);
	virtual void            OnNack( void);
//      void    OnAbort( void);

public:

	virtual void    Ack( void * pDataBuf);
	virtual void    Ack( CW_ULONG Index, CW_ULONG DataSize, CW_LP_VOID pDataBuf);
};


class CW_IMPORT_EXPORT _BaseWriteCmd: public _BaseReadWriteCmd
{
	DECLARE_DYNAMIC( _BaseWriteCmd)

protected:

	BOOL m_bWithCallback; //#MODIFFRM 28/04/03

	_BaseWriteCmd(                  // Constructeur
		_CwBaseFrame *pCwFrame,
		CW_BOOL bSynchrone,
		CW_BOOL bCyclic,
		CW_USHORT usActionCode);

	_BaseWriteCmd(                  // Constructeur
		_CwBaseFrame *pCwFrame,
		CW_BOOL bSynchrone,
		CW_BOOL bCyclic,
		CW_USHORT usActionCode,
		CW_ULONG ulIndex,
		CW_ULONG ulSize);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void);
	virtual void            OnNack( void);
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseNetworkInitializeCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseNetworkInitializeCmd)

protected:

	_AD * m_ad;

public:

	_BaseNetworkInitializeCmd( // Constructeur
		_CwBaseNetwork *	pCwNetwork,
		_AD *				ad,
		CW_USHORT			usMode);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseNetworkTerminateCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseNetworkTerminateCmd)

public:

	_BaseNetworkTerminateCmd( // Constructeur
		_CwBaseNetwork *	pCwNetwork,
		CW_USHORT			usMode);


	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseEqtInitializeCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseEqtInitializeCmd)

protected:

	_AD * m_ad;

public:

	_BaseEqtInitializeCmd( // Constructeur
		_CwBaseEqt *	pCwEqt,
		_AD *			ad,
		CW_USHORT		usMode);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseEqtTerminateCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseEqtTerminateCmd)

public:

	_BaseEqtTerminateCmd( // Constructeur
		_CwBaseEqt *	pCwEqt,
		CW_USHORT		usMode);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseFrameInitializeCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseFrameInitializeCmd)

protected:

	_AD * m_ad;

public:

	_BaseFrameInitializeCmd( // Constructeur
		_CwBaseFrame *	pCwFrame,
		_AD *			ad,
		CW_USHORT		usMode);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}

	void NotifyCompleted( void); 
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseFrameTerminateCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseFrameTerminateCmd)

public:

	_BaseFrameTerminateCmd( // Constructeur
		_CwBaseFrame * pCwFrame,
		CW_USHORT		usMode);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}

	void NotifyCompleted( void){	m_Frame->AfterTerminate(); }; 
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseNetworkStartCyclicCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseNetworkStartCyclicCmd)

public:

	_BaseNetworkStartCyclicCmd( // Constructeur
		_CwBaseNetwork * pCwNetwork);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseNetworkStopCyclicCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseNetworkStopCyclicCmd)

public:

	_BaseNetworkStopCyclicCmd( // Constructeur
		_CwBaseNetwork * pCwNetwork);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseEqtStartCyclicCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseEqtStartCyclicCmd)

public:

	_BaseEqtStartCyclicCmd( // Constructeur
		_CwBaseEqt * pCwEqt);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseEqtStopCyclicCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseEqtStopCyclicCmd)

public:

	_BaseEqtStopCyclicCmd(
		_CwBaseEqt * pCwEqt);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseFrameStartCyclicCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseFrameStartCyclicCmd)

public:

	_BaseFrameStartCyclicCmd(
		_CwBaseFrame * pCwFrame);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseFrameStopCyclicCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseFrameStopCyclicCmd)

public:

	_BaseFrameStopCyclicCmd(
		_CwBaseFrame * pCwFrame);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseNetworkStartUnsolicitedCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseNetworkStartUnsolicitedCmd)

public:

	_BaseNetworkStartUnsolicitedCmd(
		_CwBaseNetwork * pCwNetwork);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseNetworkStopUnsolicitedCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseNetworkStopUnsolicitedCmd)

public:

	_BaseNetworkStopUnsolicitedCmd(
		_CwBaseNetwork * pCwNetwork);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseEqtStartUnsolicitedCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseEqtStartUnsolicitedCmd)

public:

	_BaseEqtStartUnsolicitedCmd( // Constructeur
		_CwBaseEqt * pCwEqt);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseEqtStopUnsolicitedCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseEqtStopUnsolicitedCmd)

public:

	_BaseEqtStopUnsolicitedCmd(
		_CwBaseEqt * pCwEqt);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseFrameStartUnsolicitedCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseFrameStartUnsolicitedCmd)

public:

	_BaseFrameStartUnsolicitedCmd(
		_CwBaseFrame * pCwFrame);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseFrameStopUnsolicitedCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseFrameStopUnsolicitedCmd)

public:

	_BaseFrameStopUnsolicitedCmd(
		_CwBaseFrame * pCwFrame);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseNetworkMessageCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseNetworkMessageCmd)

	CString m_szMessage;

public:

	_BaseNetworkMessageCmd(
		_CwBaseNetwork * pCwNetwork,
		CW_USHORT        usMode,
		LPCTSTR          szMessage);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseEqtMessageCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseEqtMessageCmd)

	CString m_szMessage;

public:

	_BaseEqtMessageCmd(
		_CwBaseEqt * pCwEqt,
		CW_USHORT    usMode,
		LPCTSTR      szMessage);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseFrameMessageCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseFrameMessageCmd)

	CString m_szMessage;

public:

	_BaseFrameMessageCmd(
		_CwBaseFrame * pCwFrame,
		CW_USHORT      usMode,
		LPCTSTR        szMessage);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseModifyNetworkConfigurationCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseModifyNetworkConfigurationCmd)

	//#MODIFED 13/10/04
	//CString m_szConfiguration;
	CW_CHAR	m_cTabConfiguration[CW_SIZEOF_CONFIG];

public:

	_BaseModifyNetworkConfigurationCmd(
		_CwBaseNetwork * pCwNetwork,
		LPCTSTR          szConfiguration);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseModifyEquipmentConfigurationCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseModifyEquipmentConfigurationCmd)

	//#MODIFED 13/10/04
	//CString m_szConfiguration;
	CW_CHAR	m_cTabConfiguration[CW_SIZEOF_CONFIG];

public:

	_BaseModifyEquipmentConfigurationCmd(
		_CwBaseEqt * pCwEqt,
		CW_LP_CHAR/*LPCTSTR szConfiguration*/);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseModifyEquipmentConfigurationExCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseModifyEquipmentConfigurationExCmd)

	CW_USHORT m_usAddress;
	CString   m_szConfiguration;
	CW_USHORT m_usParamCounter;

public:

	_BaseModifyEquipmentConfigurationExCmd(
		_CwBaseEqt * pCwEqt,
		CW_USHORT    usAddress,
		LPCTSTR      szConfiguration,
		CW_USHORT    usParamCounter);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseModifyFrameConfigurationCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseModifyFrameConfigurationCmd)

	//#MODIFED 13/10/04
	//CString m_szConfiguration;
	CW_CHAR	m_cTabConfiguration[CW_SIZEOF_CONFIG];

public:

	_BaseModifyFrameConfigurationCmd(
		_CwBaseFrame * pCwFrame,
		LPCTSTR        szConfiguration);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

class CW_IMPORT_EXPORT _BaseModifyFrameCyclicPeriodCmd: public _Command
{
	DECLARE_DYNAMIC( _BaseModifyFrameCyclicPeriodCmd)

	MSECS m_msPeriod;

public:

	_BaseModifyFrameCyclicPeriodCmd(
		_CwNGFrame * pCwFrame,
		MSECS        msPeriod);

	virtual _ProtRet        Treat( void);

	virtual void            OnAck( void) {}
	virtual void            OnNack( void) {}
};

/////////////////////////////////////////////////////////////////////////////////

#endif /* _CWCMD_H_ */
