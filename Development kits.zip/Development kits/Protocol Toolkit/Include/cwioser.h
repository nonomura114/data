/*--------------------------------------------------------------------------*/
/*																			*/
/*		PROJECT		:	LIBRAIRIE GENERIQUE D'ACCES A LA COUCHE PHYSIQUE	*/
/*																			*/
/*		MODULE		:	cwioser.h											*/
/*																			*/
/*		VERSION		:	1.00												*/
/*																			*/
/*		SYSTEMES	:	Windows 95 , Windows NT								*/
/*																			*/
/*		AUTHOR		:	Eric PERROTIN										*/
/*																			*/
/*		PURPOSE		:	Classe sp�cifique d'acc�s au port s�rie				*/
/*																			*/
/*--------------------------------------------------------------------------*/


#ifndef _CWIOSERIAL_H_

	#define _CWIOSERIAL_H_


class _CwIO_Serial;
class _CwReadStatThread;
class _CwWriterThread;


// Global defines
#define PURGEFLAGS_DEFAULT	(PURGE_TXABORT | PURGE_TXCLEAR | PURGE_RXABORT | PURGE_RXCLEAR)
#define EVENTFLAGS_DEFAULT	(EV_BREAK | EV_CTS | EV_DSR | EV_ERR | EV_RING | EV_RLSD)

// Field numbers used in _Ad class methods to init. serial port
#define	FIELD_PORTNAME				5
#define	FIELD_BAUDRATE				6
#define	FIELD_BYTESIZE				7
#define	FIELD_PARITY				8
#define	FIELD_STOPBITS				9
#define	FIELD_MODEMSTATUS			10
#define	FIELD_WORKINGMODE			26
#define	FIELD_NBWAITCHAR			27
#define	FIELD_RTSSIGNALSTATUS		30

// Default number of wait char. between the arrival of 2 characters on the line
#define	NBWAITCHAR_DEFAULT			3

// Time-outs
//#define	EQUIPMENT_TIMEOUT			250
//#define	WRITE_CHECK_TIMEOUT			250

// Comm. port buffer sizes
#define MAX_READ_BUFFER_SIZE		4096
#define MAX_WRITE_BUFFER_SIZE		4096

// ReadFile reception buffer size
#define RCV_BUFFER_SIZE				2048

// Number of events to detect in ReadAndStatusRoutine
#define	NUM_READSTAT_HANDLES		3

// Number of events to detect in WriteRoutine
#define	NUM_WRITE_HANDLES			2

// Stop Bit
#define	ONE_STOP_BIT				0
#define	ONE_HALF_STOP_BIT			1
#define	TWO_STOP_BIT				2

// Services ret code
#define	CW_ABORT					9
#define	CW_TO_RECEPTION				6



//******************************
//
//	_CwReadStatThread Class
//
//******************************
class _CwReadStatThread: public _CwThread
{
public:
	_CwIO_Serial		*m_CwIOSerial;

	OVERLAPPED			m_osStatus;				// Structure for status operations
	OVERLAPPED			m_osRead;				// Structure for read operations

	_Event				*m_hReaderEvent;		// Reception request event
	_Event				*m_hReaderOkEvent;		// Reception completed ok
	_Event				*m_hReaderToRcvEvent;	// Reception time-out
	_Event				*m_hReaderAbortEvent;	// Reception failed
	_Event				*m_hStatusEvent;		// Status request event

	CW_BOOL				m_bWaitingOnStat;		// True if status operation is pending
	CW_BOOL				m_bWaitingOnRead;		// True if read operation is pending

	CW_UCHAR			m_lpszWorkingRcvBuf[RCV_BUFFER_SIZE]; // Working Buffer of reception
	CW_USHORT			m_usWorkingRcvBufSize;	// Number of bytes read

	CW_LP_UCHAR			m_lpszRcvBuf;			// Buffer of reception
	CW_USHORT			m_usRcvBufSize;			// Reception buffer size

	CW_USHORT			m_index_rcv_courant;	// Current index of reception buffer
	CW_USHORT			m_index_rcv_max;		// Max index of reception buffer

	CW_VOID				SetRcvBuf( CW_LP_UCHAR );
	CW_VOID				SetCarInRcvBuf( CW_USHORT, CW_UCHAR );
	CW_LP_UCHAR			GetRcvBuf( CW_VOID );
	CW_UCHAR			GetCarInRcvBuf( CW_USHORT );
	CW_VOID				SetRcvBufSize( CW_USHORT );
	CW_USHORT			GetRcvBufSize( CW_VOID );

	CW_VOID				SetCarInWorkingRcvBuf( CW_USHORT, CW_UCHAR );
	CW_UCHAR			GetCarInWorkingRcvBuf( CW_USHORT );
	CW_LP_UCHAR			GetWorkingRcvBuf(CW_VOID);
	CW_VOID				SetWorkingRcvBufSize( CW_USHORT );
	CW_USHORT			GetWorkingRcvBufSize( CW_VOID );

	CW_ULONG			m_ulCommEvent;
	CW_VOID				HandleStatusRequest( CW_VOID );
	CW_USHORT			StatusCompletion( CW_VOID );

	CW_USHORT			HandleReadRequest( void);
	//#MODIFJS 24/02/98
	//CW_USHORT			ReadCompletion(	CW_VOID );
	
	CW_VOID				SetIndexRcvMax(CW_USHORT usIndexRcvMax);
	CW_USHORT			GetIndexRcvMax(CW_VOID);
	
	//#MODIFJS 24/02/98
	CW_USHORT           SetIndexRcvCourant( CW_USHORT usIndexRcvCourant);
	CW_USHORT			GetIndexRcvCourant( void);
	CW_USHORT           IncrementIndexRcvCourant( void);
	//#ENDMODIFJS 24/02/98

	CW_ULONG			m_rxTimeOut;			// TimeOut of Read Request
	CW_VOID				SetRxTimeOut( CW_ULONG );
	CW_ULONG			GetRxTimeOut( CW_VOID );
	CW_VOID				SetReadTimeOut( CW_ULONG);

	//
	//	Constructeur / destructeur
	//
	_CwReadStatThread(
		CW_LP_VOID	pCwIO_Serial,
		CW_LP_CHAR	lpszThreadName,	
		CW_ULONG ulWaitStart = DEFAULT_WAIT_START,
		CW_ULONG ulWaitStop = DEFAULT_WAIT_STOP);
	virtual ~_CwReadStatThread( void);

	virtual DWORD	Run( void);
	virtual void	SpecificRun( CW_ULONG ulEvent);
};


//******************************
//
//	_CwWriterThread Class
//
//******************************
class _CwWriterThread: public _CwThread
{
public:
	_CwIO_Serial		*m_CwIOSerial;

	OVERLAPPED			m_osWrite;				// Structure for write operations

	_Event				*m_hWriterEvent;		// Emission request event
	_Event				*m_hWriterOkEvent;		// Emission completed ok
	_Event				*m_hWriterAbortEvent;	// Emission failed
	
	CW_LP_UCHAR			m_lpszSendBuf;			// Buffer of emission
	CW_USHORT			m_usSendBufSize;		// Emission buffer size

	CW_USHORT			HandleWriteRequest( CW_VOID );
	CW_USHORT			WriteCompletion( CW_VOID );

	CW_VOID				SetSendBuf( CW_LP_UCHAR );
	CW_LP_UCHAR			GetSendBuf( CW_VOID );
	CW_VOID				SetSendBufSize( CW_USHORT );
	CW_USHORT			GetSendBufSize( CW_VOID );

	CW_ULONG			m_txTimeOut;			// TimeOut of Write Request 
	CW_VOID				SetTxTimeOut( CW_ULONG );
	CW_ULONG			GetTxTimeOut( CW_VOID );
	CW_VOID				SetWriteTimeOut( CW_ULONG);

	//
	//	Constructeur / destructeur
	//
	_CwWriterThread(
		CW_LP_VOID	pCwIO_Serial,
		CW_LP_CHAR	lpszThreadName,	
		CW_ULONG ulWaitStart = DEFAULT_WAIT_START,
		CW_ULONG ulWaitStop = DEFAULT_WAIT_STOP);
	virtual ~_CwWriterThread( void);

	virtual DWORD	Run( void);
	virtual void	SpecificRun( CW_ULONG ulEvent);
};


//******************************
//
//	_CwIO_Serial Class
//
//******************************
class  _CwIO_Serial :	public _CwIO 
{

	friend _CwWriterThread;
	friend _CwReadStatThread;

//***
//***	GLOBAL MEMBERS
//***
private:
	HANDLE			m_hCommPort;			// Open handle to the comm.port
	CW_BOOL			m_bShareCommPort;		// true if port shared
	CW_LP_VOID		m_lpvSemShareCommPort;	// Acces to port semaphore

    DWORD			m_CommErrors;			// Last comm error flags from ClearCommError()

//***
//***	CONSTRUCTOR & DESTRCTOR
//***
public:
	_CwIO_Serial( _CwBaseNetwork *pNetworkOwner);  //#MODIFJS 10/03/99 - Gestion des param�tres s�ries (Prot. NG)
	virtual ~_CwIO_Serial( CW_VOID );


//***
//***	INIT
//***
private:	
	CW_CHAR			m_lpszPortName[15];	// Pointer to name of comm. port
	CW_CHAR         m_lpszPortUserName[15];

	CW_ULONG		m_ulBaudRate;		// Current baud rate
	CW_UCHAR		m_ucByteSize;		// Number of bits/byte
	CW_UCHAR		m_ucParity;			// Parity
	CW_UCHAR		m_ucStopBits;		// Number of stop bits
	CW_BOOL			m_bModemStatus;		// true if modem status is handled
	CW_BOOL			m_bEnableRtsSignal; // true if rts status is handled
	CW_UCHAR		m_ucNbWaitChar;		// Nb wait char. between the arrival of 2 char.
	CW_ULONG		m_EventMask;		// Mask of events to monitor

	CW_VOID			SetBaudRate( CW_ULONG );
	CW_VOID			SetBaudRate( _Serial_BaudRate esbrBaudRate);
	CW_VOID			SetByteSize( CW_UCHAR );
	CW_VOID			SetByteSize( _Serial_ByteSize esbsByteSize);
	CW_VOID			SetParity( CW_UCHAR );
	CW_VOID			SetParity( CW_LP_CHAR );
	CW_VOID			SetParity( _Serial_Parity espParity);
	CW_VOID			SetStopBits( CW_LP_CHAR );
	CW_VOID			SetStopBits( _Serial_StopBit essbStopBit);
	CW_VOID			SetModemStatus( CW_BOOL );
	CW_VOID			SetRtsSignalStatus( CW_BOOL );
	CW_VOID			SetNbWaitChar( CW_UCHAR );
	CW_VOID			SetEventMask( CW_VOID );

public:
	CW_VOID			SetPortName( CW_LP_CHAR );
	//CW_VOID         SetPortName( _Serial_Port espPort); #MODIFFRM 20/03/01
	CW_VOID         SetPortName( short espPort);
	CW_VOID         SetPortNumber( CW_UCHAR);
	CW_LP_CHAR		GetPortName( CW_VOID );
	CW_LP_CHAR      GetPortUserName( void);
	HANDLE			GetPortHandle( CW_VOID );
	CW_ULONG		GetBaudRate( CW_VOID );
	CW_UCHAR		GetByteSize( CW_VOID );
	CW_UCHAR		GetParity( CW_VOID );
	CW_UCHAR		GetStopBits( CW_VOID );
	CW_BOOL			GetModemStatus( CW_VOID );
	CW_BOOL			GetRtsSignalStatus( CW_VOID );
	CW_UCHAR		GetNbWaitChar( CW_VOID );
	CW_ULONG		GetEventMask( CW_VOID );

	CW_USHORT		Initialize( _AD *);
	CW_VOID			Reset( CW_VOID );	


//***
//***	THREAD
//***
public:
	#define CWIO_READSTAT_NAME	"CwIOReadStat_%s"
	CW_LP_CHAR			m_lpszReadStatName;
	_CwReadStatThread	*m_hReadStatThread;


	#define CWIO_WRITER_NAME	"CwIOWriter_%s"
	CW_LP_CHAR			m_lpszWriterName;
	_CwWriterThread		*m_hWriterThread;


//***
//***	START
//***
private:
	CW_USHORT		CreateCommHandle( CW_VOID );
	CW_VOID			UpdateSettings( CW_VOID );
	CW_USHORT		Open( CW_VOID );

public:		
	CW_USHORT		Start( CW_VOID );



//***
//***	STOP
//***
private:
	CW_VOID			CloseCommHandle( CW_VOID );
	CW_ULONG		Close( CW_VOID );

public:
	CW_VOID			Stop(CW_VOID );


//***
//***	Read and Status methods
//***
public:
	virtual CW_BOOL		ProcessRead( CW_VOID ) = 0;


//***
//***	Modem status and serial status checking
//***	DTR and RTS modem status setting 
//***
public:
	CW_VOID				ReportCommError( CW_VOID );
	CW_VOID				ReportStatusEvent(CW_ULONG );
	CW_VOID				CheckModemStatus(CW_BOOL bUpdateNow);
	CW_VOID				CheckCommStatus(CW_BOOL bUpdateNow);

	CW_VOID				ModemDTR_ON( CW_VOID );
	CW_VOID				ModemDTR_OFF( CW_VOID );
	CW_VOID				ModemRTS_ON( CW_VOID );
	CW_VOID				ModemRTS_OFF( CW_VOID );


//***
//***	SERVICES
//***
public:

	CW_USHORT			SendFrame( CW_LP_UCHAR, CW_USHORT, CW_ULONG );
	CW_USHORT			RcvFrame( CW_LP_UCHAR, CW_USHORT, CW_ULONG );
	CW_USHORT			SendRcvFrame( CW_LP_UCHAR, CW_USHORT, CW_LP_UCHAR, CW_USHORT, CW_ULONG );

	CW_USHORT			SendBreak( CW_USHORT );
	CW_USHORT			SendBreakRcvFrame( CW_USHORT, CW_LP_UCHAR, CW_USHORT, CW_ULONG );


//***
//*** GESTION DES ERREURS
//***
protected:

	CW_BOOL				CwIOClear_Errors( CW_LP_ULONG pdwErrors, LPCOMSTAT pcomStat);

	// Signalisation d'erreurs en r�ception

	CW_VOID				CwIOSet_RX_TIMEOUT_Error( CW_VOID);
	CW_VOID				CwIOSet_RX_OVERRUN_Error( CW_VOID);
	CW_VOID				CwIOSet_RX_PARITY_Error( CW_VOID);
	CW_VOID				CwIOSet_RX_FRAME_Error( CW_VOID);
	CW_VOID				CwIOSet_RX_BREAK_Error( CW_VOID);
	CW_VOID				CwIOSet_RX_OVERFLOW_Error( CW_VOID);
	
	// Signalisation d'erreurs en �mission

	CW_VOID				CwIOSet_TX_TIMEOUT_Error( CW_VOID);
	CW_VOID				CwIOSet_TX_FULL_Error( CW_VOID);


	//#MODIFJS 15/06/98 D�lai inter-trame

//***
//*** GESTION DU DELAI INTER-TRAME
//***

protected:

	CW_ULONG      m_ulInterFrameDelayValue;
	_Event        *m_evInterFrameDelayEvent;

private:
	BOOL m_bStopped;

public:
	BOOL GetStopped() { return m_bStopped; };

};

#endif