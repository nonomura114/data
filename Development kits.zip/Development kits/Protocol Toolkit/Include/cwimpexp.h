
#ifndef _CWIMPEXP_H_

	#define _CWIMPEXP_H_

/*	#ifdef CW_IMPLEMENTATION
		#define CW_IMPORT_EXPORT _declspec( dllexport)
	#else
		#define CW_IMPORT_EXPORT _declspec( dllimport)
	#endif

    #define CW_STANDARD_IMPORT_EXPORT CW_IMPORT_EXPORT WINAPI

	#define CW_IMPORT _declspec( dllimport)
	#define CW_EXPORT	_declspec( dllexport)
*/

	#define CW_IMPORT_EXPORT 
    #define CW_STANDARD_IMPORT_EXPORT CW_IMPORT_EXPORT WINAPI

	#define CW_IMPORT
	#define CW_EXPORT

 	#ifdef __cplusplus
 		#define CW_C_IMPORT_EXPORT extern "C" CW_IMPORT_EXPORT
		#define CW_C_EXPORT			extern "C" CW_EXPORT
 	#else
 		#define CW_C_IMPORT_EXPORT CW_IMPORT_EXPORT
		#define CW_C_EXPORT			CW_EXPORT
	#endif

	#define CW_FCT	CW_USHORT CW_STANDARD_IMPORT_EXPORT
	#define CW_SUB	void CW_STANDARD_IMPORT_EXPORT

#endif
