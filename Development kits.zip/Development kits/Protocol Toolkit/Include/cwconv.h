#ifndef _CWCONV_H_

	#define _CWCONV_H_

	CW_C_IMPORT_EXPORT int SZtoINT(
		const char *pszNumber,
		const char **ppszStopScan = NULL,
		int nBase = 10);

	CW_C_IMPORT_EXPORT unsigned int SZtoUINT(
		const char *pszNumber,
		const char **ppszStopScan = NULL,
		int nBase = 10);

	CW_C_IMPORT_EXPORT long SZtoLONG(
		const char *pszNumber,
		const char **ppszStopScan = NULL,
		int nBase = 10);

	CW_C_IMPORT_EXPORT unsigned long SZtoULONG(
		const char *pszNumber,
		const char **ppszStopScan = NULL,
		int nBase = 10);

	CW_C_IMPORT_EXPORT long GetBinDigits(
		const char * pchData,
		int nOffset,
		int nLength);

	CW_C_IMPORT_EXPORT long GetDecDigits(
		const char * pchData,
		int nOffset,
		int nLength);

	CW_C_IMPORT_EXPORT long GetHexDigits(
		const char * pchData,
		int nOffset,
		int nLength);

	
	// Conversion ASC
	CW_C_IMPORT_EXPORT CW_USHORT ASCtoUCHAR(
		CW_LP_BYTE lpszBuffer,
		CW_UCHAR *pucUCHAR);

	CW_C_IMPORT_EXPORT CW_USHORT ASCtoUSHORT(
		CW_LP_BYTE lpszBuffer,
		CW_USHORT *pusUSHORT);

	CW_C_IMPORT_EXPORT CW_USHORT ASCtoULONG(
		CW_LP_BYTE lpszBuffer,
		CW_ULONG *pulULONG);

	CW_C_IMPORT_EXPORT CW_USHORT UCHARtoASC(
		CW_UCHAR ucUCHAR,
		CW_UCHAR *pucASC);

	CW_C_IMPORT_EXPORT CW_USHORT USHORTtoASC(
		CW_USHORT usUSHORT,
		CW_USHORT *pusASC);

	CW_C_IMPORT_EXPORT CW_USHORT ULONGtoASC(
		CW_ULONG ulULONG,
		CW_ULONG *pulASC);

	// Conversion BCD
	CW_C_IMPORT_EXPORT CW_USHORT BCDtoUCHAR(
		CW_UCHAR ucBCD,
		CW_UCHAR *pucUCHAR);

	CW_C_IMPORT_EXPORT CW_USHORT BCDtoUSHORT(
		CW_USHORT usBCD,
		CW_USHORT *pusUSHORT);

	CW_C_IMPORT_EXPORT CW_USHORT BCDtoULONG(
		CW_ULONG ulBCD,
		CW_ULONG *pulULONG);

	CW_C_IMPORT_EXPORT CW_USHORT UCHARtoBCD(
		CW_UCHAR ucUCHAR,
		CW_UCHAR *pucBCD);

	CW_C_IMPORT_EXPORT CW_USHORT USHORTtoBCD(
		CW_USHORT usUSHORT,
		CW_USHORT *pusBCD);

	CW_C_IMPORT_EXPORT CW_USHORT ULONGtoBCD(
		CW_ULONG ulULONG,
		CW_ULONG *pulBCD);


	// Conversion MSB-LSB
	CW_C_IMPORT_EXPORT CW_USHORT SwapQuartetInByte(
		CW_UCHAR ucOrigin,
		CW_UCHAR *pucTarget);

	CW_C_IMPORT_EXPORT CW_USHORT SwapByteInWord(
		CW_USHORT usOrigin,
		CW_USHORT *pusTarget);

//#MODIFFRM 12/07/00
	CW_IMPORT_EXPORT CW_USHORT SwapWordInDWord(
		CW_ULONG ulOrigin,
		CW_LP_ULONG pulTarget);

	CW_IMPORT_EXPORT CW_USHORT SwapWordInDWord(
		CW_ULONG *ulOriginTarget);

	CW_IMPORT_EXPORT CW_USHORT SwapWordInDWords(
		CW_LP_ULONG pulOrigin,
		CW_LP_ULONG pulTarget,
		CW_USHORT usQuantity);

	CW_IMPORT_EXPORT CW_USHORT SwapWordInDWords(
		CW_LP_ULONG ulOriginTarget,
		CW_USHORT usQuantity);
//#ENDMODIFFRM 12/07/00

	// Conversion UCHAR-HEXA_STRING
	CW_C_IMPORT_EXPORT const CW_CHAR *const UCHAR_to_HEXASTRING(
		CW_BYTE ucValue);

#endif // _CWCONV_H_
