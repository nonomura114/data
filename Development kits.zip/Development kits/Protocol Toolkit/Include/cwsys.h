
#ifndef _CWSYS_H_

	#define _CWSYS_H_

	//------------------------------------------------------------------
	// Calcul du temps pass�

	typedef CW_ULONG MSECS;

	CW_C_IMPORT_EXPORT MSECS cwGetAccurateTime( void);
	CW_C_IMPORT_EXPORT MSECS cwGetElapsedTime( MSECS msStartTime);
	//
	//------------------------------------------------------------------
	


	//------------------------------------------------------------------
	// Calcul du temps pass� dans un thread
	// ne fonctionne que sous Windows NT
	// Les services WIN32 mis en oeuvre n'etant pas implemente en WIN95

	struct _ThreadTime
	{
		HANDLE   hThread;
		FILETIME ftKernelTimeStart;
		FILETIME ftUserTimeStart;
	};

	// Positionnement du chrono
	CW_C_IMPORT_EXPORT void cwSetThreadTimeStart(
		_ThreadTime *ThreadTime);	

	// Temps ecoule depuis le positionnement du chrono
	// Resultat: Compteur 64 bits en multiple de 100 nanosecondes
	CW_C_IMPORT_EXPORT __int64 cwGetThreadElapsedTime(
		_ThreadTime *ThreadTime);
	//
	//------------------------------------------------------------------



	//------------------------------------------------------------------
	// Calcul du temps pass� dans un process
	// ne fonctionne que sous Windows NT
	// Les services WIN32 mis en oeuvre n'etant pas implemente en WIN95

	struct _ProcessTime
	{
		HANDLE   hProcess;
		FILETIME ftKernelTimeStart;
		FILETIME ftUserTimeStart;
	};

	// Positionnement du chrono
	CW_C_IMPORT_EXPORT void cwSetProcessTimeStart(
		_ProcessTime *ProcessTime);	

	// Temps ecoule depuis le positionnement du chrono
	// Resultat: Compteur 64 bits en multiple de 100 nanosecondes
	CW_C_IMPORT_EXPORT __int64 cwGetProcessElapsedTime(
		_ProcessTime *ProcessTime);
	//
	//------------------------------------------------------------------



	//------------------------------------------------------------------
	// Fonction d'allocation et de lib�ration de m�moire
	// sans la surcharge DEBUG

	void *_malloc_nodbg( size_t size);

	void _free_nodbg( void *who);
	//
	//------------------------------------------------------------------

#endif
