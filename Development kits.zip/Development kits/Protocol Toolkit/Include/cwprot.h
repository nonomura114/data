
#ifndef _CWPROT_H_

	#define _CWPROT_H_

#include "cwprotb.h"


class _TimDat;

class _ProtNetwork;
class _ProtEqt;
class _ProtFrame;

class _CwNetwork;
class _CwEqt;
class _CwFrame;

struct _ProtError;
struct _ProtInfo;


// ----------------- Prototype des fonctions ------------------

CW_C_EXPORT _ProtNetwork *CreateProtNetwork( CW_USHORT usType);
CW_C_EXPORT _ProtEqt     *CreateProtEqt( CW_USHORT usType);
CW_C_EXPORT _ProtFrame   *CreateProtFrame( CW_USHORT usProtocolDataType, CW_USHORT usCwDataType);
CW_C_EXPORT void         GetProtocolVersion( struct _CwVersion *pProtInfo);


// --------------------- Les constantes -----------------------

//
//	Compte-rendu immediat sur les commandes Cimway
//
//	enum _ProtRet
//	{
//		Commande traitee avec ou sans erreur
//		PR_CMD_PROCESSED       = 0,
//
//		Commande non-traitee par le protocole a cet instant
//		PR_CMD_NOT_PROCESSED   = 1,
//
//		Commande non-traitee par le protocole de fa�on definitive
//		PR_CMD_NEVER_PROCESSED = 2	
//	};
//

//
// Le mode des commandes cycliques
//
enum _CyclicMode
{
	CM_READ  = 0, // Lecture

	CM_WRITE = 1  // Ecriture
};


// --------------------- Les structures -----------------------

//
// Structure liee a l'acces des tables Cimway
//
struct _ProtPartialDataTable
{
	CW_ULONG   Index;    // Index dans la table
	                     // Il est exprime dans le type de donnees Cimway
	                     // Commence a partir de 0
	CW_ULONG   DataSize; // Nombre de donnees
	                     // Ce nombre est exprime dans le type
	                     // de donnees Cimway
	CW_LP_VOID pData;    // Pointeur sur les donnees
};


//
// Format des valeurs des variables remontees par le protocole
//
//	union _CwItemValue
//	{
//		CW_BOOL  log;      // Etat
//		CW_BYTE  ana8b;    // Analogique codee sur un entier 8 bits
//		CW_WORD  ana16b;   // Analogique codee sur un entier 16 bits
//		CW_DWORD ana32b;   // Analogique codee sur un entier 32 bits
//		CW_REAL  anaFloat; // Analogique codee
//		                   // sur un reel IEEE simple precision ( 32 bits)
//		CW_DWORD dwRaw;    // Valeur brute
//	};
//
#define _ProtValue	_CwItemValue

//
// Format du status des variables remontee par le protocole
//
//	union _CwProtocolItemStatus
//	{
//		struct
//		{
//			unsigned char bOutDating : 1; // Indique si l'horodatage est
//			                              // effectue par le protocole
//			unsigned char bNA        : 1; // Indique si une donnee est devenue
//			                              // non-accessible
//			unsigned char bReserve   : 6;	// Reserve
//		} Flags;
//	
//		CW_UCHAR ucRaw;
//	};
//	
#define _ProtStatus	_CwProtocolItemStatus


//
// Structures liees a la remontee evenementielle des donnees
//

struct _ProtUnsolicitedData
{
	CW_ULONG    Address;      // Adresse de la donnee dans l'equipement
	CW_USHORT   ProtDataType; // Type de donnees de l'equipement
	_ProtValue  Value;        // Valeur
	_TimDat     hdate;        // Horodate
	_ProtStatus Status;       // Status
};


struct _ProtSetUnsolicitedData
{
	CW_ULONG             NbData;            // Nombre de donnees
	_ProtUnsolicitedData *pUnsolicitedData; // Pointeur sur les donnees
};


// ------------------------ Les classes -----------------------


// -------------- La classe reseau du protocole ---------------

class CW_IMPORT_EXPORT _ProtNetwork: public CObject
{
	// Attributs

public:

	_CwNetwork  *m_pCwNetwork;          // Pointeur sur l'objet
	                                    // reseau de Cimway
	CW_BYTE     m_Reserve[ 32];

	// Methodes

public:

		_ProtNetwork( void);             // Constructeur
		virtual ~_ProtNetwork( void);            // Destructeur

	// Method which activates the protocol (ex valid_rcp_car in blank protcol)
	virtual CW_VOID	NotifyRcvData(	CW_LP_UCHAR rxBuffer, 
									CW_USHORT *usIndex_rcv_max, 
									CW_USHORT *usIndex_rcv_current);

	virtual CW_USHORT GetFluxManagement( void);

	virtual _ProtEqt *CreateProtEqt(    // Creer l'objet equipement
		CW_USHORT usType);               // Type d'equipement

	virtual void     OnInitialize(      // Initialiser
		_AD *adFile);                    // Ligne ASCII du COMM.DAT

	virtual void     OnTerminate(       // Finir l'utilisation
		void);

	// Les commandes

		// Les Asynchrones

	virtual _ProtRet Start_Async(       // Demarrer le reseau
		_ProtStartNetworkCmd *pStartNetworkCmd);

	virtual _ProtRet Stop_Async(        // Arreter le reseau
		_ProtStopNetworkCmd *pStopNetworkCmd);

	virtual _ProtRet CyclicScan_Async(  // Scruter le reseau
	                                    // Activee toutes les 50 ms
		_ProtCyclicScanCmd *pCyclicScanCmd);

	virtual _ProtRet Browse_Async(_ProtBrowseNetworkCmd *pBrowseNetworkCmd);

	virtual _ProtRet BrowseNetworkDevice_Async(_ProtBrowseNetworkDeviceCmd *pBrowseNetworkDeviceCmd);

		// Les Synchrones

	virtual void StartReadCyclic_Sync(  // Demarrer les cycliques
	                                    // de lecture
		void);

	virtual void StopReadCyclic_Sync(   // Arreter les cycliques
	                                    // de lecture
		void);

	virtual void StartWriteCyclic_Sync( // Demarrer les cycliques
	                                    // d'ecriture
		void);

	virtual void StopWriteCyclic_Sync(  // Arreter les cycliques
	                                    // d'ecriture
		void);

	virtual void StartWatchUnsolicitedData_Sync(
	                                    // G�rer la gestion des
	                                    // donnees non-solicitees
		void);

	virtual void StopWatchUnsolicitedData_Sync(
	                                    // Ne plus g�rer la gestion
	                                    // des donnees non-solicitees
		void);	

	virtual void AbortStartNetworkCmd_Sync(
	                                    // Commande de demarrage
	                                    // est abandonnee ( time-out, ...)
		_ProtStartNetworkCmd *pStartNetworkCmd);
	                                    // Pointeur sur la commande
	                                    // abandonee

	virtual void AbortStopNetworkCmd_Sync(
	                                    // Commande de d'arret
	                                    // est abandonnee ( time-out, ...)
		_ProtStopNetworkCmd *pStopNetworkCmd);
	                                    // Pointeur sur la commande
	                                    // abandonee

	virtual void AbortCyclicScanCmd_Sync(
	                                    // Commande de scrutation
	                                    // est abandonnee ( time-out, ...)
		_ProtCyclicScanCmd *pCyclicScanCmd);
	                                    // Pointeur sur la commande
	                                    // abandonee

    virtual void AbortBrowseNetworkCmd_Sync(
                                        // Commande de scrutation
                                        // est abandonnee ( time-out, ...)
        _ProtBrowseNetworkCmd *pBrowseCmd);
                                        // Pointeur sur la commande
                                        // abandonee

	virtual void ModifyConfiguration_Sync( // Modifier la configuration
		CW_LP_CHAR  lpszConfigBuffer);

	virtual void OnReceiveMessage_Sync(
		CW_LPC_CHAR  szMessage);

	NETWORK_FCT_RESERVED                // Reserve
};



// ------------ La classe equipement du protocole -------------

class CW_IMPORT_EXPORT _ProtEqt: public CObject
{
	// Attributs

public:

	_CwEqt		*m_pCwEqt;              // Pointeur sur l'objet
	                                    // eqt de Cimway
	CW_BYTE		m_Reserve[ 32];

	// Methodes

public:

		_ProtEqt( void);                 // Constructeur
		virtual ~_ProtEqt( void);                // Destructeur

	virtual _ProtFrame *CreateProtFrame(  // Creer l'objet trame
		CW_USHORT usProtocolDataType,     // Type de trame
		                                  // ( = type de donnees protocole)
		CW_USHORT usCwDataType);          // Type de donn�es CW

	virtual void     OnInitialize(        // Initialiser
		_AD *adFile);                      // Ligne ASCII du COMM.DAT

	virtual void     OnTerminate(         // Finir l'utilisation
		void);

	// Les commandes

		// Les Asynchrones

	virtual _ProtRet Start_Async(         // Demarrer l'equipement
		_ProtStartEqtCmd *pStartEqtCmd);

	virtual _ProtRet Stop_Async(          // Arreter l'equipement
		_ProtStopEqtCmd *pStopEqtCmd);

	virtual _ProtRet BrowseDevice_Async(          // Arreter l'equipement
		_ProtBrowseEqtCmd *pBrowseEqtCmd);

		// Les Synchrones

	virtual void StartReadCyclic_Sync(    // Demarrer les cycliques
	                                      // de lecture
		void);

	virtual void StopReadCyclic_Sync(     // Arreter les cycliques
	                                      // de lecture
		void);

	virtual void StartWriteCyclic_Sync(   // Demarrer les cycliques
	                                      // d'ecriture
		void);

	virtual void StopWriteCyclic_Sync(    // Arreter les cycliques
	                                      // d'ecriture
		void);

	virtual void StartWatchUnsolicitedData_Sync(
	                                      // G�rer la gestion des
	                                      // donnees non-solicitees
		void);

	virtual void StopWatchUnsolicitedData_Sync(
	                                      // Ne plus g�rer la gestion
	                                      // des donnees non-solicitees
		void);	


	virtual void AbortStartEqtCmd_Sync(	  // Commande de demarrage de
	                                      // l'eqt est abandonnee
		_ProtStartEqtCmd *pStartEqtCmd);   // Pointeur sur la commande
	                                      // abandonnee

	virtual void AbortStopEqtCmd_Sync(    // Commande d'arret de
	                                      // l'eqt est abandonnee
		_ProtStopEqtCmd *pStopEqtCmd);     // Pointeur sur la commande
	                                      // abandonnee


	// Divers

	virtual void ModifyConfiguration_Sync( // Modifier la configuration
		CW_LP_CHAR  lpszConfigBuffer);

	virtual CW_BOOL OnScanObj_Sync(       // Examiner, explorer les attributs
	                                      // Activer par la methode
                                         // ScanEqtObj_Sync de _CwNetwork
		CW_LP_VOID p);                     // Pointeur passe par
                                         // ScanEqtObj_Sync

	virtual void OnReceiveMessage_Sync(
		CW_LPC_CHAR  szMessage);

	EQT_FCT_RESERVED                      // Reserve
};


// --------------- La classe trame du protocole -----------------

class CW_IMPORT_EXPORT _ProtFrame: public CObject
{
	// Attributs

public:

	_CwFrame  *m_pCwFrame;    // Pointeur sur l'objet Frame de Cimway
	CW_BYTE   m_Reserve[ 32];

	// Methodes

public:

		_ProtFrame( void);                 // Constructeur
		virtual ~_ProtFrame( void);                // Destructeur

	virtual void     OnInitialize(        // Initialiser
		_AD *adFile);                      // Ligne ASCII du COMM.DAT

	virtual void     OnTerminate(         // Finir l'utilisation
		void);

	// Les commandes

		// Les Asynchrones

	virtual _ProtRet Start_Async(         // Demarrer la trame
		_ProtStartFrameCmd *pStartFrameCmd);

	virtual _ProtRet Stop_Async(          // Arreter la trame
		_ProtStopFrameCmd *pStopFrameCmd);

	virtual _ProtRet Read_Async(          // Lire
		_ProtReadCmd *pReadCmd);

	virtual _ProtRet Write_Async(         // Ecrire
		_ProtWriteCmd *pWriteCmd);


		// Les Synchrones

	virtual void StartReadCyclic_Sync(    // Demarrer la cyclique
	                                      // de lecture
		void);

	virtual void StopReadCyclic_Sync(     // Arreter la cyclique
	                                      // de lecture
		void);

	virtual void StartWriteCyclic_Sync(   // Demarrer la cyclique
	                                      // d'ecriture
		void);

	virtual void StopWriteCyclic_Sync(    // Arreter la cyclique
	                                      // d'ecriture
		void);

	virtual void ModifyCyclicPeriod_Sync( // Modifier la periode de
	                                      // la cyclique
		const MSECS msPeriod);

	virtual void ModifyConfiguration_Sync( // Modifier la configuration
		CW_LP_CHAR  lpszConfigBuffer);

	virtual void StartWatchUnsolicitedData_Sync(
	                                      // G�rer la gestion des
	                                      // donnees non-solicitees
		void);

	virtual void StopWatchUnsolicitedData_Sync(
	                                      // Ne plus gerer la gestion
	                                      // des donnees non-solicitees
		void);	


	virtual void AbortStartFrameCmd_Sync( // Commande de demarrage de
	                                      // la trame abandonnee
		_ProtStartFrameCmd *pStartFrameCmd);
	                                      // Pointeur sur la commande
	                                      // abandonnee

	virtual void AbortStopFrameCmd_Sync(  // Commande d'arret de la
	                                      // trame abandonnee
		_ProtStopFrameCmd *pStopFrameCmd); // Pointeur sur la commande
	                                      // abandonnee

	virtual void AbortReadCmd_Sync(       // Commande de lecture
	                                      // abandonnee
		_ProtReadCmd *pReadCmd);           // Pointeur sur la commande
	                                      // abandonnee

	virtual void AbortWriteCmd_Sync(		  // Commande d'ecriture
	                                      // abandonnee
		_ProtWriteCmd *pWriteCmd);         // Pointeur sur la commande
	                                      // abandonnee

	// Divers

	virtual CW_BOOL OnScanObj_Sync(       // Examiner, explorer les attributs
	                                      // Activer par la methode
	                                      // ScanFrameObj_Sync de _CwNetwork
		CW_LP_VOID p);                     // Pointeur passe par
                                         // ScanFrameObj_Sync

//#MODIFFRM 30/09/02
	virtual void OnLoad(				// Demande la lecture dans le fichier
										// Celui-ci est d�j� ouvert si pFile != NULL, il sera ferm� par la classe de base
		FILE *pFile);					// Sinon, le fichier n'existe pas

	virtual void OnSave(				// Demande d'�criture dans le fichier
										// Celui-ci est d�j� ouvert si pFile != NULL,  il sera ferm� par la classe de base
		FILE *pFile);					// Sinon, le fichier n'a pas pu �tre cr��.

	virtual BOOL IsPersistant(			// Active ou d�sactive le m�canisme de sauvegarde
										// Par d�faut, le m�canisme est d�sactiv�.
		void);
//#ENDMODIFFRM 30/09/02

	virtual void OnReceiveMessage_Sync(
		CW_LPC_CHAR  szMessage);

	FRAME_FCT_RESERVED                    // Reserve
};

// --------------- Les fonctions de service -------------------
//#MODIFJS 11/03/99 - Gestion du chemin de l'application et du projet
CW_C_IMPORT_EXPORT CW_USHORT GetApplicationPath_Sync( char *lpszApplicationPath);
CW_C_IMPORT_EXPORT CW_USHORT GetProjectPath_Sync( char *lpszProjectPath);
CW_IMPORT_EXPORT CString GetExploitationDataProjectPath_Sync(); //#MODIFFRM 30/09/02

// --------------- La classe reseau de cimway -----------------

class CW_IMPORT_EXPORT _CwNetwork: public _CwNGNetwork
{
	// Attributs

public:

	// Methodes

		_CwNetwork( void);                // Constructeur
		virtual ~_CwNetwork( void);               // Destructeur

public:

	// Les Commandes

	void     StartCmd_Async(             // Demander a Cimway de
                                        // redemarrer le reseau 
                                        // Active l'objet _ProtNetwork
                                        // dans la methode Start_Async
		void);

	void     StopCmd_Async(              // Demander a Cimway d'
                                        // arreter le reseau 
                                        // Active l'objet _ProtNetwork
                                        // dans la methode Stop_Async
		void);

	CW_BOOL  SleepCmd_Sync(              // Demander a Cimway de mettre le
                                        // protocole en attente
		MSECS msDelay);                   // Delai en millisecondes


	// Les erreurs

	void	   SetInvalid_Sync(            // Passer le status du reseau
                                        // invalide et stocker les
                                        // codes d'erreur
		_ProtError *pErr);                // Pointeur sur l'erreur

	void	   SetValid_Sync(              // Passer le status du reseau
                                        // valide
		void);


	// Les services

	CW_BOOL  ScanEqtObj_Sync(            // Balayer les equipements de reseau
                                        // Active les eqts dans la
                                        // methode OnScanObj_Sync
		CW_LP_VOID p);

	CW_BOOL  ScanFrameObj_Sync(          // Balayer les trames du reseau
                                        // Active les trames dans la
                                        // methode OnScanObj_Sync
		CW_LP_VOID p);


	// Lecture d'attributs

	CW_USHORT   GetType_Sync(           // Retourne le type du reseau
		void);

	CW_ULONG    GetNbEqt_Sync(          // Retourne le nombre d'eqt
		void);

	CW_ULONG    GetNbFrame_Sync(        // Retourne le nombre de trame
	                                    // de ce reseau
		void);


	CW_ULONG    GetNbCyclicFrame_Sync(        // Retourne le nombre de trame de ce reseau
	                                    
		void);

	MSECS       GetTimeOut_Sync(        // Retourne la valeur du 
	                                    // time-out (en ms)
		void);

	void         GetID_Sync(          // Retourne l'identifiant du
		CString &csID);               // r�seau au format
	                                  // BOARD.NETWORK

	CW_USHORT   GetSerialParameters_Sync(          // Retourne les parametres
	                                               // du port s�rie
		_Serial_Parameters &spSerialParameters);

	// Lecture d'attributs sp�cifiques

	CW_USHORT   OpenUserAttributes_Sync(
		CW_HANDLE *hUserAttributes);

	CW_USHORT   CloseUserAttributes_Sync(
		CW_HANDLE hUserAttributes);

	CW_USHORT   GetUserAttributes_Sync(
		CW_HANDLE        hUserAttributes,
		CW_USHORT        usIndex,
		CW_ENUMITEMTYPE  itUserAttributesType,
		_CwDataItem      **diUserAttributes);


	// Modification d'attributs

	void        SetNbRetry_Sync(       // Forcer le nombre de tentatives
		CW_USHORT usNbRetry);

	void        SendMessage_Sync(
		CW_LPC_CHAR szMessage);


    bool GetDongleRight_Sync(int  iKey);

};

				
// --------------- La classe equipement de cimway -----------------

class CW_IMPORT_EXPORT _CwEqt: public _CwNGEqt
{
	// Attributs

public:

	// Methodes

		_CwEqt( void);                  // Constructeur
		virtual ~_CwEqt( void);                 // Destructeur

public:

	// Les commandes

	void     StartCmd_Async(           // Demander a Cimway de demarrer
	                                   // l'equipement
	                                   // Active l'objet _ProtEqt dans
	                                   // la methode Start_Async
		void);

	void     StopCmd_Async(            // Demander a Cimway d'arreter
	                                   // l'equipement
	                                   // Active l'objet _ProtEqt dans
	                                   // la methode Stop_Async
		void);

	CW_BOOL  SleepCmd_Sync(            // Demander a Cimway de mettre
	                                   // le protocole en sommeil
		MSECS msDelay);                 // Delai en millisecondes


	// Les erreurs

	void     SetInvalid_Sync(          // Passer le status de l'equipement
	                                   // invalide et stocker les codes
	                                   // d'erreurs
		_ProtError *pErr);              // Pointeur sur l'erreur

	void     SetValid_Sync(            // Passer le status de l'equipement
	                                   // valide
		void);


	// Les actions sur les donnees

//	CW_BOOL  SetUnsolicitedData_Async( // Stocker les donnees
//	                                   // non-solicitees
//		_ProtSetUnsolicitedData *pUnsolicitedData);

	CW_BOOL  SetUnsolicitedData_Sync(  // Stocker les donnees
	                                   // non-solicitees
		_ProtSetUnsolicitedData *pUnsolicitedData);


	// Services

	_ProtNetwork *GetProtNetwork_Sync( // Retourner le pointeur
	                                   // sur ProtNetwork
		void);

	CW_BOOL      ScanFrameObj_Sync(    // Balayer les trames de l'equipement
	                                   // Active les objets _ProtFrame dans
	                                   // la methode OnScan_Sync
		CW_LP_VOID p);


	// Lecture d'attributs

	CW_USHORT    GetType_Sync(         // Retourne le type d'equipement
		void);

	CW_ULONG     GetAddress_Sync(      // Retourne l'adresse de l'eqt
		void);

	CW_ULONG     GetNbFrame_Sync(     // Retourne le nombre de trame
	                                  // de l'equipement
		void);

	CW_ULONG     GetNbCyclicFrame_Sync(     // Retourne le nombre de trame cyclique de l'equipement
	                                  
		void);

	MSECS        GetTimeOut_Sync(     // Retourne la valeur du
	                                  // time_out (en ms)
		void);

	//#MODIFED 12/10/10
	MSECS        GetDeltaTS_Sync(     // Retourne la valeur du
	                                  // Delta TS (en ms) qui permet de savoir si un 
									  //bloc horodat� doit etre gerer par le temps reel ou pas
		void);
	//#ENDMODIF

    //#MODIFED 17/04/13
	CW_USHORT        GetRoutingAddress_Sync(void);     // Retourne l'adresse de routage

	void         GetID_Sync(          // Retourne l'identifiant de
		CString &csID);               // l'�quipement au format
	                                  // BOARD.NETWORK.EQT

	// Lecture d'attributs sp�cifiques

	CW_USHORT   OpenUserAttributes_Sync(
		CW_HANDLE *hUserAttributes);

	CW_USHORT   CloseUserAttributes_Sync(
		CW_HANDLE hUserAttributes);

	CW_USHORT   GetUserAttributes_Sync(
		CW_HANDLE        hUserAttributes,
		CW_USHORT        usIndex,
		CW_ENUMITEMTYPE  itUserAttributesType,
		_CwDataItem      **diUserAttributes);


	// Modification des attributs

	void         SetNbRetry_Sync(     // Forcer le nombre de tentative
		CW_USHORT NbRetry);

	void         SetAvailable_Sync(       // Indiquer que l'�quipement est disponible
		void);

	void         ResetAvailable_Sync(     // Indiquer que l'�quipement est indisponible
		void);

	void  Resynchronize_Sync(
		void);

	void  SendMessage_Sync(
		CW_LPC_CHAR szMessage);
};
			
	
// --------------- La classe trame de cimway -----------------

class CW_IMPORT_EXPORT _CwFrame: public _CwNGFrame
{
	// Attributs

public:

	// Methodes

		_CwFrame( void);               // Constructeur
		virtual ~_CwFrame( void);              // Destructeur

public:

	// Les commandes

	void     StartCmd_Async(          // Demander a Cimway de demarrer
	                                  // la trame.
	                                  // Active l'objet _ProtFrame dans la
	                                  // methode Start_Async
		void);

	void     StopCmd_Async(           // Demander a Cimway d'arreter
	                                  // la trame.
	                                  // Active l'objet _ProtFrame dans la
	                                  // methode Stop_Async
		void);

	CW_BOOL  SleepCmd_Sync(           // Demander a Cimway de mettre
	                                  // le protocole en sommeil
		MSECS msDelay);                // Delai en millisecondes


	// Les erreurs

	void     SetInvalid_Sync(         // Passer le status de la trame
	                                  // invalide et stocker les codes
	                                  // d'erreurs
		_ProtError *pErr);             // Pointeur sur l'erreur

	void     SetValid_Sync(           // Passer le status de la trame
	                                  // valide
		void);


	// Action sur les donnees
	// SetGlobalDataTable
	CW_BOOL  SetGlobalDataTable_Sync(  // Mise a jour globale de la table Cimway
		CW_LP_VOID pDataBuf);          // Pointeur sur les donnees

	CW_BOOL  SetGlobalDataTable_Sync(  // Mise a jour globale de la table Cimway
		CW_LP_VOID pDataBuf,           // Pointeur sur les donnees
		CW_USHORT  usTableType);       // Type de table � mettre � jour

	CW_BOOL  SetGlobalDataTable_Sync(  // Mise a jour globale de la table Cimway
		CW_LP_VOID pDataBuf,           // Pointeur sur les donnees
		_Command   *pCmd);             // Pointeur sur la commande en cours

	CW_BOOL  SetInvalidGlobalDataTable_Sync(  // Mise a jour de la table Cimway
		void);                                // Toutes les valeurs sont invalides

	// SetPartialDataTable
	CW_BOOL	 SetPartialDataTable_Sync( // Mise a jour partielle de la table Cimway
		_ProtPartialDataTable *pPartialDataTable);


	CW_BOOL  SetPartialDataTable_Sync( // Mise a jour partielle de la table Cimway
		_ProtPartialDataTable *pPartialDataTable,
		CW_USHORT             usTableType);       // Type de table � mettre � jour

	CW_BOOL  SetPartialDataTable_Sync(  // Mise a jour partielle de la table Cimway
		_ProtPartialDataTable *pPartialDataTable,
		_Command              *pCmd);             // Pointeur sur la commande en cours

	//#MODIFFRM 22/11/00
	CW_BOOL	 SetPartialDataTableEx_Sync( // Mise a jour partielle de la table Cimway
		_ProtPartialDataTable *pPartialDataTable,
		_TimDat TimeDate);
	//#ENDMODIFFRM 22/11/00

	// GetGlobalDataTable
	CW_BOOL	GetGlobalDataTable_Sync(  // Acquisition globale de la table Cimway
		CW_LP_VOID pDataBuf);         // Pointeur sur les donnees

	CW_BOOL GetGlobalDataTable_Sync(  // Acquisition globale de la table Cimway
		CW_LP_VOID pDataBuf,          // Pointeur sur les donnees
		CW_USHORT  usTableType);      // Type de table � mettre � jour

	CW_BOOL GetGlobalDataTable_Sync(  // Acquisition globale de la table Cimway
		CW_LP_VOID pDataBuf,          // Pointeur sur les donnees
		_Command   *pCmd);            // Pointeur sur la commande en cours

	// GetPartialDataTable
	CW_BOOL GetPartialDataTable_Sync(  // Acquisition partielle de la
	                                   // table Cimway
		_ProtPartialDataTable *pPartialDataTable);

	CW_BOOL GetPartialDataTable_Sync(  // Acquisition partielle de la table Cimway
		_ProtPartialDataTable *pPartialDataTable,
		CW_USHORT             usTableType);       // Type de table � mettre � jour

	CW_BOOL GetPartialDataTable_Sync(  // Acquisition partielle de la table Cimway
		_ProtPartialDataTable *pPartialDataTable,
		_Command              *pCmd);             // Pointeur sur la commande en cours

	// SetUnsolicitedData
	CW_BOOL	SetUnsolicitedData_Sync(  // Stocker les donnees
	                                  // non-solicitees
		_ProtSetUnsolicitedData *pUnsolicitedData);


	// Services

	_ProtEqt     *GetProtEqt_Sync(     // Retourner le pointeur
	                                   // sur ProtEqt
		void);


	// Lecture d'attributs

	CW_USHORT    GetType_Sync(         // Retourne le type de la trame
		void);

	MSECS        GetTimeOut_Sync(      // Retourne la valeur du
	                                   // time-out (en ms)
		void);

	void         GetID_Sync(          // Retourne l'identifiant de
		CString &csID);               // la trame au format
	                                  // BOARD.NETWORK.EQT.FRAME

	CW_ULONG     GetAddress_Sync(      // Retourne l'adresse de debut
	                                   // saisie dans le configurateur
		void);

	CW_ULONG     GetDataSize_Sync(     // Retourne le nombre
	                                   // d'information
	                                   // Ce nombre est exprime dans
	                                   // le type de donnees Cimway
		void);

	CW_USHORT    GetCwDataType_Sync(   // Retourne le type de
	                                   // donnees Cimway
		void);

	CW_USHORT    GetProtDataType_Sync( // Retourne le type de
	                                   // donnees equipement
		void);


	// Lecture d'attributs sp�cifiques

	CW_USHORT   OpenUserAttributes_Sync(
		CW_HANDLE *hUserAttributes);

	CW_USHORT   CloseUserAttributes_Sync(
		CW_HANDLE hUserAttributes);

	CW_USHORT   GetUserAttributes_Sync(
		CW_HANDLE        hUserAttributes,
		CW_USHORT        usIndex,
		CW_ENUMITEMTYPE  itUserAttributesType,
		_CwDataItem      **diUserAttributes);


	// Modification d'attributs

	void         SetNbRetry_Sync(      // Forcer le nombre de tentative
		CW_USHORT NbRetry);

	void         Resynchronize_Sync(
		void);

	void         SendMessage_Sync(
		CW_LPC_CHAR szMessage);
};

#endif // _CWPROT_H_
