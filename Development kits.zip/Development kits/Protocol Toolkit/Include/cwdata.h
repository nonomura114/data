#ifndef _CWDATA_H_
#define _CWDATA_H_

//************************************************
//**
//** _CwBaseData
//**
//************************************************

typedef enum
{
	CW_DATA_UPDATED,
	CW_DATA_NOT_UPDATED,
	CW_DATA_UPDATE_ERROR

} _eDataUpdate;

class CW_IMPORT_EXPORT _CwBaseData: public _DefaultObject
{
	DECLARE_DYNAMIC( _CwBaseData)

	//***
	//*** Data - Configuration
	//***

private:

	_CwBaseLink	      	*m_RefreshLink;
	
	_CriticalSection	*m_lpCriticalSection;

protected:

	void              SetRefreshLink( _CwBaseLink *Link);
	virtual void      OnSetRefreshLink( _CwBaseLink *Link);

public:

	//#MODIFDL 04/03/98
	CW_BOOL           m_FirstUpDate;

	_CwBaseLink       *GetRefreshLink( void);

	void		Lock();
	void		UnLock();

	CW_USHORT GetItemsAttributs( 	// Get attributs of all Items of a Frame
	 	CW_ULONG         *pulNumberItems,   // [out] Number of Items in Frame
		_CwItemAttributs **ppItemAttributs);// [out] Array of Items Attributs.

	CW_USHORT SetItemsAttributs( // Set attributs of Items of a Frame
	 	CW_ULONG         ulNbItems,   	  // [in] Number of Items in Frame
		_CwItemAttributs *pItemAttributs, // [in] Array of Items Attributs.
		CW_RESULT        *pErrors);       // [out] Array of Result.

	CW_USHORT CreateItems(                    // Create User Item of a Frame
		CW_ULONG         ulNumberItems,          // [in] The number of Item to create
		_CwItemCreation  *pItemCreation,         // [in] Array of Item creation attributes
		_CwItemAttributs **ppItemAttributs,      // [out] Array of Items Attributs.
		CW_RESULT        *pErrors);              // [out] Array of Result.

	CW_USHORT SetActiveItemsState(	// Set Items active or inactive
		CW_ULONG	ulNbItems,	// [in] Number of Item to be affected
		CW_HANDLE	*phServer,	// [in] Array of Server items handles.
						// These were returned from AddItem.
		CW_BOOL		bActive,	// [in] CW_TRUE if items are to be 
						// activated, CW_FALSE if items are
						// to be desactivated.
		CW_RESULT	*pErrors);	// [out] Array of Result. Indicates 
						// which Items were sucessfully affected
	
	void OnSetActiveItemTRUE(  // Call when a Item is actif
		_CwBaseItem *pItem);		// Pointer to this item

	void OnSetActiveItemFALSE(  // Call when a Item is passif
		_CwBaseItem *pItem);		// Pointer to this item

protected:

	virtual void      ResetConfiguration( void);


	//***
	//*** Data - Constructor & Destructor
	//***

public:

		_CwBaseData( void);
		virtual ~_CwBaseData( void);

	CW_USHORT         Initialize(
		CW_USHORT   UserId,
		_CwBaseLink *Owner,
		_AD         *adFile);

	void              Terminate( void);

protected:

	virtual void      Reset( void);

	virtual CW_USHORT BeforeInitialize( _AD *adFile);
	virtual CW_USHORT	AfterInitialize( _AD *adFile);

	//***
	//*** Data - Management Routines
	//***

public:

	CW_USHORT         GetInfo( CW_LP_ACT_INFO lpInfo);
	CW_USHORT         GetInfo( CW_LP_TAB_INFO lpInfo);
	CW_USHORT         GetStatus( CW_LP_ACT_STATUS lpStatus);

protected:

	virtual void      OnGetInfo( CW_LP_ACT_INFO lpInfo);
	virtual void      OnGetInfo( CW_LP_TAB_INFO lpInfo);
	virtual void      OnGetStatus( CW_LP_ACT_STATUS lpStatus);


	//***
	//*** Data - Specific Methods
	//***

private:

	CW_LP_VOID              m_lpData;       // User Table
	CW_LP_VOID              m_lpImage;      // Cache Table
	CW_LPSTMFORMATDATATIME  m_pStreamData;  // Buffer use for notify data change
	CW_ULONG				m_StreamDataSize;	// Sizeof m_pStreamData member
	_CwDataItem *			m_pDataItem;		// Buffer to store one item

protected:

	virtual void      OnAllocDataTable( CW_LP_VOID lpData);
	virtual void      OnAllocImageTable( CW_LP_VOID lpImage);

	CW_USHORT         m_DataType;
	CW_ULONG          m_Size_Word;
	CW_ULONG          m_Size_Byte;
	CW_ULONG          m_Size_Elt;		// Nb d'Items canoniques
	CW_USHORT         m_NbBitsNotUsed;

	CW_BOOL           m_Init;            // mpar.ini

	CW_ULONG          m_ulNbEltInit;

	CW_ULONG          m_ulNbActifItem;	// Nb Item Actif

	CW_ULONG          m_ulNbModif_Table; // para2.xraf & mpar.raf
	CW_ULONG          m_ulNbModif_Field;

	CW_BOOL           m_OutDating;       // para2.dext
	_TimDat           m_HDate;

protected:

	void              SetDataType( CW_USHORT usDataType);
	virtual void      OnSetDataType( CW_USHORT usDataType);

	void              SetDataSize(
		CW_ULONG ulNbElt,
		CW_ULONG ulSizeEltInBit);

	virtual void      SetData( CW_ULONG ulNbElt);
	void              SetInit( void);
	void              ResetInit( void);
	void              IncrementNbModif( void);
	void              ResetNbModif( void);
	void              SetOutDating( void);
	void              ResetOutDating( void);

	virtual void      OnSetData( void);
	virtual void      OnSetInit( void);
	virtual void      OnResetInit( void);
	virtual void      OnIncrementNbModif( void);
	virtual void      OnResetNbModif( void);
	virtual void      OnSetOutDating( void);
	virtual void      OnResetOutDating( void);

	void              SetRefreshDate( void);
	void              SetRefreshDate( _TimDat *HDate);
	virtual void      OnSetRefreshDate( void);
	
	CW_BOOL           Verify_Position_Length(
		_ProtPartialDataTable *pDataTable);


public:

	CW_LP_VOID        GetDataTableAddr( void);
	CW_LP_VOID        GetImageTableAddr( void);

	CW_USHORT         GetDataType( void);
	CW_ULONG          GetSize_Word( void);
	CW_ULONG          GetSize_Byte( void);
	CW_ULONG          GetSize_Elt( void);
	CW_USHORT         GetNbBitsNotUsed( void);
	_CwFrameHeader *  GetStreamData( void);	 
	CW_ULONG          GetNbActiveItem( void);

	CW_BOOL           IsInit( void);
	CW_ULONG          GetNbModif( void);
	CW_BOOL           IsOutDating( void);

	CW_USHORT         UpdateDataTable(
		CW_LP_UPDATE_INFO lpUpdateInfo);

	CW_USHORT         UpdateImageTable( void);

	CW_USHORT         GetLastUpdate(
		CW_USHORT *dd,
		CW_USHORT *mm,
		CW_USHORT *hh,
		CW_USHORT *mn,
		CW_USHORT *msec);

	CW_USHORT         GetLastUpdate(
		CW_LP_LAST_UPDATE lpLastUpdate);

	CW_USHORT         GetGlobalDataTable(
		CW_LP_VOID lpvBuffer,
		CW_USHORT  usTypeTable);

	CW_USHORT         GetPartialDataTable(
		_ProtPartialDataTable *pPartialDataTable,
		CW_USHORT             usTypeTable);

	CW_USHORT         SetGlobalDataTable(
		CW_LP_VOID lpvBuffer,
		CW_USHORT usTypeTable);

	CW_USHORT         SetPartialDataTable(
		_ProtPartialDataTable *pPartialDataTable,
		CW_USHORT             usTypeTable);
	//#MODIFFRM 22/11/00
	CW_USHORT         SetPartialDataTableEx(
		_ProtPartialDataTable *pPartialDataTable,
		CW_USHORT             usTypeTable,
		_TimDat TimeDate);
	//#ENDMODIFFRM 22/11/00

protected:

	virtual void      OnUpdateDataTable( CW_LP_UPDATE_INFO lpUpdateInfo);
	virtual void      OnUpdateImageTable( void);

	CW_USHORT         GetDataTable(
		_ProtPartialDataTable *pDataTable,
		CW_LP_VOID            lpvSrc);

	CW_USHORT         SetDataTable(
		_ProtPartialDataTable *pDataTable,
		CW_LP_VOID            lpvDest);

	//#MODIFFRM 22/11/00
	CW_USHORT         SetDataTableEx(
		_ProtPartialDataTable *pDataTable,
		CW_LP_VOID            lpvDest,
		_TimDat TimeDate);
	void		  OnSetDataTable();
	//#ENDMODIFFRM 22/11/00

public:

	virtual CW_USHORT MemCopy(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemCopyEx(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulSrcIndex,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemTestAndCopy(
		CW_LP_VOID  lpvDest,
		CW_ULONG    ulIndexDest,
		CW_LP_VOID  lpvSrc,
		CW_ULONG    ulIndexSrc,
		CW_LP_ULONG pulCmpt);

	virtual _eDataUpdate  TestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual _eDataUpdate  NoTestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	//***
	//*** Data - Item Management
	//***

protected:

	CW_USHORT         InitCanonicalItem( void);

public:

	_CwCanonicalItem  *m_pCanonicalItem;

	_LinkedList       *m_llUserItem;

	void              OnSetItemInit( void);
	void              OnResetItemInit( void);

	CW_USHORT	  NotifyClient( void);         // Notify client for Data change
	CW_USHORT     NotifyClientProcess( void);  // Notify client for Data change
	CW_USHORT     NotifyNoneAccessible( void); // Call when error detect
	void		  FlowControl( void);          // Flow Control From protocol to Client

	//#MODIFJS 19/11/98 - Forcer un rafraichissement apres StopCyclic ou StopWatchUnsolicited
	void          ForceRefresh( void);

	void          OnNotifyItemHDateChange(
		_CwItemDataAttributs *pAttributs);
	void          OnNotifyHDateChange(
		_CwItemDataAttributs *pAttributs);

	virtual void      SetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      GetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      SetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      GetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	CW_USHORT         Notify(
		CW_ULONG             ulIndex,
		_CwItemDataAttributs *itValue,
		CW_LP_VOID           lpvDest);
};


class CW_IMPORT_EXPORT _ByteData: public _CwBaseData
{
	DECLARE_DYNAMIC( _ByteData)

public:

		_ByteData( void);

protected:

	virtual CW_USHORT AfterInitialize( _AD *adFile);

	void              SetData( CW_ULONG ulNbElt);

public:

	virtual CW_USHORT	MemCopy(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemCopyEx(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulSrcIndex,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemTestAndCopy(
		CW_LP_VOID  lpvDest,
		CW_ULONG    ulIndexDest,
		CW_LP_VOID  lpvSrc,
		CW_ULONG    ulIndexSrc,
		CW_LP_ULONG pulCmpt);

	virtual _eDataUpdate  TestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual _eDataUpdate  NoTestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual void      SetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      GetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	void              SetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	void              GetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);
};


class CW_IMPORT_EXPORT _WordData: public _CwBaseData
{
	DECLARE_DYNAMIC( _WordData)

public:

		_WordData( void);

protected:

	virtual CW_USHORT AfterInitialize( _AD *adFile);

	void              SetData( CW_ULONG ulNbElt);

public:

	virtual CW_USHORT	MemCopy(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemCopyEx(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulSrcIndex,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemTestAndCopy(
		CW_LP_VOID  lpvDest,
		CW_ULONG    ulIndexDest,
		CW_LP_VOID  lpvSrc,
		CW_ULONG    ulIndexSrc,
		CW_LP_ULONG pulCmpt);

	virtual _eDataUpdate  TestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual _eDataUpdate  NoTestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual void      SetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      GetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	void              SetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	void              GetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);
};


class CW_IMPORT_EXPORT _RealData: public _CwBaseData
{
	DECLARE_DYNAMIC( _RealData)

public:

		_RealData( void);

protected:

	virtual CW_USHORT AfterInitialize( _AD *adFile);

	void              SetData( CW_ULONG ulNbElt);

public:

	virtual CW_USHORT MemCopy(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemCopyEx(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulSrcIndex,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemTestAndCopy(
		CW_LP_VOID  lpvDest,
		CW_ULONG    ulIndexDest,
		CW_LP_VOID  lpvSrc,
		CW_ULONG    ulIndexSrc,
		CW_LP_ULONG pulCmpt);

	virtual _eDataUpdate  TestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual _eDataUpdate  NoTestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual void      SetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      GetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	void              SetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	void              GetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);
};


class CW_IMPORT_EXPORT _DWordData: public _CwBaseData
{
	DECLARE_DYNAMIC( _DWordData)

public:

		_DWordData( void);

protected:

	virtual CW_USHORT AfterInitialize( _AD *adFile);

	void              SetData( CW_ULONG ulNbElt);

public:

	virtual CW_USHORT	MemCopy(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemCopyEx(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulSrcIndex,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemTestAndCopy(
		CW_LP_VOID  lpvDest,
		CW_ULONG    ulIndexDest,
		CW_LP_VOID  lpvSrc,
		CW_ULONG    ulIndexSrc,
		CW_LP_ULONG pulCmpt);

	virtual _eDataUpdate  TestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual _eDataUpdate  NoTestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual void      SetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      GetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	void              SetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	void              GetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);
};


class CW_IMPORT_EXPORT _BitData: public _CwBaseData
{
	DECLARE_DYNAMIC( _BitData)

public:

		_BitData( void);

protected:

	virtual CW_USHORT AfterInitialize( _AD *adFile);

	void              SetData( CW_ULONG ulNbElt);

public:

	virtual CW_USHORT MemCopy(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemCopyEx(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulSrcIndex,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemTestAndCopy(
		CW_LP_VOID  lpvDest,
		CW_ULONG    ulIndexDest,
		CW_LP_VOID  lpvSrc,
		CW_ULONG    ulIndexSrc,
		CW_LP_ULONG pulCmpt);

	virtual _eDataUpdate  TestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual _eDataUpdate  NoTestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual void      SetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      GetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	void              SetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	void              GetDefaultItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);
};


class CW_IMPORT_EXPORT _BCDByteData: public _ByteData
{
	DECLARE_DYNAMIC( _BCDByteData)

public:

		_BCDByteData( void);

	virtual CW_USHORT MemCopy(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemCopyEx(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulSrcIndex,
		CW_ULONG   ulDataSize);

	virtual _eDataUpdate  TestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual _eDataUpdate  NoTestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual void      SetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      GetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);
};


class CW_IMPORT_EXPORT _BCDWordData: public _WordData
{
	DECLARE_DYNAMIC( _BCDWordData)

public:

		_BCDWordData( void);

public:

	virtual CW_USHORT MemCopy(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemCopyEx(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulSrcIndex,
		CW_ULONG   ulDataSize);

	virtual _eDataUpdate  TestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual _eDataUpdate  NoTestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual void      SetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      GetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

};


class CW_IMPORT_EXPORT _BCDDWordData: public _DWordData
{
	DECLARE_DYNAMIC( _BCDDWordData)

public:

		_BCDDWordData( void);

public:

	virtual CW_USHORT MemCopy(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulDataSize);

	virtual CW_USHORT	MemCopyEx(
		CW_LP_VOID lpvDest,
		CW_ULONG   ulDestIndex,
		CW_LP_VOID lpvSrc,
		CW_ULONG   ulSrcIndex,
		CW_ULONG   ulDataSize);

	virtual _eDataUpdate  TestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual _eDataUpdate  NoTestAndSet(
		_CwItemValue *itRefValue,
		_CwItemValue *itNewValue);

	virtual void      SetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

	virtual void      GetItemValue(
		CW_ULONG     ulIndex,
		_CwItemValue *itValue,
		CW_LP_VOID   lpvTable);

};

#endif // _CWDATA_H_