#ifndef _CWBKSERV_H_
#define _CWBKSERV_H_

#ifdef _WIN64

#undef FP_SEG
#undef FP_OFF
#undef MK_FP

#else

#undef FP_SEG
#define FP_SEG( fp ) \
    ((CW_USHORT)((CW_ULONG)(fp) >> 16))

#undef FP_OFF
#define FP_OFF( fp ) \
    ((CW_USHORT)(((CW_ULONG)(fp)) & 0x0000FFFF))

#undef MK_FP
#define MK_FP( seg, ofs ) \
    (((CW_ULONG)((CW_USHORT)(seg)) << 16) | ((CW_ULONG)((CW_USHORT)(ofs))))

#endif

//***
//*** SERVICES
//***

CW_C_IMPORT_EXPORT CW_USHORT Attente(
	TYP_DESBLANC *desblanc,
	MOT delai);

CW_C_IMPORT_EXPORT CW_USHORT Transfert_Cim(
	TYP_DESBLANC *desblanc,
	OCTET *buffer);
	
CW_C_IMPORT_EXPORT CW_USHORT Transfert_Prot(
	TYP_DESBLANC *desblanc,
	OCTET *buffer);
	
CW_C_IMPORT_EXPORT CW_USHORT Transfert_Page_Cim(
	TYP_DESBLANC *desblanc,
	OCTET *buffer,
	MOT pn_despag,
	MOT type_data_image);
	
CW_C_IMPORT_EXPORT CW_USHORT Transfert_Page_Prot(
	TYP_DESBLANC *desblanc,
	OCTET *buffer,
	MOT pn_despag,
	MOT type_data_image);
	
CW_C_IMPORT_EXPORT CW_USHORT Transfert_Partiel_Cim(
	TYP_DESBLANC *desblanc,
	OCTET *buffer,
	MOT pn_despag,
	MOT nb_data,
	MOT rang_data,
	MOT type_data_image);
	
CW_C_IMPORT_EXPORT CW_USHORT Transfert_Partiel_Prot(
	TYP_DESBLANC *desblanc,
	OCTET *buffer,
	MOT pn_despag,
	MOT nb_data,
	MOT rang_data,
	MOT type_data_image);
	
CW_C_IMPORT_EXPORT CW_USHORT Fin_Traitement(
	TYP_DESBLANC *desblanc,
	MOT code_retour,
	...);
	
CW_C_IMPORT_EXPORT CW_USHORT Indic_Erreur(
	TYP_DESBLANC *desblanc,
	MOT gravite_erreur,
	struct sErrNiv7 *err_niv7);

//#MODIFJS 27/10/98 - Audit des temps de lecture
CW_C_IMPORT_EXPORT void statWrite( TYP_DESBLANC *desblanc);
CW_C_IMPORT_EXPORT void statBeginRead( TYP_DESBLANC *desblanc);
CW_C_IMPORT_EXPORT void statEndRead( TYP_DESBLANC *desblanc);

//#MODIFJS 11/03/99 - Gestion du chemin de l'application et du projet
CW_C_IMPORT_EXPORT CW_USHORT GetApplicationPath(
	char *lpszApplicationPath);

//#MODIFJS 11/03/99 - Gestion du chemin de l'application et du projet
CW_C_IMPORT_EXPORT CW_USHORT GetProjectPath(
	char *lpszProjectPath);

#endif
