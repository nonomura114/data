#ifndef __CWTCPIPINTF_H__
#define __CWTCPIPINTF_H__

// Taille du buffer de r�ception par d�faut
#define	SIZE_DEFAULT_RECEIVE_BUFFER		2048

#define	CW_TCPIP_OK				0			// Pas d'erreur
#define	CW_TCPIP_ERROR			-1			// La connexion n'est pas �tablie
#define	CW_TCPIP_RECEIVE_TO		1			// Time out sur la requete de reception
#define	CW_TCPIP_ALREADY_START	2			// d�j� d�marr�

class	IcwTCPIPCallBack;
class	IcwTCPIPIntf;
class	CcwTCPIP;

//#MODIFED 12/08/11 Ajout du define
typedef enum
{
	eAccess_Client,		// Acc�s en mode client
	eAccess_Server,		// Acc�s en mode serveur
    //#MODIFED 22/07/11
    eAccess_ClientUnsolicited //Acc�s en mode client avec gestion des trames non solicit�es
} enumAccessType;

typedef enum
{
	eRST_ACK,		// The socket stop with a RST-ACK
	eFIN_ACK,		// The socket close with a FIN-ACK
} enumCloseMode;


// Creation de l'objet TCPIP de type client
IcwTCPIPIntf * CreatecwTCPIPClient(
					IcwTCPIPCallBack *	a_pICallBack,
					DWORD				a_ReceiveBufferSize = SIZE_DEFAULT_RECEIVE_BUFFER,
                    enumAccessType      a_eAccessType = eAccess_Client,
                    enumCloseMode       a_eClosemode = eRST_ACK); 

//;****************************************************************
//; IcwTCPIPIntf
//; ------------
//; Interface d'acc�s � l'api TCPIP de CimWay.
//;_________________________________________________________________

class	IcwTCPIPIntf : public CObject
{
public:
			CcwTCPIP *	m_pcwTCPIP;

				// Constructeur
				IcwTCPIPIntf(              
					IcwTCPIPCallBack *	a_pICallBack,	
					DWORD				a_ReceiveBufferSize,
                    enumAccessType      a_eAccessType,
                    enumCloseMode       a_eClosemode);

				// Destructeur
virtual			~IcwTCPIPIntf();            

		// Etablir la connexion
virtual		int	Start(
					const CString &	a_csRemoteIpAddress,		// [in] adresse IP ex: 10.0.0.23
					USHORT			a_usRemotePortNumber,		// [in] num�ro de port
					DWORD			a_dwReconnectionPeriod,		// [in] P�riode de reconnexion
					bool			a_bSyncMode	= FALSE);       // [in] si FALSE, pas d'attente de compte rendu d'ex�cution   		

virtual		int	Start(
                    const CString &	a_csRemoteIpAddress,		// [in] adresse IP ex: 10.0.0.23
                    const CString &	a_csRemoteHostName,		    // [in] host name (FQDN)
                    USHORT			a_usRemotePortNumber,		// [in] num�ro de port
                    DWORD			a_dwReconnectionPeriod,		// [in] P�riode de reconnexion
                    bool			a_bSyncMode = FALSE);       // [in] si FALSE, pas d'attente de compte rendu d'ex�cution    		


		// Coupure de la connexion (close socket)
virtual		int	Stop();

		// Cette fct fait une demande d'�mission puis une se met en attente de r�ception 
virtual		int	SendRcvFrame(
					CW_LPC_UCHAR	a_pcBufferToSend,		// [in] Ptr sur le buffer contenant les donn�es � �mettre
					CW_ULONG		a_ulSendBufferSize,		// [in] Taille en octet des donn�es � transmettre
					CW_ULONG		a_ulTimeOut,            // [in] Time out en milliseconde
                    bool            a_bRequestSent = false);// [in] Request already sent			

//#MODIFED 13/05/09
		// Cette fct fait une demande d'�mission 
virtual		int	SendFrame(
					CW_LPC_UCHAR	a_pcBufferToSend,		// [in] Ptr sur le buffer contenant les donn�es � �mettre
					CW_ULONG		a_ulSendBufferSize,		// [in] Taille en octet des donn�es � transmettre
					CW_ULONG		a_ulTimeOut);			// [in] Time out en milliseconde
//#ENDMODIF

};

//;****************************************************************
//; IcwTCPIPCallBack
//; ----------------
//; Interface des fonctions CallBack du TCPIP de CimWay.
//;_________________________________________________________________

class	IcwTCPIPCallBack : public CObject
{
public:
	// Cette fct est appel�e quand la connexion est �tablie 
virtual	void	OnConnectionReady() {}

		// Cette fct est appel�e quand la connexion est rompue 
virtual void	OnConnectionAbort() {}

		// Cette fct est appel�e quand des donn�es sont re�ues
		// Retour = TRUE si les donn�es ont �t� re�u
virtual	bool	OnReceive(
					CW_LPC_CHAR		a_pcRcvBuffer,			// [in] Ptr sur le buffer contenant les donn�es re�ues
					int				a_iReceiveResult)		// [in] Nombre de aract�re re�u
				{ return TRUE; }

//#MODIFED 22/07/11
virtual	void	OnUnsolicitedFrame(
					CW_LPC_CHAR		a_pcRcvBuffer,			// [in] Ptr sur le buffer contenant les donn�es re�ues
					int				a_iReceiveResult)		// [in] Nombre de caract�re re�u
				{}
//#ENDMODIFED
};



#endif // __CWTCPIP_H__
