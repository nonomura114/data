/*--------------------------------------------------------------------------*/
/*																			*/
/*		PROJECT		:	LIBRAIRIE GENERIQUE D'ACCES A LA COUCHE PHYSIQUE	*/
/*																			*/
/*		MODULE		:	cwioerr.h											*/
/*																			*/
/*		VERSION		:	1.00												*/
/*																			*/
/*		SYSTEMES	:	Windows 95 , Windows NT								*/
/*																			*/
/*		AUTHOR		:	Eric PERROTIN										*/
/*																			*/
/*		PURPOSE		:	Erreurs entr�es/sorties								*/
/*																			*/
/*--------------------------------------------------------------------------*/

#ifndef _CWIOERR_H_

	#define _CWIOERR_H_

#define	CW_ERR_SYS_ALLOC						400
#define	CW_ERR_WAIT_TIMEOUT						401
#define	CW_ERR_WAIT_FAILED						402

// Create Comm errors
#define	CW_ERR_CREATE_COMM_HANDLE				410

// Create Event errors
#define	CW_ERR_CREATE_EXIT_EVENT				413
#define	CW_ERR_CREATE_OSREAD_EVENT				414
#define	CW_ERR_CREATE_OSSTATUS_EVENT			415
#define	CW_ERR_CREATE_OSWRITE_EVENT				416

#define	CW_ERR_CREATE_READER_EVENT				420
#define	CW_ERR_CREATE_READER_OK_EVENT			421
#define	CW_ERR_CREATE_READER_ABORT_EVENT		422
#define	CW_ERR_CREATE_READER_TO_RECEPTION_EVENT	423

#define CW_ERR_CREATE_WRITER_EVENT				425
#define CW_ERR_CREATE_WRITER_OK_EVENT			426
#define CW_ERR_CREATE_WRITER_ABORT_EVENT		427

// Init comm errors
#define	CW_ERR_SET_PORT_STATE					430
#define	CW_ERR_GET_PORT_STATE					431
#define CW_ERR_SET_PORT_TIMEOUTS				432
#define	CW_ERR_PURGE_PORT_BUFFERS				433
#define	CW_ERR_SETDTR							434
#define	CW_ERR_CLRDTR							435
#define	CW_ERR_SETRTS							436
#define	CW_ERR_CLRRTS							437

// Read errors
#define	CW_ERR_READ_FAILED						440
#define	CW_ERR_READ_ABORTED						441
#define	CW_ERR_READ_GET_OVERLAPPED_RESULT		442
#define	CW_ERR_READ_TIMEOUT						443
#define	CW_ERR_READ_REQUEST_TIMEOUT				445
#define	CW_ERR_READ_WAIT_FAILED					446


// Status errors
#define	CW_ERR_STATUS_FAILED					450
#define	CW_ERR_STATUS_ABORTED					451
#define	CW_ERR_STATUS_GET_OVERLAPPED_RESULT		452
#define	CW_ERR_STATUS_TIMEOUT					453

// Status errors
#define	CW_ERR_WRITE_FAILED						460
#define	CW_ERR_WRITE_ABORTED					461
#define	CW_ERR_WRITE_GET_OVERLAPPED_RESULT		462
#define	CW_ERR_WRITE_TIMEOUT					463
#define	CW_ERR_WRITE_DATA						464
#define	CW_ERR_WRITE_REQUEST_TIMEOUT			465
#define CW_ERR_WRITE_WAIT_FAILED				466

#endif
