/*
** cwlnklst.h
*/

#ifndef _CWLNKLST_H_

	#define _CWLNKLST_H_

	class _Elt;
	class _LinkedList;
	
	class CW_IMPORT_EXPORT _Elt: public CObject
	{
		DECLARE_DYNAMIC( _Elt)

	private:
		_Elt *m_eltNext;
		_Elt *m_eltPrevious;
		CW_LP_VOID m_lpvContent;

	public:
		_Elt( 
			_Elt *Previous=NULL,
			_Elt *Next=NULL,
			CW_LP_VOID lpvContent=NULL);
		virtual ~_Elt( void);

		_Elt *GetNext( void);
		void SetNext( _Elt *eltNext);

		_Elt *GetPrevious( void);
		void SetPrevious( _Elt *eltPrevious);

		CW_LP_VOID GetContent( void);
		void SetContent( CW_LP_VOID lpvContent);
	};

	class CW_IMPORT_EXPORT _LinkedList: public CObject
	{
		DECLARE_DYNAMIC( _LinkedList)

	protected:

		_CriticalSection *m_lpCriticalSection;
		
		_Elt *m_Head;
		_Elt *m_Tail;
		long m_dwCounter;

		CW_BOOL VerifyPosition( long dwPosition);
		_Elt *GetElementAt( long dwPosition);

	public:
		long nbmax;

		// Constructor
		_LinkedList( long lMaxElt = 32767);
		// Destructor
		virtual ~_LinkedList( void);

		// Elt Creation and Deletion Functions
		virtual _Elt *CreateElt( _Elt *Previous, _Elt *Next, CW_LP_VOID Content);
		virtual void DeleteElt( _Elt *Elt);

		// Head/Tail Access
		CW_LP_VOID GetFirstContent( void);
		CW_LP_VOID GetLastContent( void);

		// Operations
		CW_LP_VOID UnlinkFirst( void);
		CW_LP_VOID UnlinkLast( void);
		CW_LP_VOID Unlink( CW_LP_VOID lpvContent);
		CW_LP_VOID UnlinkElement( _Elt *eltToRemove);
		CW_BOOL LinkBegin( CW_LP_VOID lpvContent);
		CW_BOOL LinkEnd( CW_LP_VOID lpvContent);
		void Purge( void);
		
		_Elt       *LinkFirst( CW_LP_VOID lpvContent);
		_Elt       *LinkLast( CW_LP_VOID lpvContent);

        // Iteration
		void StartIteration( void);
		void StopIteration( void);
		_Elt *GetFirst( void);
		_Elt *GetLast( void);
		_Elt *GetNext( _Elt *eltReference);
		_Elt *GetPrev( _Elt *eltReference);

		// Retrieval/Modification
		CW_LP_VOID GetAt( long dwPosition);
		CW_BOOL SetAt( long dwPosition, CW_LP_VOID lpvContent);
		CW_LP_VOID UnlinkAt( long dwPosition);

		// Insertion
		CW_BOOL LinkBefore( CW_LP_VOID lpvContent, CW_LP_VOID lpvReference);
		CW_BOOL LinkAfter( CW_LP_VOID lpvContent, CW_LP_VOID lpvReference);

		_Elt       *LinkBeforeElement(
                        CW_LP_VOID lpvContent,
                        _Elt *eltReference);

        _Elt       *LinkAfterElement(
                        CW_LP_VOID lpvContent,
                        _Elt *eltReference);

		// Searching
		_Elt *Find( CW_LP_VOID lpvContent);
		long FindIndex( CW_LP_VOID lpvContent);
		int IsInList( CW_LP_VOID lpvContent);

		// Status
		CW_BOOL IsEmpty( void);
		CW_ULONG GetNb( void);
		CW_ULONG GetNbLong( void);
	};


#define LL_LOOP( LL, FCT)\
\
	if ( LL != NULL)\
	{\
		_Elt *Elt, *EltNext;\
		CW_LP_VOID Item;\
\
		(LL)->StartIteration();\
		Elt = (LL)->GetFirst();\
\
		while ( Elt != NULL)\
		{\
			EltNext = (LL)->GetNext( Elt);\
			Item = Elt->GetContent();\
			if ( Item != NULL)\
			{\
				FCT;\
			}\
			Elt = EltNext;\
		}\
\
		(LL)->StopIteration();\
	}

#define LL_LOOP_B( LL)\
\
	if ( LL != NULL)\
	{\
		_Elt *Elt, *EltNext;\
		CW_LP_VOID Item;\
\
		(LL)->StartIteration();\
		Elt = (LL)->GetFirst();\
\
		while ( Elt != NULL)\
		{\
			EltNext = (LL)->GetNext( Elt);\
			Item = Elt->GetContent();\
			if ( Item != NULL)

#define LL_LOOP_E( LL)\
\
			Elt = EltNext;\
		}\
\
		(LL)->StopIteration();\
	}


#define LL_FULL_DESTRUCTION( LL, CAST)\
\
	if ( LL != NULL)\
	{\
		CAST Item;\
\
		LL->StartIteration();\
		while( LL->IsEmpty() == CW_FALSE)\
			if (( Item = (CAST)LL->UnlinkFirst()) != NULL)\
				delete Item;\
		LL->StopIteration();\
		delete LL;\
		LL = NULL;\
	}

#define LL_FULL_PURGE( LL, CAST)\
\
	if ( LL != NULL)\
	{\
		CAST Item;\
\
		(LL)->StartIteration();\
		while( (LL)->IsEmpty() == CW_FALSE)\
		{\
			if (( Item = (CAST)(LL)->UnlinkFirst()) != NULL)\
				delete Item;\
		}\
		(LL)->StopIteration();\
	}


#define LL_UNLINK_AND_EXEC( LL, FCT)\
\
	if ( LL != NULL)\
	{\
		CAST Item;\
\
		(LL)->StartIteration();\
		while( (LL)->IsEmpty() == CW_FALSE)\
			if (( Item = (LL)->UnlinkFirst()) != NULL)\
			{\
				FCT;\
			}\
		(LL)->StopIteration();\
		delete LL;\
	}

#define LL_UNLINK_AND_EXEC_B( LL)\
\
	if ( LL != NULL)\
	{\
		CAST Item;\
\
		LL->StartIteration();\
		while( LL->IsEmpty() == CW_FALSE)\
			if (( Item = LL->UnlinkFirst()) != NULL)\

#define LL_UNLINK_AND_EXEC_E( LL)\
\
		LL->StopIteration();\
		delete LL;\
	}


#define LL_DESTRUCTION( LL)\
\
	if ( LL != NULL)\
	{\
		delete LL;\
		LL = NULL;\
	}

#define LL_COUNT( LL)\
\
	( LL == NULL? 0: LL->GetNb())


#define LL_FIND( LL, POS, ITEM, CAST)\
\
	if ( ( LL != NULL) && ( POS <= (LL)->GetNb()))\
	{\
		ITEM = (CAST)(LL)->GetAt( POS);\
	}\
	else\
	{\
		ITEM = NULL;\
	}


#define LL_SEARCH( LL, ITEM, CAST, COND)\
	if ( LL != NULL)\
	{\
		LL->StartIteration();\
\
		_Elt *Elt = LL->GetFirst();\
		while ( Elt != NULL)\
		{\
			ITEM = (CAST)Elt->GetContent();\
			if ( (ITEM != NULL) && (COND))\
				break;\
			Elt = LL->GetNext( Elt);\
		}\
		LL->StopIteration();\
\
		if ( Elt == NULL)\
			ITEM = NULL;\
	}\
	else\
	{\
		ITEM = NULL;\
	}


#endif /* _CWLNKLST_H_ */
