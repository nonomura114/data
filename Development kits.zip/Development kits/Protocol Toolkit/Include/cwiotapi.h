/*--------------------------------------------------------------------------*/
/*																			*/
/*		PROJECT		:	LIBRAIRIE GENERIQUE D'ACCES A LA COUCHE PHYSIQUE	*/
/*																			*/
/*		MODULE		:	cwiotapi.h											*/
/*																			*/
/*		VERSION		:	1.00												*/
/*																			*/
/*		SYSTEMES	:	Windows 95 , Windows NT								*/
/*																			*/
/*		AUTHOR		:	Eric PERROTIN										*/
/*																			*/
/*		PURPOSE		:	Classe sp�cifique d'acc�s TAPI						*/
/*																			*/
/*--------------------------------------------------------------------------*/


#ifndef _CWIOTAPI_H_

	#define _CWIOTAPI_H_


//******************************
//
//	_CwIO_TAPI Class
//
//******************************
class  _CwIO_TAPI :	public _CwIO 
{



//***
//***	CONSTRUCTOR & DESTRCTOR
//***
public:

		_CwIO_TAPI( _CwBaseNetwork *pNetworkOwner);  //#MODIFJS 10/03/99 - Gestion des param�tres s�ries (Prot. NG)
		virtual ~_CwIO_TAPI( CW_VOID);


//***
//***	INIT
//***
public:
	CW_USHORT		Initialize( _AD *);



//***
//***	RESET
//***
public:
	CW_VOID			Reset( CW_VOID );	



//***
//***	START
//***
public:		
	CW_USHORT		Start( CW_VOID );



//***
//***	STOP
//***
public:
	CW_VOID			Stop(CW_VOID );

};

#endif