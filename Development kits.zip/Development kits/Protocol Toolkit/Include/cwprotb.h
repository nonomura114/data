#ifndef _CWPROTB_H_

	#define _CWPROTB_H_


#define PROTBASE_FCT_RESERVED			\
	virtual void	FctReserve01( void);	\
	virtual void	FctReserve02( void);	\
	virtual void	FctReserve03( void);	\
	virtual void	FctReserve04( void);	\
	virtual void	FctReserve05( void);	\
	virtual void	FctReserve06( void);	\
	virtual void	FctReserve07( void);	\
	virtual void	FctReserve08( void);	\
	virtual void	FctReserve09( void);	\
	virtual void	FctReserve10( void);	\
	virtual void	FctReserve11( void);	\
	virtual void	FctReserve12( void);	\
	virtual void	FctReserve13( void);	\
	virtual void	FctReserve14( void);	\
	virtual void	FctReserve15( void);	\
	virtual void	FctReserve16( void);

#define NETWORK_FCT_RESERVED			\
	virtual void	FctReserve01( void);	\
	virtual void	FctReserve02( void);	\
	virtual void	FctReserve03( void);	\
	virtual void	FctReserve04( void);	\
	virtual void	FctReserve05( void);	\
	virtual void	FctReserve06( void);	\
	virtual void	FctReserve07( void);	\
	virtual void	FctReserve08( void);	\
	virtual void	FctReserve09( void);	\
	virtual void	FctReserve10( void);	\
	virtual void	FctReserve11( void);	\
	virtual void	FctReserve12( void);	\
	virtual void	FctReserve13( void);	\
	virtual void	FctReserve14( void);	\
	virtual void	FctReserve15( void);	

#define EQT_FCT_RESERVED	PROTBASE_FCT_RESERVED
#define FRAME_FCT_RESERVED	PROTBASE_FCT_RESERVED


#endif /* _CWPROTB_H_ */
