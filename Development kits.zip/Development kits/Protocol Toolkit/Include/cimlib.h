//****************************************************************************
//*                                                                          *
//*  MODULE NAME      :  CIMLIB.h                                            *
//*                                                                          *
//*  VERSION          :  1.40                                                *
//*                                                                          *
//*  PURPOSE          :  This files contains structure definitions, defined  *
//*                      constants and CIMLIB library functions used to      *
//*                      interface with CIMWAY.                              *
//*                                                                          *
//*  REVISION HISTORY :  11 October 1991 - CIMLIB original.                  *
//*                                                                          *
//*                                                                          *
//*        Copyright (c) 1991, ARC INFORMATIQUE, All rights reserved.        *
//*                                                                          *
//****************************************************************************


#ifndef CIMLIB_INCLUDED    // Only include it once.
#define CIMLIB_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "cwimpexp.h"
#include "cw_types.h"		//#MODIFJS 13/06/96

//****************************************************************************
//*                               CONSTANTS                                  *
//****************************************************************************


// CIMLIB version number :
// -----------------------

#define CW_VERSION  0140


// Error message maximum length :
// ------------------------------

#define CW_ERR_MSG_LEN  80


// CIMLIB functions return codes :
// -------------------------------

#define CW_OK                              0  // No error.
#define CW_NO_ERROR                        0

// CIMWAY errors :

#define CW_ERR_CONFIGURATION               1  // Configuration error.
#define CW_ERR_INTERNAL_ERROR              2  // CIMWAY internal error.
#define CW_ERR_INVALID_CMD_NUM             3  // Invalid command number.
#define CW_ERR_CMD_NOT_IMPLEMENTED         4  // Command not implemented.
#define CW_ERR_UNKNOWN_PROTOCOL_CMD        5  // Unknown command for this
                                              // protocol.
#define CW_ERR_INVALID_PARAMATER           6  // Invalid parameter.
#define CW_ERR_PROTOCOL_ALREADY_INIT       7  // CIMWAY already initialized.
#define CW_ERR_PROTOCOL_NOT_INIT           8  // CIMWAY not initialized.
#define CW_ERR_INVALID_NET_NUM             9  // Invalid network number.
#define CW_ERR_NET_ALREADY_STARTED        10  // Network is already started.
#define CW_ERR_NET_STOPPED                11  // Network is stopped.
#define CW_ERR_INVALID_EQT_NUM            12  // Invalid equipment number.
#define CW_ERR_EQT_ALREADY_STARTED        13  // Equipment is already started.
#define CW_ERR_EQT_STOPPED                14  // Equipment is stopped.
#define CW_ERR_INVALID_DESLIEN_NUM        15  // Invalid "DESLIEN" number.
#define CW_ERR_DESLIEN_NOT_SUPPORTED      16  // "DESLIEN" not supported by
                                              // CIMWAY.
#define CW_ERR_INVALID_DESMEM_NUM         17  // Invalid "DESMEM" number.
#define CW_ERR_DESMEM_NOT_SUPPORTED       18  // "DESMEM" not supported by
                                              // CIMWAY.
#define CW_ERR_AUTO_REPEAT_ENABLED        19  // Auto repeat transfer already
                                              // enabled.
#define CW_ERR_AUTO_REPEAT_DISABLED       20  // Auto repeat transfer already
                                              // disabled.
#define CW_ERR_EXCHANGE_INACTIVE          23  // Exchange is inactive.
#define CW_ERR_ILLEGAL_SIMPLE_READ        24  // Simple read unauthorized.
#define CW_ERR_ILLEGAL_SIMPLE_WRITE       25  // Simple write unauthorized.
#define CW_ERR_NOT_AUTO_REPEAT_EXCHANGE   26  // Exchange not defined in auto
                                              // repeat transfer.
#define CW_ERR_INVALID_POSITION_LENGTH    27  // Invalid start position
                                              // and/or length.
#define CW_ERR_INVALID_INTERVAL           28  // Invalid auto repeat transfer
                                              // interval.
#define CW_ERR_ILLEGAL_ASYNC_READ         29  // Simple asynchronous read
                                              // unauthorized.
#define CW_ERR_ILLEGAL_EXCHANGE_CMD       30  // Illegal command for
                                              // this exchange.
#define CW_ERR_NET_START_FAILED           31  // Network start command failed.
#define CW_ERR_EQT_START_FAILED           32  // Equipment start command failed.
#define CW_ERR_NET_STOP_FAILED            33  // Network stop command failed.
#define CW_ERR_EQT_STOP_FAILED            34  // Equipment stop command failed.
#define CW_ERR_SYNC_CMD_FAILED            35  // Synchronous command failed.
#define CW_ERR_SYNC_CMD_ABORTED           36  // Synchronous command aborted.
#define CW_ERR_DATA_NOT_UPDATED           37  // Data not updated.
#define CW_ERR_DATA_NOT_INIT              38  // Data not initialized.
#define CW_ERR_INVALID_VERSION            39  // Invalid configuration version.
#define CW_ERR_CMD_NOT_PROCESSED          40  // Command not processed by the
                                              // protocol.
//#MODIF JS - Erreurs pour CW16/32

#define CW_ERR_INVALID_BOARD_NUM          41 // Invalid Board Number
#define CW_ERR_INVALID_FRAME_NUM          42 // Invalid Frame Number
#define CW_ERR_BOARD_ALREADY_STARTED      43 // Board is already started
#define CW_ERR_BOARD_STOPPED              44 // Board is stopped
#define CW_ERR_FRM_START_FAILED           45
#define CW_ERR_FRM_STOP_FAILED            46
#define CW_ERR_INVALID_BUFFER             47
#define CW_ERR_CW_NOT_DISPO               49
#define CW_ERR_OVERFLOW                   50 // FPE_OVERFLOW
                                             // BCD_OVERFLOW

// Erreur mise en file des commandes

#define CW_ERR_ULTRA_QUEUE_FULL           51
#define CW_ERR_ULTRAWAIT_QUEUE_FULL       52
#define CW_ERR_PRIOR_QUEUE_FULL           21 // Compatibilite
                                             // Time-critical commands queue
                                             // is full.
#define CW_ERR_PRIORWAIT_QUEUE_FULL       53
#define CW_ERR_CYCLIC_QUEUE_FULL          54
#define CW_ERR_CYCLICWAIT_QUEUE_FULL      55
#define CW_ERR_ONESHOT_QUEUE_FULL         22 // Compatibilite
                                             // Application commands queue
                                             // is full.
#define CW_ERR_ONESHOTWAIT_QUEUE_FULL     56
#define CW_ERR_DATA_NOT_FOUND             57
#define CW_ERR_UNKNOW_ITEM                58

#define CW_ERR_WATCH_UNSOLICITED_ENABLED  59
#define CW_ERR_WATCH_UNSOLICITED_DISABLED 60
#define CW_ERR_NOT_UNSOLICITED_EXCHANGE   61

#define CW_ERR_NO_CMD_IN_LIST             62
#define CW_ERR_NO_CURRENT_CMD             63

#define	CW_OBJECTTYPE_INVALID				64
#define	CW_MODIFY_ATTRIBUT_NOTSUPPORTED		65
#define	CW_LAYERONE_INVALID					66


// Errors messages file or configuration file reading errors :

#define CW_ERR_OPEN_MSG_FILE			100 // Errors messages file opening failed.
#define CW_ERR_OPEN_CONFIG_FILE			101 // Configuration file opening failed.
#define CW_ERR_BAD_CONFIG_FILE_VERSION	102 // Configuration file version is bad.
#define CW_ERR_NOT_ENOUGH_MEMORY		103 // Not enough memory to allocate messages buffer or CIMWAY tables
#define CW_ERR_PROTDAT_OPEN_FAILED		104 // PROTOC.DAT opening has failed
#define CW_ERR_PROTDAT_EMPTY			105 // PROTOC.DAT is empty
#define CW_ERR_PROTDAT_UNKNOW_PROT		106 // Protocol Type isn't registry in PROTOC.DAT

#define CW_ERR_PROT_OPEN_FAILED			120 // Protocol File opening has failed
#define CW_ERR_PROT_BAD					121 // Protocol File is bad
#define CW_ERR_IO_CREATE				122	// The I/O object cannot be created

#define CW_ERR_PROT_OPEN_MANUFAC_DLL	123	// Protocol File, error on loading manufacturer DLL
#define CW_ERR_PROT_CREATEDIR_FAILED	124	// Protocol File, creating directory Bin\Tmp
#define CW_ERR_PROT_COPY_FAILED			125	// Protocol File copying has failed

#define CW_PFAIL						130	// The function was partially successful. See the pErrors
#define CW_FAIL							131	// The function was unsuccessful
#define CW_INVALIDHANDLE				132	// The frame server handle was invalid
#define CW_INVALIDTID					133	// The transaction ID is invalid
#define CW_INVALIDID                    134
#define CW_OBJECTNOTPRODUCT				135	// The objet is not product 

#define CW_ERR_STARTING_THREAD			140
#define CW_ERR_STOPING_THREAD			141

//#MODIFJS 23/04/98
#define CW_ERR_INVALID_INDEX             145
#define CW_ERR_NOT_IMPLEMENTED_TYPE      146
#define CW_ERR_INVALID_USER_ATTRIBUTES   147
#define CW_ERR_INVALID_HANDLE            148
//#ENDMODIFJS 23/04/98

#define CW_ERR_IO_START                  149  // The I/O object cannot be started
#define CW_ERR_NOMAPPEDDATA              150

// OS/2 errors only :

#define CW_ERR_OS2_INVALID_RIC_TASK_NUM  200  // Invalid RIC task number.
#define CW_ERR_OS2_RIC_DEVICE_ACCESS     201  // Error during access to the RIC
                                              // device driver.
#define CW_ERR_OS2_RIC_INIT_FAILED       202  // Error during RIC
                                              // initialization.

// TSR installation error (MS/DOS and Windows only) :

#define CW_ERR_TSR_NOT_INSTALLED         300  // The TSR is not found.


// #MODIF EG 04/04/97
// Warning les codes d'erreurs de 400 � 700 sont r�serv�s
// pour le gestion des I/O
// #MODIF EG 04/04/97

// Read / write synchronous mode :
// -------------------------------

// Values of "SyncMode" parameter of "CwRead", "CwPartRead", "CwWrite" and
// "CwPartWrite" functions.

#define CW_SYNC   0  // Synchronous  read/write.
#define CW_ASYNC  1  // Asynchronous read/write.


// Read / write action code :
// --------------------------

// Values of "ActionCode" parameter of "CwRead", "CwPartRead", "CwWrite" and
// "CwPartWrite" functions.

#define CW_NORM_CMD  	   0x0  // Normal command.
#define CW_PRIO_CMD  	   0x1  // Time-critical command.
#define CW_SEQ_CMD   		0x2  // Sequencing command.
#define CW_COND_CMD  		0x4  // Conditional command.
#define CW_TYPETABLE_CMD  	0x8  // Choise type table.
#define CW_TUSER_CMD  		0x10 // Choise user table.


// Auto repeat transfer flag :
// ---------------------------

// Values of "AutoRepeatFlag" parameter of "CwSetActionAutoRepeat",
// "CwSetEquipmentAutoRepeat" and  "CwSetNetworkAutoRepeat" functions.

#define CW_ENABLED                1  // Auto repeat enabled.
#define CW_DISABLED               0  // Auto repeat disabled.
#define CW_INCONDITIONAL_ENABLED  2  // Enable Cyclic whenever no variables are mapped
#define CW_DEFAULT_ENABLED        3

// CIMWAY command calling context :
// --------------------------------

// Values of "Context" member of "CW_ERR_INFO" structure.

#define CW_CTX_SERVICE  0  // Nothing (services functions).
#define CW_CTX_CMD      1  // Command number only.
#define CW_CTX_NET      2  // Command number + network number.
#define CW_CTX_ACT      3  // Command number + action user number.
#define CW_CTX_NET_EQT  4  // Command number + network + equipment number.
#define CW_CTX_TAB      5  // Command number + data table user number.
#define CW_CTX_PRIO     6  // Command number + priority number.


// Environment types :
// -------------------

// Values of "Environment" member of "CW_PRO_INFO" structure.

#define CW_ALL_ENV       0  // ALL.
#define CW_PC_4P_ENV     1  // PC 4 ports.
#define CW_RIC_2P_ENV    2  // RIC 2 ports.
#define CW_RIC_4P_ENV    3  // RIC 4 ports.
#define CW_RIC_8P_ENV    4  // RIC 8 ports.
#define CW_FACTOR_ENV    5  // FACTOR.
#define CW_ETHERNET_ENV  6  // ETHERNET.
#define CW_LAC_ENV       7  // LAC (COMPEX).
#define CW_MODICON_ENV   8  // MODICON.


// Number of stop bits (network information) :
// -------------------------------------------

// Values of "StopBits" member of "CW_NET_INFO" structure.

#define CW_0_STOP_BIT     0  // 0 stop bit.
#define CW_1_STOP_BIT     1  // 1 stop bit.
#define CW_1_5_STOP_BITS  2  // 1,5 stop bits.
#define CW_2_STOP_BITS    3  // 2 stop bits.


// Type of parity checking (network information) :
// -----------------------------------------------

// Values of "Parity" member of "CW_NET_INFO" structure.

#define CW_NO_PARITY    0  // No parity.
#define CW_EVEN_PARITY  1  // Even parity.
#define CW_ODD_PARITY   2  // Odd parity.


// Auto repeat and simple transfers mode :
// ---------------------------------------

// Mask values of "TransferMode" member of "CW_ACT_INFO" structure.

// Auto repeat transfer mode :

#define CW_AUTO_REPEAT_READ    1  // ---- ---- ---- --01 : Reading mode.
#define CW_AUTO_REPEAT_WRITE   2  // ---- ---- ---- --10 : Writing mode .

// Simple transfer mode :

#define CW_SIMPLE_READ        16  // ---- ---- -001 ---- : Reading authorized.
#define CW_SIMPLE_WRITE       32  // ---- ---- -010 ---- : Writing authorized.
#define CW_SIMPLE_SYNC_READ   64  // ---- ---- -100 ---- : Synchronous reading.


// Data table types :
// ------------------

// Values of "DataType" member of "CW_ACT_INFO" structure.

// "DataType" parameter of "CwGetTableInfo", "CwGetTableList" and
// "CwGetTableID" functions.

#define CW_BLANKFRAME_BIT		1 // Bit.
#define CW_BLANKFRAME_BYTE		2 // Byte (8 bits).
#define CW_BLANKFRAME_WORD		3 // Word (16 bits).
#define CW_BLANKFRAME_REAL		4 // Real (32 bits).
#define CW_BLANKFRAME_DWORD	5 // Double word (32 bits).

// Protocol starting datetime :
// ----------------------------

typedef struct
{
  CW_USHORT  Day;      // Day of the month  [1..31]
  CW_USHORT  Month;    // Month of the year [1..12]
  CW_USHORT  Hours;    // Hours             [0..23]
  CW_USHORT  Minutes;  // Minutes           [0..59]
  CW_USHORT  Seconds;  // Seconds           [0..59]

} CW_START_DATETIME;

typedef CW_START_DATETIME *CW_LP_START_DATETIME;

// Data table updating information :
// ---------------------------------

typedef struct
{
  CW_USHORT  Day;           //               / Day of the month  [1..31]
  CW_USHORT  Month;         // Modification |  Month of the year [1..12]
  CW_USHORT  Hours;         //   datetime   |  Hours             [0..23]
  CW_USHORT  Minutes;       //              |  Minutes           [0..59]
  CW_USHORT  Millisecs;     //               \ Milliseconds      [0..59999]
  CW_BOOL    NotModified;   // Data has not been modified since last update.
  CW_BOOL    SeveralModif;  // Data has been modified several times since last
                            //  update.
  CW_BOOL    OutDating;     // Out dating flag.
  CW_USHORT  nAction;       // Relative action user number.

} CW_UPDATE_INFO;

typedef CW_UPDATE_INFO *CW_LP_UPDATE_INFO;

// Pour CIMSERVER
typedef struct
{
  CW_USHORT  Day;           //               / Day of the month  [1..31]
  CW_USHORT  Month;         // Modification |  Month of the year [1..12]
  CW_USHORT  Hours;         //   datetime   |  Hours             [0..23]
  CW_USHORT  Minutes;       //              |  Minutes           [0..59]
  CW_USHORT  Millisecs;     //               \ Milliseconds      [0..59999]

} CW_LAST_UPDATE;

typedef CW_LAST_UPDATE *CW_LP_LAST_UPDATE;
// Fin pour CIMSERVER


// Action state word :
// -------------------

typedef struct
{
  CW_BIT LastExchangeFailed		: 1;  // Failure during last exchange.
  CW_BIT NetworkOutOfOrder		: 1;  // Network is out of order.
  CW_BIT EquipmentOutOfOrder	: 1;  // Equipment is out of order.
  CW_BIT TransferError			: 1;  // Transfer error.
  CW_BIT ProtocolError			: 1;  // Protocol error.
  CW_BIT CorrespondentError		: 1;  // Correspondent error.
  CW_BIT NetworkError			: 1;  // Network error.
  CW_BIT TimeoutError			: 1;  // Time-out error.
  CW_BIT AppliQueueFull			: 1;  // Application commands queue is full.
  CW_BIT AutoRepeatQueueFull	: 1;  // Auto repeat commands queue is full.
  CW_BIT PrioQueueFull			: 1;  // Time-critical commands queue is full.
  CW_BIT WatchUnsolicitedActive	: 1;  // Watch Unsollicited exchanges are active.	//#MODIFDL 27/03/06
  CW_BIT LastCmdInProgress		: 1;  // Last command in progress.
  CW_BIT AutoRepeatActive		: 1;  // Auto repeat exchanges are active.
  CW_BIT AutoRepeatInQueue		: 1;  // Auto repeat exchange cmd already in queue.
  CW_BIT ImageTableModified		: 1;  // Image table has been modified.

} CW_ACT_STATE;


// Action complementary state word (transfer error) :
// --------------------------------------------------

typedef struct
{
  CW_BIT FramingError  : 1;  // Framing error.
  CW_BIT OverrunError  : 1;  // Overrun error.
  CW_BIT ParityError   : 1;  // Parity error.
  CW_BIT ChecksumError : 1;  // Check-sum error.
  CW_BIT BreakError    : 1;  // Unexpected receiving break error.
  CW_BIT EchoError     : 1;  // Receiving echo error.
  CW_BIT SendError     : 1;  // Sending error.
  CW_BIT Reserved      : 9;  // Reserved.

} CW_ACT_TRANS_COMP_STATE;


// Action complementary state word (protocol error) :
// --------------------------------------------------

typedef struct
{
  CW_BIT UnknownFunction     : 1;  // Unknown receiving function.
  CW_BIT UnsupportedFunction : 1;  // Receiving function not implemented.
  CW_BIT FunctionWithoutACK  : 1;  // Sending function without acknowledgment.
  CW_BIT InvalidFunction     : 1;  // Invalid receiving function.
  CW_BIT Reserved1           : 1;  // Reserved.
  CW_BIT InvalidInfoNumber   : 1;  // Invalid number of information.
  CW_BIT InvalidAddress      : 1;  // Invalid address.
  CW_BIT Reserved2           : 1;  // Reserved.
  CW_BIT InvalidData         : 1;  // Invalid data (unauthorized values).
  CW_BIT Reserved3           : 1;  // Reserved.
  CW_BIT AddresseeNotReady   : 1;  // Addressee not ready.
  CW_BIT InvalidAddressee    : 1;  // Invalid addressee number.
  CW_BIT Reserved4           : 4;  // Reserved.

} CW_ACT_PROTO_COMP_STATE;


// Equipment state word :
// ----------------------

typedef struct
{
  CW_BIT OutOfOrder				: 1;  // Equipment is out of order.
  CW_BIT Unavailable			: 1;  // Unavailable equipment.
  CW_BIT InitError				: 1;  // Error during equipment initialization.
  CW_BIT StopError				: 1;  // Error during equipment stopping.
  CW_BIT LastCmdFailed			: 1;  // Failure during last command.
  CW_BIT Broadcast				: 1;  // Broadcasting equipment.
  CW_BIT Reserved1				: 2;  // Reserved.
  CW_BIT Active					: 1;  // Equipment is active.
  CW_BIT AutoRepeatActive		: 1;  // Auto repeat exchanges are active.
  CW_BIT AutoRepeatEnabled		: 1;  // Auto repeat exchanges are enabled.
  CW_BIT NS 					: 1;  // Invalid status #MODIFDL 26/01/96
  CW_BIT WatchUnsolicitedActive	: 1;  // Watch Unsollicited exchanges are active.
  CW_BIT Reserved2				: 3;  // Reserved.

} CW_EQT_STATE;


// Network state word :
// --------------------

typedef struct
{
  CW_BIT OutOfOrder				: 1;  // Network is out of order.
  CW_BIT InitError				: 1;  // Error during network initialization.
  CW_BIT StopError				: 1;  // Error during network stopping.
  CW_BIT HoldError				: 1;  // Network holding error.
  CW_BIT LastCmdFailed			: 1;  // Failure during last command.
  CW_BIT Reserved1				: 3;  // Reserved.
  CW_BIT Active					: 1;  // Network is active.
  CW_BIT AutoRepeatActive		: 1;  // Auto repeat exchanges are active.
  CW_BIT AutoRepeatEnabled		: 1;  // Auto repeat exchanges are enabled.
  CW_BIT Reserved2				: 1;  // Reserved.
  CW_BIT WatchUnsolicitedActive	: 1;  // Watch Unsollicited exchanges are active.
  CW_BIT Reserved3				: 3;  // Reserved.

} CW_NET_STATE;


//#MODIF JS - 01/08/1996

typedef struct
{
	CW_BIT OutOfOrder			: 1;
	CW_BIT InitError			: 1;
	CW_BIT StopError			: 1;
	CW_BIT Reserved1			: 5;
	CW_BIT Active				: 1;
	CW_BIT AutoRepeatActive	: 1;
	CW_BIT AutoRepeatEnabled: 1;
	CW_BIT Reserved2			: 5;

} CW_BOARD_STATE;


typedef struct
{
	CW_BIT Active		: 1;
	CW_BIT Configured	: 1;
	CW_BIT Reserved	: 14;

} CW_PRO_STATE;

//#ENDMODIF JS


// Action status :
// ---------------

typedef struct
{
  union
  {
    CW_USHORT     Word;
    CW_ACT_STATE  Flag;

  } State;                          // State word.

  union
  {
    CW_USHORT                Word;
    CW_ACT_TRANS_COMP_STATE  TransFlag;
    CW_ACT_PROTO_COMP_STATE  ProtoFlag;

  } CompState;                      // Complementary state word.

  CW_USHORT  ErrorCount;            // Errors count.
  CW_USHORT  AbortedExchangeCount;  // Aborted exchanges count.
												// #MODIFDL 09/04/96
  CW_USHORT  OkReadCount;  			// OK read exchanges count.
  CW_USHORT  DataModifyCount;			// Data modify count.

} CW_ACT_STATUS;

typedef CW_ACT_STATUS *CW_LP_ACT_STATUS;


// Equipment status :
// ------------------

typedef struct
{
  union
  {
    CW_USHORT     Word;
    CW_EQT_STATE  Flag;

  } State;                          // State word.

  CW_USHORT  ErrorCount;            // Errors count.
  CW_USHORT  TransferErrorCount;    // Transfer errors count.
  CW_USHORT  AbortedExchangeCount;  // Aborted exchanges count.

} CW_EQT_STATUS;

typedef CW_EQT_STATUS *CW_LP_EQT_STATUS;


// Network status :
// ----------------

typedef struct
{
  union
  {
    CW_USHORT     Word;
    CW_NET_STATE  Flag;

  } State;                          // State word.

  CW_USHORT  ErrorCount;            // Errors count.
  CW_USHORT  TransferErrorCount;    // Transfer errors count.
  CW_USHORT  AbortedExchangeCount;  // Aborted exchanges count.

} CW_NET_STATUS;

typedef CW_NET_STATUS *CW_LP_NET_STATUS;

//#MODIF JS - 29/07/1996

// Board Status
// ------------

typedef struct
{
	union
	{
		CW_USHORT     Word;
		CW_NET_STATE  Flag;

	} State;                          // State word.

	CW_USHORT  ErrorCount;            // Errors count.
	CW_USHORT  TransferErrorCount;    // Transfer errors count.
	CW_USHORT  AbortedExchangeCount;  // Aborted exchanges count.

} CW_BOARD_STATUS;

typedef CW_BOARD_STATUS *CW_LP_BOARD_STATUS;

//#ENDMODIF JS


//#MODIF JS - 01/08/1996

// Cimway status:
// --------------

typedef struct
{
	union
	{
		CW_USHORT		Word;
		CW_PRO_STATE	Flag;
	} State;

	CW_USHORT	ErrorCount;
	CW_USHORT	TransferErrorCount;
	CW_USHORT	AbortedExchangeCount;

} CW_PRO_STATUS;

typedef CW_PRO_STATUS *CW_LP_PRO_STATUS;

//#ENDMODIF JS


// Equipment identification :
// --------------------------

typedef struct
{
  CW_USHORT  nNetwork;             // Network order number.
  CW_USHORT  nPort;                // Port number.
  CW_USHORT  nEquipment;           // Equipment order number.
  CW_USHORT  nEquipmentOnNetwork;  // Equipment number on network.

} CW_EQT_ID;

typedef CW_EQT_ID *CW_LP_EQT_ID;


// Action identification :
// -----------------------

typedef struct
{
  CW_USHORT  OrderNumber;  // Action order number.

} CW_ACT_ID;

typedef CW_ACT_ID *CW_LP_ACT_ID;


// Data table identification :
// ---------------------------

typedef struct
{
  CW_USHORT  OrderNumber;  // Data table order number.

} CW_TAB_ID;

typedef CW_TAB_ID *CW_LP_TAB_ID;


// Protocol information :
// ----------------------

typedef struct
{
  CW_USHORT   Environment;     // Environment type.
  CW_USHORT   TotalNetwork;    // Total number of networks.
  CW_USHORT   TotalEquipment;  // Total number of equipments.
  CW_USHORT   TotalAction;     // Total number of actions.
  CW_USHORT   TotalTable;      // Total number of data tables.
  CW_LP_VOID  lpDESLIEN;       // Far pointer on the first "DESLIEN".
  CW_LP_VOID  lpDESMEM;        // Far pointer on the first "DESMEM".

} CW_PRO_INFO;

typedef CW_PRO_INFO *CW_LP_PRO_INFO;


//#MODIF JS - 29/07/1996

// Board Information
// -----------------

typedef struct
{

	CW_USHORT Type;
	CW_USHORT TotalNetwork;
	CW_USHORT TotalEquipment;

} CW_BOARD_INFO;

typedef CW_BOARD_INFO *CW_LP_BOARD_INFO;

//#ENDMODIF JS

// Network information :
// ---------------------

typedef struct
{
  CW_USHORT  NbEquipment;   // Number of equipments on the network.
  CW_USHORT  nPort;         // Port number.
// Pour CIMSERVER
  CW_USHORT  nProtoc;       // Protocol number
// Fin pour CIMSERVER
  CW_USHORT  Timeout;       // Time-out (in milliseconds).
  CW_ULONG   BaudRate;      // Transmission rate (in bauds).
  CW_USHORT  DataBits;      // Number of data bits.
  CW_USHORT  StopBits;      // Number of stop bits.
  CW_USHORT  Parity;        // Type of parity checking (none, odd, even).
  CW_BOOL    ModemSignals;  // Modem signals enabled.

} CW_NET_INFO;

typedef CW_NET_INFO *CW_LP_NET_INFO;


// Equipment information :
// -----------------------

typedef struct
{
  CW_USHORT  SpecificTimeout;  // Specific time-out (in milliseconds).
  CW_USHORT  ReturnTime;       // Return time (in milliseconds).
// Pour CIMSERVER
  CW_USHORT  EquipmentType;    // Type of equipment
  CW_USHORT  Actions;          // Number of actions on the Equipment 
  CW_USHORT  UserNumber;       // User number of the equipment
// Fin pour CIMSERVER
  CW_USHORT  DeltaTS;			// DeltaTS (in seconds) //#MODIFED 12/10/10 
  CW_USHORT  RoutingAddress;    //#MODIFED 17/04/13

} CW_EQT_INFO;

typedef CW_EQT_INFO *CW_LP_EQT_INFO;


// Transfer action information :
// -----------------------------

typedef struct
{
  CW_LP_VOID  lpDataTable;     // Far pointer on the data table.
  CW_USHORT   nTable;          // Data table user number.
  CW_USHORT   DataLength;      // Length of the data table (in bytes).
// Pour CIMSERVER
  CW_USHORT   DataEmpty;       // Number of bits unused in the last word.
  CW_USHORT   Init;            // Flag Data table initialised.
  CW_USHORT   nOrderTable;     // Data table Order number.
// Fin pour CIMSERVER
  CW_USHORT   DataType;        // Data type of the table.
  CW_USHORT   TransferMode;    // Auto repeat and simple transfers mode.
// Pour CIMSERVER
  CW_USHORT   Cadence;         // Pooling interval for auto repeat. 
// Fin pour CIMSERVER
// Pour ASFPM
  CW_LP_VOID  lpImageTable;    // Far pointer on the image table.
// Fin pour ASFPM

//# MODIFJS 26/06/1996
	CW_USHORT	EqtDataType;	// Equipment Data Type for this action
	CW_USHORT	EqtDataAddr;	// Equipment Data Address for this action
	CW_USHORT	SpecificField;  // Specific Field of the associated frame
//# ENDMODIF
    CW_BOOL     bSystemFrame;    //CW_TRUE si trame system sinon CW_FALSE

} CW_ACT_INFO;

typedef CW_ACT_INFO *CW_LP_ACT_INFO;


// Data table information :
// ------------------------

typedef struct
{
  CW_LP_VOID  lpDataTable;  // Far pointer on the data table.
  CW_USHORT   DataLength;   // Length of the data table (in bytes).

} CW_TAB_INFO;

typedef CW_TAB_INFO *CW_LP_TAB_INFO;


// Last CIMWAY error information :
// -------------------------------

typedef struct
{
  CW_USHORT  ReturnCode;                // Last command return code.
  CW_CHAR    Message [CW_ERR_MSG_LEN];  // Error message.
  CW_USHORT  Context;                   // CIMWAY command calling context.
  CW_USHORT  nCommand;                  // CIMWAY command number.
  CW_USHORT  nNetwork;                  // Network order number.
  CW_USHORT  nEquipment;                // Equipment order number.
  CW_USHORT  nAction;                   // Action user number.
  CW_USHORT  nTable;                    // Data table user number.
  CW_USHORT  nPriority;                 // Priority number [0..15].

} CW_ERR_INFO;

typedef CW_ERR_INFO *CW_LP_ERR_INFO;


// Audits compteur de lecteur et �criture :
// ---------------

typedef struct
{
	// Taille en octet de la struct
	CW_ULONG	Size;

	// Compteur de lecture OK.
	CW_ULONG	OkReadCount;

	// Compteur de d'�criture OK.
	CW_ULONG	OkWriteCount;

} CW_READWRITE_AUDIT;

//****************************************************************************
//*                            POUR CIMSERVER                                *
//****************************************************************************

//Definitions pour la recuperation des libelles
//---------------------------------------------

#define	LONG_ENG_CFG		160			/* multiple de 4 et > 87 */
#define	LG_ENREG_CFG		(unsigned long) LONG_ENG_CFG

#define	MAX_LIB				32			//#MODIFDL 25/06/96
												//Longueur maximum des libell�s support�s
												//pour le desvoie, despap, deslien, desmem

#define	TYPDESCRIPT			0
#define	TYPDESCOM			1
#define	TYPDESLIEN			2
#define	TYPDESMEM			3
#define	TYPDESVOIE			4
#define	TYPDESAP				5
#define	TYPDESPAG			6
#define	TYPDESDON			7

#define COMMENT_ER1            18
#define COMMENT_ER2            19
#define COMMENT_ER3            20
#define COMMENT_ER4            21
#define COMMENT_ER5            22
#define COMMENT_ER6            23
#define COMMENT_ER7            24


typedef struct S1_b
{
	 MOT	  code_des ;
	 MOT	  pos_bloc_info ;
	 } POS_DES_CFG_b;

typedef struct S2_b
{
	 MOT	  code_des ;
	 MOT	  nbre_occ ;
	 MOT	  pos_1occ ;
} POS_FIX_CFG_b;

typedef struct S3_b
{
	 MOT	  nbre_occ ;
	 MOT	  pos_1occ ;
	 } POS_VAR_CFG_b;

struct Sengdeb_b
  {
	 POS_DES_CFG_b	info_chainage_des[ 8 ];
	 MOT  version;
	 char	  filler[ LONG_ENG_CFG - 34 ];
	 };

struct Sengfix_b
  {
	 POS_FIX_CFG_b	info_fix_des[ 4 ];
	 char	  filler[ LONG_ENG_CFG - 24 ];
	 };

struct SengvarA_b
{
	 MOT	  code_des ;
	 MOT	  nbre_tot_occ ;
	 char	  filler[ LONG_ENG_CFG - 4 ];
	 };

struct SengvarB_b
  {
	 POS_VAR_CFG_b	  info_voie_des[ LONG_ENG_CFG / sizeof( POS_VAR_CFG_b) ];
	 };

typedef struct
  {
	 MOT ides ;
	 MOT nseq ;
	 }	Senete_b;

struct eng_lib 
  {
	 Senete_b ent_lib	;
	 MOT llglib ;
	 char	  lidlib[ 81 ] ;
	 char	  filler_lib[ LONG_ENG_CFG - 87 ] ;
	 };

struct eng_first
   {
   MOT fil1;
   MOT fil2;
   MOT suiv;
	char fil3[ LONG_ENG_CFG - 6 ] ;
   } ;

//#MODIFDL 25/06/96
struct s_lib 
  {
	 char	  lidlib[ MAX_LIB + 1 ] ;
  };


//#MODIF JS 16/12/97

typedef void (*LPFN_TRACE)( CW_ULONG, CW_LP_CHAR);
typedef void (*LPFN_RECORDERR)( CW_ULONG, CW_USHORT, CW_USHORT, CW_LPC_CHAR, CW_LPC_CHAR);
typedef CW_BOOL (*LPFN_OKTOTRACE)( CW_ULONG);

//#MODIFDL 21/09/01 Ptr sur fonction qui permet de savoir si l'objet appartient � la liste des postes producteurs
typedef int (*LPFN_ISINPRODUCTLIST)( LPCTSTR);

typedef bool (*LPFN_GETGBLINT)( int);


// Create thread

typedef HANDLE ( WINAPI *LPFN_CREATETHREAD)(
            LPCTSTR                 a_szName,
			LPTHREAD_START_ROUTINE	a_pfnStartAddress,			// [in]	 Function adress
			LPVOID					a_pParameter,				// [in]	 Parameter
			PHANDLE					a_phTreadHandle,			// [out] Thread handle, = NULL if create thread fails
			LPDWORD					a_pThreadId,				// [out] Thread ID 
			int						a_nPriority,				// [in]	 Priority
			UINT					a_nStackSize,				// [in]  stack size
			DWORD					a_dwCreationFlags,			// [in]  Flag
			LPSECURITY_ATTRIBUTES	a_lpSecurityAttrs);			// [in]  Security attributs

#define CW_RECERR_LVL_INFO     1
#define CW_RECERR_LVL_WARNING  2
#define CW_RECERR_LVL_FATAL    3

#define CW_RECERR_DST_MEMORY   0
#define CW_RECERR_DST_FILET    1
#define CW_RECERR_DST_SUIVI    2

// Define use for protecting CimWay driver
#define CW_DONGLE_KEY_PROTOC_1     1
#define CW_DONGLE_KEY_PROTOC_2     2

typedef struct
{
	CW_USHORT				usSize;
	CW_BOOL					bSimu;
	LPFN_TRACE				lpfnTrace;
	LPFN_RECORDERR			lpfnRecordErr;
	LPFN_OKTOTRACE			lpfnOkToTrace;
	CW_LP_CHAR				lpszApplicationPath;
	CW_LP_CHAR				lpszProjectPath;
	//#MODIFDL 21/09/01 Ptr sur fonction qui permet de savoir si l'objet appartient � la liste des postes producteurs
	LPFN_ISINPRODUCTLIST	lpfnIsInProductList;
	//#MODIFDL 02/03/06		si = TRUE alors cwAudit est aliment�
	CW_USHORT				bTraceEnable;
	//#MODIFDL 24/02/10		Creation de thread
	LPFN_CREATETHREAD		lpfnCreateThread;
    LPFN_GETGBLINT          lpfnGetGblInt;
} sCwBeginParameters;

//**
//** IsValidCwBeginParam
//**
//** sParams: pointeur sur la structure de parametres de CwBegin
//** pParam:  parametre membre de la structure que l'on doit verifier
//**
#define IsValidCwBeginParam( sParams, pParam)	\
	((( ( char *)&(sParams->pParam) - ( char *)&(sParams->usSize)) < sParams->usSize) \
	? CW_TRUE: CW_FALSE)

//#ENDMODIF JS

//****************************************************************************
//*                            LIBRARY FUNCTIONS                             *
//****************************************************************************

//============================================================================
//=                                                                          =
//=                      C I M L I B   S E R V I C E S                       =
//=                                                                          =
//============================================================================


CW_FCT CwBegin(
	CW_USHORT nRicTask);

//#MODIF JS 16/12/97
CW_FCT CwBeginEx(
	sCwBeginParameters *CwBeginParams);

CW_SUB CwEnd(
	void);

CW_FCT CwReadConfiguration(
	CW_LP_CHAR lpConfigurationFile);

CW_SUB CwGetProtocolInfo(
	CW_LP_PRO_INFO lpProtocolInfo);

CW_SUB CwGetNetworkInfo(
	CW_USHORT nNetwork,
	CW_LP_NET_INFO lpNetworkInfo);

CW_SUB CwGetEquipmentInfo(
	CW_USHORT nNetwork,
	CW_USHORT nEquipment,
	CW_LP_EQT_INFO lpEquipmentInfo);

CW_SUB CwGetActionInfo(
	CW_USHORT nAction,
	CW_LP_ACT_INFO lpActionInfo);

CW_SUB CwGetActionInfo_FromHandle(
	CW_HANDLE      hLink,
	CW_LP_ACT_INFO lpActionInfo);

CW_SUB CwGetActionInfoEx(
	CW_USHORT nAction,
	CW_LP_ACT_INFO lpActionInfo);

CW_SUB CwGetTableInfo(
	CW_USHORT nTable,
	CW_USHORT DataType,
	CW_LP_TAB_INFO lpTableInfo);

CW_SUB CwGetLastErrorInfo(
	CW_LP_ERR_INFO lpErrorInfo);

CW_SUB CwGetActionList(
	CW_LP_USHORT lpActionList);

CW_SUB CwGetTableList(
	CW_USHORT DataType,
	CW_LP_USHORT lpNbTable,
	CW_LP_USHORT lpTableList);



//============================================================================
//=                                                                          =
//=                     C I M W A Y   F U N C T I O N S                      =
//=                                                                          =
//============================================================================


//----------------------------------------------------------------------------
//-                         START / STOP FUNCTIONS                           -
//----------------------------------------------------------------------------

CW_FCT CwStartProtocol(
	CW_LP_START_DATETIME lpStartDateTime);

CW_FCT CwStopProtocol(
	void);

CW_FCT CwStartNetwork(
	CW_USHORT nNetwork);

CW_FCT CwStopNetwork(
	CW_USHORT nNetwork);

CW_FCT CwStartEquipment(
	CW_USHORT nNetwork,
	CW_USHORT nEquipment);

CW_FCT CwStopEquipment(
	CW_USHORT nNetwork,
	CW_USHORT nEquipment);

CW_FCT CwStartNetwork_FromHandle(
	CW_HANDLE hNetwork);

CW_FCT CwStopNetwork_FromHandle(
	CW_HANDLE hNetwork);

CW_FCT CwStartEquipment_FromHandle(
	CW_HANDLE hEqt);

CW_FCT CwStopEquipment_FromHandle(
	CW_HANDLE hEqt);

//----------------------------------------------------------------------------
//-                          READ / WRITE FUNCTIONS                          -
//----------------------------------------------------------------------------

CW_FCT CwRead(
	CW_USHORT nAction,
	CW_USHORT SyncMode,
	CW_USHORT ActionCode,
	CW_LP_ACT_STATUS lpActionStatus,
	BOOL bUseCache);

CW_FCT CwPartRead(
	CW_USHORT nAction,
	CW_USHORT SyncMode,
	CW_USHORT ActionCode,
	CW_USHORT StartPosition,
	CW_USHORT Length,
	CW_LP_ACT_STATUS lpActionStatus);

CW_FCT CwWrite(
	CW_USHORT nAction,
	CW_USHORT SyncMode,
	CW_USHORT ActionCode,
	CW_LP_ACT_STATUS lpActionStatus);

CW_FCT CwWriteSimu(
	CW_USHORT nAction,
	CW_LP_VOID lpDataTable);

CW_FCT CwPartWrite(
	CW_USHORT nAction,
	CW_USHORT SyncMode,
	CW_USHORT ActionCode,
	CW_USHORT StartPosition,
	CW_USHORT Length,
	CW_LP_ACT_STATUS lpActionStatus);

CW_FCT CwRead_FromHandle(
	CW_HANDLE hLink,
	CW_USHORT SyncMode,
	CW_USHORT ActionCode,
	CW_ULONG ulRequestId,//#MODIFFRM 22/08/03
	CW_LP_ACT_STATUS lpActionStatus,
	BOOL bUseCache);

CW_FCT CwPartRead_FromHandle(
	CW_HANDLE hLink,
	CW_USHORT SyncMode,
	CW_USHORT ActionCode,
	CW_USHORT StartPosition,
	CW_USHORT Length,
	CW_LP_ACT_STATUS lpActionStatus);

CW_FCT CwWrite_FromHandle(
	CW_HANDLE hLink,
	CW_USHORT SyncMode,
	CW_USHORT ActionCode,
	CW_LP_ACT_STATUS lpActionStatus);

CW_FCT CwPartWrite_FromHandle(
	CW_HANDLE hLink,
	CW_USHORT SyncMode,
	CW_USHORT ActionCode,
	CW_USHORT StartPosition,
	CW_USHORT Length,
	CW_LP_ACT_STATUS lpActionStatus);

//#MODIFFRM 28/04/03
CW_FCT CwPartWriteAsync_FromHandle(
	CW_HANDLE hLink,
	CW_USHORT ActionCode,
	CW_USHORT StartPosition,
	CW_USHORT Length,
	CW_HANDLE hClient,
	CW_TRANSACTID *pIdWriteTransaction
	);
//#ENDMODIFFRM 28/04/03

//------------------------------------------------
//- AUTO REPEAT FUNCTIONS
//------------------------------------------------

CW_FCT CwSetActionAutoRepeat(
	CW_USHORT nAction,
	CW_USHORT AutoRepeatFlag);

CW_FCT CwSetActionAutoRepeatInterval(
	CW_USHORT nAction,
	CW_USHORT NewInterval);

CW_FCT CwSetActionAutoRepeat_FromHandle(
	CW_HANDLE hLink,
	CW_USHORT AutoRepeatFlag);

CW_FCT CwSetActionAutoRepeatInterval_FromHandle(
	CW_HANDLE hLink,
	CW_USHORT NewInterval);

CW_FCT CwSetEquipmentAutoRepeat(
	CW_USHORT nNetwork,
	CW_USHORT nEquipment,
	CW_USHORT AutoRepeatFlag,
	CW_LP_USHORT lpNbAction);

CW_FCT CwSetNetworkAutoRepeat(
	CW_USHORT nNetwork,
	CW_USHORT AutoRepeatFlag,
	CW_LP_USHORT lpNbAction);

//------------------------------------------------
//- WATCH UNSOLICITED FUNCTIONS
//------------------------------------------------

CW_FCT CwSetActionWatchUnsolicited(
	CW_USHORT nAction,
	CW_USHORT WatchUnsolicitedFlag);

CW_FCT CwSetEquipmentWatchUnsolicited(
	CW_USHORT nNetwork,
	CW_USHORT nEquipment,
	CW_USHORT WatchUnsolicitedFlag,
	CW_LP_USHORT lpNbAction);

CW_FCT CwSetNetworkWatchUnsolicited(
	CW_USHORT nNetwork,
	CW_USHORT WatchUnsolicitedFlag,
	CW_LP_USHORT lpNbAction);


//----------------------------------------------------------------------------
//-                             UPDATE FUNCTIONS                             -
//----------------------------------------------------------------------------

CW_FCT CwUpdateDataTable(
	CW_USHORT nAction,
	CW_LP_UPDATE_INFO lpUpdateInfo);

CW_FCT CwUpdateImageTable(
	CW_USHORT nAction);

CW_FCT CwUpdateDataTable_FromHandle(
	CW_HANDLE hLink,
	CW_LP_UPDATE_INFO lpUpdateInfo);

CW_FCT CwUpdateImageTable_FromHandle(
	CW_HANDLE hLink);

CW_FCT CwUpdateDataTableByPriority(
	CW_USHORT nPriority,
	CW_LP_UPDATE_INFO lpUpdateInfo);

CW_FCT CwUpdateNetworkJournal(
	void);

CW_FCT CwUpdateChronoJournal(
	void);


//----------------------------------------------------------------------------
//-                             STATUS FUNCTIONS                             -
//----------------------------------------------------------------------------

CW_FCT CwGetActionStatus(
	CW_USHORT nAction,
	CW_LP_ACT_STATUS lpActionStatus);

CW_FCT CwGetActionStatus_FromHandle(
	CW_HANDLE        hLink,
	CW_LP_ACT_STATUS lpActionStatus);

//#MODIFDL 12/04/96
CW_FCT CwGetActionStatusAndCounter(
	CW_USHORT nAction,
	CW_LP_ACT_STATUS lpActionStatus);

CW_FCT CwGetEquipmentStatus(
	CW_USHORT nNetwork,
	CW_USHORT nEquipment,
	CW_LP_EQT_STATUS lpEquipmentStatus);

CW_FCT CwGetEquipmentStatus_FromHandle(
	CW_HANDLE        hEqt,
	CW_LP_EQT_STATUS lpEqtStatus);

CW_FCT CwGetNetworkStatus(
	CW_USHORT nNetwork,
	CW_LP_NET_STATUS lpNetworkStatus);

CW_FCT CwGetNetworkStatus_FromHandle(
	CW_HANDLE        hNetwork,
	CW_LP_NET_STATUS lpNetworkStatus);

CW_FCT CwClearActionErrorCount(
	CW_USHORT nAction);

CW_FCT CwClearEquipmentErrorCount(
	CW_USHORT nNetwork,
	CW_USHORT nEquipment);

CW_FCT CwClearNetworkErrorCount(
	CW_USHORT nNetwork);


//----------------------------------------------------------------------------
//-                         IDENTIFICATION FUNCTIONS                         -
//----------------------------------------------------------------------------

CW_FCT CwGetEquipmentID(
	CW_USHORT nAction,
	CW_LP_EQT_ID lpEquipmentID);

CW_FCT CwGetActionID(
	CW_USHORT nAction,
	CW_LP_ACT_ID lpActionID);

CW_FCT CwGetTableID(
	CW_USHORT nTable,
	CW_USHORT DataType,
	CW_LP_TAB_ID lpTableID);


//----------------------------------------------------------------------------
//-                         CYCLIC ACTIVATE                                   -
//----------------------------------------------------------------------------

CW_FCT CwCyclicActivate(
	void);

//----------------------------------------------------------------------------
//-                         MODIFY PARAMETER                                   -
//----------------------------------------------------------------------------

CW_FCT CwModifyActionParameter(
	CW_USHORT nAction, 
	CW_LP_CHAR pbuf);

CW_FCT CwModifyEquipmentParameter(
	CW_USHORT nNetwork,
	CW_USHORT nEquipment,
	CW_LP_CHAR  pbuf);

CW_FCT CwModifyNetworkParameter(
	CW_USHORT nNetwork,
	CW_LP_CHAR  pbuf);

CW_FCT CwModifyActionParameter_FromHandle(
	CW_HANDLE   hLink, 
	CW_LP_CHAR  pbuf);

CW_FCT CwModifyLinkUserAttributes_FromHandle(
	CW_HANDLE  hLink,
	CW_LPC_CHAR pbuf);

CW_FCT CwModifyLinkUserAttribute_FromHandle(
	CW_HANDLE   hLink,
	CW_USHORT   usIndex,
	CW_LPC_CHAR pbuf);

CW_FCT CwGetLinkUserAttributes_FromHandle(
	CW_HANDLE  hLink,
	CW_LP_CHAR szParam,
	int        iParamMaxSize);

CW_FCT CwGetLinkUserAttribute_FromHandle(
	CW_HANDLE  hLink,
	CW_USHORT  usIndex,
	CW_LP_CHAR szParam,
	int        iParamMaxSize);

CW_FCT CwModifyEquipmentParameter_FromHandle(
	CW_HANDLE   hEqt,
	CW_LP_CHAR  pbuf);

//#MODIFFRM 06/12/00
CW_FCT CwModifyEquipmentParameterEx_FromHandle(
	CW_HANDLE   hEqt,
	CW_USHORT pAddress,
	CW_LP_CHAR  pbuf,
	CW_USHORT pParametersCounter);
//#ENDMODIFFRM 06/12/00

CW_FCT CwModifyEquipmentUserAttributes_FromHandle(
	CW_HANDLE  hEqt,
	CW_LPC_CHAR pbuf);

CW_FCT CwModifyEquipmentUserAttribute_FromHandle(
	CW_HANDLE   hEqt,
	CW_USHORT   usIndex,
	CW_LPC_CHAR pbuf);

CW_FCT CwGetEquipmentUserAttributes_FromHandle(
	CW_HANDLE  hEqt,
	CW_LP_CHAR szParam,
	int        iParamMaxSize);

CW_FCT CwGetEquipmentUserAttribute_FromHandle(
	CW_HANDLE  hEqt,
	CW_USHORT  usIndex,
	CW_LP_CHAR szParam,
	int        iParamMaxSize);

CW_FCT CwModifyNetworkParameter_FromHandle(
	CW_HANDLE   hNetwork,
	CW_LP_CHAR  pbuf);

CW_FCT CwModifyNetworkUserAttributes_FromHandle(
	CW_HANDLE  hNetwork,
	CW_LPC_CHAR pbuf);

CW_FCT CwModifyNetworkUserAttribute_FromHandle(
	CW_HANDLE   hNetwork,
	CW_USHORT   usIndex,
	CW_LPC_CHAR pbuf);

CW_FCT CwGetNetworkUserAttributes_FromHandle(
	CW_HANDLE  hNetwork,
	CW_LP_CHAR szParam,
	int        iParamMaxSize);

CW_FCT CwGetNetworkUserAttribute_FromHandle(
	CW_HANDLE  hNetwork,
	CW_USHORT  usIndex,
	CW_LP_CHAR szParam,
	int        iParamMaxSize);

//****************************************************************************
//*                            POUR CIMSERVER  ou ASFPM                      *
//****************************************************************************
CW_SUB CwGetEquipmentList(
	CW_USHORT nNetwork,
	CW_LP_USHORT lpEquipmentList);

CW_SUB CwGetTotalTableList(
	CW_LP_USHORT lpTableList);

CW_SUB CwGetNetworkLib(
	CW_USHORT nNetwork,
	CW_LP_CHAR Lib);

CW_SUB CwGetEquipmentLib(
	CW_USHORT nNetwork, 
	CW_USHORT nEquipment,
	CW_LP_CHAR Lib);

CW_SUB CwGetActionLib(
	CW_USHORT nAction, 
	CW_LP_CHAR Lib);

CW_SUB CwGetTableLib(
	CW_USHORT nTable,
	CW_USHORT DataType,
	CW_LP_CHAR Lib);

CW_SUB CwGetTotalEquipmentLib(
	CW_USHORT nNetwork, 
	CW_USHORT nEquipment,
	CW_LP_CHAR Lib);
                               
CW_SUB CwGetTotalActionLib(
	CW_USHORT nAction, 
	CW_LP_CHAR Lib);

CW_SUB CwGetLastUpdate(
	CW_USHORT nAction ,
	CW_LP_LAST_UPDATE lpLastUpdate);


//*************************************************************************
//**
//** Fonctions n�cessaire � CW16
//**
//*************************************************************************

CW_SUB CwSetOS(
	int CwOS);

//*************************************************************************
//**
//** Envoi de messages aux objects protocoles
//**
//*************************************************************************

CW_FCT CwSendAllNetworksMessage(CW_LPC_CHAR szMessage);

CW_FCT CwSendNetworkMessage_FromHandle(CW_HANDLE   hNetwork,
									   CW_LPC_CHAR szMessage);

CW_FCT CwSendEquipmentMessage_FromHandle(CW_HANDLE   hEqt,
										 CW_LPC_CHAR szMessage);

CW_FCT CwSendFrameMessage_FromHandle(CW_HANDLE   hLink,
									 CW_LPC_CHAR szMessage);


//----------------------------------------------------------------------------
//-                          AUDIT READ / WRITE FUNCTIONS                          -
//----------------------------------------------------------------------------
//#MOFIDL 03/04/06

CW_FCT CwReadWriteNetworkAudit(
				LPCTSTR				a_pszNetwokId,
				CW_READWRITE_AUDIT	&a_RWAudit);
CW_FCT CwReadWriteEqtAudit(
				LPCTSTR				a_pszEqtId,
				CW_READWRITE_AUDIT	&a_RWAudit);
CW_FCT CwReadWriteFrameAudit(
				LPCTSTR				a_pszFrameId,
				CW_READWRITE_AUDIT	&a_RWAudit);

CW_FCT CwReadWriteNetworkAudit_FromHandle(
                CW_HANDLE			hNetwork,
                CW_READWRITE_AUDIT	&a_RWAudit);

CW_FCT CwReadWriteEqtAudit_FromHandle(
                CW_HANDLE	    	hEqt,
                CW_READWRITE_AUDIT	&a_RWAudit);

CW_FCT CwReadWriteFrameAudit_FromHandle(
                CW_HANDLE			hFrame,
                CW_READWRITE_AUDIT	&a_RWAudit);

//----------------------------------------------------------------------------
//-                          miscellaneous                        -
//----------------------------------------------------------------------------
//#MOFIDL 25/11/10

// Get function ptr to create thread
LPFN_CREATETHREAD WINAPI CwGetlpfnCreateThread();

CW_FCT CwBrowseNetwork_FromHandle(CW_HANDLE   hNetwork);

CW_FCT CwBrowseNetworkDevice_FromHandle(CW_HANDLE   hNetwork, LPCTSTR szDeviceId);

CW_FCT CwBrowseDevice_FromHandle(CW_HANDLE   hEqt);

#ifdef __cplusplus
}
#endif

#endif   // CIMLIB_INCLUDED

