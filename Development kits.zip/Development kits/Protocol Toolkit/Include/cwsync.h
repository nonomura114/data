/*
** cwsync.h
*/

#ifndef _CWSYNC_H_

	#define _CWSYNC_H_

	class CW_IMPORT_EXPORT _Sync: public CObject
	{
	protected:
		HANDLE	m_hSyncObject;

	public:
		_Sync( void);
		virtual ~_Sync( void);

		virtual CW_BOOL Lock(
			CW_ULONG ulTimeOut = INFINITE);

		virtual CW_BOOL Unlock( void)
			{ return CW_TRUE; }

		virtual CW_BOOL Unlock( LONG lCount, LPLONG lpPrevCount)
			{ return CW_TRUE; }

		virtual CW_BOOL IsSynchroLock( void);

		HANDLE GetHandle( void);		
	};

	class CW_IMPORT_EXPORT _Event: public _Sync
	{
	public:
		_Event(
			CW_BOOL bInitialState,
			CW_BOOL bManualReset,
			LPSTR lpszName,
			LPSECURITY_ATTRIBUTES lpEventAttributes = NULL);

		_Event(
			LPSTR lpszName,
			DWORD dwDesiredAccess = EVENT_ALL_ACCESS,
			CW_BOOL bInheritHandle = CW_FALSE);

		virtual ~_Event( void);
	
		CW_BOOL Unlock( void);

		CW_BOOL ResetEvent( void);
		CW_BOOL PulseEvent( void);
		CW_BOOL SetEvent( void);
	};

	class CW_IMPORT_EXPORT _CriticalSection: public _Sync
	{
	protected:
		CRITICAL_SECTION m_CriticalSection;

	public:
		_CriticalSection( void);
		virtual ~_CriticalSection( void);
	
		CW_BOOL Lock( void);
		CW_BOOL Unlock( void);
		CW_BOOL IsSynchroLock( void);
	};

	class CW_IMPORT_EXPORT _Semaphore: public _Sync
	{
	public:
		_Semaphore(
			LONG lInitialCount,
			LONG lMaximumCount,
			LPSTR lpszName,
			LPSECURITY_ATTRIBUTES lpSemaphoreAttributes = NULL);

		_Semaphore(
			LPSTR lpszName,
			DWORD dwDesiredAccess = SEMAPHORE_ALL_ACCESS,
			CW_BOOL bInheritHandle = CW_FALSE);

		virtual ~_Semaphore( void);
	
		CW_BOOL Release(
			LONG lCount,
			LPLONG lpPrevCount=NULL);
	
		CW_BOOL Release( void);
	};


	class _Mutex: public _Sync
	{
	public:
		_Mutex(
			CW_BOOL bInitialOwner,
			LPSTR lpszName,
			LPSECURITY_ATTRIBUTES lpMutexAttributes = NULL);

		_Mutex(
			LPSTR lpszName,
			DWORD dwDesiredAccess = MUTEX_ALL_ACCESS,
			CW_BOOL bInheritHandle = CW_FALSE);

		virtual ~_Mutex( void);

		CW_BOOL Unlock( void);
	};

#endif /* _CWSYNC_H_ */
