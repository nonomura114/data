

#ifndef _CWITEM_H_

	#define _CWITEM_H_


#define	SIZE_ID_ITEM	160	// Taille de l'ID d'un Item

union _CwKernelItemStatus
{
	struct
	{
		unsigned char bNS      : 1;
		unsigned char bUpdate  : 1;
		unsigned char bRefresh : 1;
		unsigned char bFormat  : 1;
		unsigned char bReserve : 4;
	} Flags;

	CW_UCHAR ucRaw;
};


union _CwProtocolItemStatus
{
	struct
	{
		unsigned char bOutDating : 1;
		unsigned char bNA        : 1;
		unsigned char bHisValue  : 1;		//#MODIFDL 08/10/10 =1 if it is a historic value
		unsigned char bReserve   : 5;
	} Flags;

	CW_UCHAR ucRaw;
};


union _CwItemStatus
{
	struct
	{
		_CwKernelItemStatus   Kernel;
		_CwProtocolItemStatus Protocol;

	} Flags;

	CW_USHORT usRaw;

inline	bool	IsHisValue()		{ return (Flags.Protocol.Flags.bHisValue) ? true : false; } // = true if it is a historic value
inline	void	SetHisValue()		{ Flags.Protocol.Flags.bHisValue = 1; }							
inline	void	ResetHisValue()		{ Flags.Protocol.Flags.bHisValue = 0; }							
};


union _CwItemValue
{
	CW_BOOL  log;      // Etat
	CW_BYTE  ana8b;    // Analogique codee sur un entier 8 bits
	CW_WORD  ana16b;   // Analogique codee sur un entier 16 bits
	CW_DWORD ana32b;   // Analogique codee sur un entier 32 bits
	CW_REAL  anaFloat; // Analogique codee
	                   // sur un reel IEEE simple precision ( 32 bits)
	CW_DWORD dwRaw;    // Valeur brute
};



struct _CwItemDataAttributs
{
	_CwProtocolItemStatus ProtItemStatus;
	_CwItemValue          ItemValue;
	_TimDat               ItemHDate;
};


#endif // _CWITEM_H_
