#pragma once
 
#if defined( _MSC_VER ) && ( _MSC_VER >= 1200 )
// Microsoft C/C++ compiler version 12.0 or above is used
#else
#error Microsoft C/C++ compiler version 12.0 or above is required
#endif

#ifndef __cplusplus
#error CW32 protocols requires C++ compilation (use a .cpp suffix)
#endif

#ifndef _AFXDLL
#error CW32 protocols requires MFC in a shared DLL (see general project settings)
#endif

#include "cwimpexp.h"
#include "cw_types.h"
#include "cimlib.h"
#include "cwinc.h"
#include "cwsync.h"
#include "cwlnklst.h"
#include "cwmailb.h"
#include "cwthread.h"
#include "cwllist.h"
#include "cwad.h"
#include "cwconv.h"
#include "cwsys.h"
#include "cwtimdat.h"
#include "cwtrace.h"
#include "cwaudit.h"
#include "cwtimer.h"
#include "cwerror.h"
#include "cwcomprm.h"
#include "cwioerr.h"
#include "cwio.h"
#include "cwioser.h"
#include "cwngiosr.h"
#include "cwiotcp.h"
#include "cwiotapi.h"
#include "cwvers.h"
#include "cwapi.h"
#include "cwitem.h"
#include "cwobj.h"
#include "cwtype.h"
#include "cwitem2.h"
#include "cw.h"
#include "cwcmd.h"
#include "cwcmdprt.h"
#include "cwprot.h"
