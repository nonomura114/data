/*
** cwcomprm.h
*/

//#MODIFFRM 20/03/01
/*typedef enum
{
	SERIAL_PORT_UNDEFINED = -1,
	SERIAL_PORT_COM1      = 1,
	SERIAL_PORT_COM2      = 2,
	SERIAL_PORT_COM3      = 3,
	SERIAL_PORT_COM4      = 4,
	SERIAL_PORT_COM5      = 5,
	SERIAL_PORT_COM6      = 6,
	SERIAL_PORT_COM7      = 7,
	SERIAL_PORT_COM8      = 8,
	SERIAL_PORT_COM9      = 9,
	SERIAL_PORT_COM10     = 10,
	SERIAL_PORT_COM11     = 11,
	SERIAL_PORT_COM12     = 12,
	SERIAL_PORT_COM13     = 13,
	SERIAL_PORT_COM14     = 14,
	SERIAL_PORT_COM15     = 15,
	SERIAL_PORT_COM16     = 16,
	SERIAL_PORT_COM17     = 17,
	SERIAL_PORT_COM18     = 18,
	SERIAL_PORT_COM19     = 19,
	SERIAL_PORT_COM20     = 20,
	SERIAL_PORT_COM21     = 21,
	SERIAL_PORT_COM22     = 22,
	SERIAL_PORT_COM23     = 23,
	SERIAL_PORT_COM24     = 24,
	SERIAL_PORT_COM25     = 25,
	SERIAL_PORT_COM26     = 26,
	SERIAL_PORT_COM27     = 27,
	SERIAL_PORT_COM28     = 28,
	SERIAL_PORT_COM29     = 29,
	SERIAL_PORT_COM30     = 30,
	SERIAL_PORT_COM31     = 31,
	SERIAL_PORT_COM32     = 32

} _Serial_Port;*/

#define SERIAL_PORT_UNDEFINED -1
//#ENDMODIFFRM 20/03/01

typedef enum
{
	SERIAL_BAUDRATE_UNDEFINED = -1,
	SERIAL_BAUDRATE_50        = 50L,
	SERIAL_BAUDRATE_75        = 75L,
	SERIAL_BAUDRATE_110       = 110L,
	SERIAL_BAUDRATE_150       = 150L,
    SERIAL_BAUDRATE_300       = 300L,
    SERIAL_BAUDRATE_600       = 600L,
    SERIAL_BAUDRATE_1200      = 1200L,
    SERIAL_BAUDRATE_2400      = 2400L,
    SERIAL_BAUDRATE_4800      = 4800L,
    SERIAL_BAUDRATE_9600      = 9600L,
    SERIAL_BAUDRATE_14400     = 14400L,
    SERIAL_BAUDRATE_19200     = 19200L,
    SERIAL_BAUDRATE_38400     = 38400L,
    SERIAL_BAUDRATE_56000     = 56000L,
    SERIAL_BAUDRATE_128000    = 128000L,
    SERIAL_BAUDRATE_256000    = 256000L

} _Serial_BaudRate;

typedef enum
{
	SERIAL_STOPBIT_UNDEFINED  = -1,
	SERIAL_STOPBIT_1,           // 1 stop bit
	SERIAL_STOPBIT_1_5,         // 1.5 stop bits
	SERIAL_STOPBIT_2            // 2 stop bits

} _Serial_StopBit;

typedef enum
{
	SERIAL_PARITY_UNDEFINED  = -1,
	SERIAL_PARITY_NO         = 0,  // No Parity
	SERIAL_PARITY_ODD        = 1,  // Odd
	SERIAL_PARITY_EVEN       = 2,  // Even
	SERIAL_PARITY_MARK       = 3,  // Mark
	SERIAL_PARITY_SPACE      = 4   // Space

} _Serial_Parity;

typedef enum
{
	SERIAL_BYTESIZE_UNDEFINED = -1,
	SERIAL_BYTESIZE_4         = 4,   // Size: 4 bits 
	SERIAL_BYTESIZE_5         = 5,   // Size: 5 bits 
	SERIAL_BYTESIZE_6         = 6,   // Size: 6 bits 
	SERIAL_BYTESIZE_7         = 7,   // Size: 7 bits 
	SERIAL_BYTESIZE_8         = 8    // Size: 8 bits 

} _Serial_ByteSize;

typedef struct
{
//#MODIFFRM 20/03/01
	//_Serial_Port      espPort;
	short espPort;
//#ENDMODIFFRM 20/03/01
	_Serial_BaudRate  esbrBaudRate;
	_Serial_StopBit   essbStopBit;
	_Serial_Parity    espParity;
	_Serial_ByteSize  esbsByteSize;

} _Serial_Parameters;

