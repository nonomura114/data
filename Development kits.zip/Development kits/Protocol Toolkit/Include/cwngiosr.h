/*--------------------------------------------------------------------------*/
/*																			*/
/*		PROJECT		:	LIBRAIRIE GENERIQUE D'ACCES A LA COUCHE PHYSIQUE	*/
/*																			*/
/*		MODULE		:	cwngiosr.h											*/
/*																			*/
/*		VERSION		:	1.00												*/
/*																			*/
/*		SYSTEMES	:	Windows 95 , Windows NT								*/
/*																			*/
/*		AUTHOR		:	Eric PERROTIN										*/
/*																			*/
/*		PURPOSE		:	Classe permettant d'activer les protocoles nouvelle	*/
/*						g�n�ration											*/
/*						Services d'acc�s au port s�rie						*/
/*																			*/
/*--------------------------------------------------------------------------*/


#ifndef _CWNGIOSR_H_

	#define _CWNGIOSR_H_

class _ProtNetwork;
class _ProtEqt;

//******************************
//
//	_CwNGIOSer Class
//
//******************************
class  CW_IMPORT_EXPORT _CwNGIOSer: public _CwIO_Serial 
{
// Constructor
public:

	_CwNGIOSer( _CwBaseNetwork *pNetworkOwner);  //#MODIFJS 10/03/99 - Gestion des param�tres s�ries (Prot. NG)

//***
//***	Activation of the protocol
//***
private:
	CW_BOOL			ProcessRead( CW_VOID );


//***
//***	Pointer to _ProtNetwork
//***
private:
	_ProtNetwork	*m_pProtNetwork;

	CW_VOID			SetProtNetwork( _ProtNetwork * );
	_ProtNetwork	*GetProtNetwork( CW_VOID );


//***
//***	SERVICES 
//***
public:
	CW_USHORT		NGSendFrame(			_ProtEqt *,
											CW_LP_UCHAR, CW_USHORT, 
											CW_USHORT );

	CW_USHORT		NGSendBreak(			_ProtEqt *,
											CW_USHORT );
		
	CW_USHORT		NGRcvFrame(				_ProtEqt *,
											CW_LP_UCHAR, CW_USHORT, 
											CW_USHORT );
						
	CW_USHORT		NGSendRcvFrame(			_ProtEqt *,
											CW_LP_UCHAR, CW_USHORT, 
											CW_LP_UCHAR, CW_USHORT, 
											CW_USHORT );
	
	CW_USHORT		NGSendBreakRcvFrame(	_ProtEqt *,
											CW_USHORT,
											CW_LP_UCHAR, CW_USHORT, 
											CW_USHORT );

};

#endif