#ifndef _CWNET_H_
#define _CWNET_H_


//************************************************
//**
//** _CwBaseNetworkThread
//**
//************************************************
class _CwBaseNetworkThread: public _CwThreadMail
{
private:
	_CwBaseNetwork	*m_pCwBaseNetwork;	// Pointeur sur l'objet NETWORK

public:
	_CwBaseNetworkThread(
		CString        &csThreadName,
		_CwBaseNetwork *pCwBaseNetwork);

protected:
	void SpecificRun( CW_ULONG ulEvent);
};


//************************************************
//**
//** _CwBaseNetwork
//**
//************************************************
class CW_IMPORT_EXPORT _CwBaseNetwork: public _CommunicationObject
{
	DECLARE_DYNAMIC( _CwBaseNetwork)

public:
	//***
	//*** Network - Gestion du Thread Protocol Network
	//***
	#define THREADNET_NAME	"CwThreadNet_%s"
	_CwBaseNetworkThread  *m_ThreadProtocolNetwork;
	
	//***
	//*** Network - Gestion du Thread Timer
	//***
	#define THREADTIMER_NAME	"CwThreadTimer_%s"
	_CwThreadTimer	*m_ThreadTimer;

	//***
	//*** Network - Configuration
	//***
public:

	CW_USHORT   GetEqtFromName( char *pszName, _CwBaseEqt **pEqtOut);

private:

	#define DEFAULT_UPHOLD   50
	#define DEFAULT_TIMEOUT  200

	_CwVersion  *m_pProtVersion;

private:

	virtual void  LoadProtocolVersion( void);
	CW_USHORT     LookAndSignalForManufacturerDLL( void);

public:

	CW_USHORT   GetProtocolVersion( struct _CwVersion *pProtVersion);

private:

	CW_USHORT	m_usProtocolType;

    CW_BOOL     m_bBeforeCyclicCommand;

public:

	// m�morisation of protocol type
	CW_VOID		SetProtocolType( CW_USHORT usProtocolType) { m_usProtocolType = usProtocolType; }
	CW_USHORT	GetProtocolType( CW_VOID)                  { return m_usProtocolType; }

protected:

	_LinkedList *m_llEqt;
	_LinkedList *m_llFrame;
	_LinkedList *m_llCyclicFrame;
	_LinkedList *m_llWatchUnsolicitedFrame;

	CW_CHAR		m_lpszManufacturerDLL[128];	// Nom de la DLL constructeur
	CW_CHAR		m_lpszProtocDLL[128];		// Nom d'origine dans PROTOC.DAT
	CW_CHAR		m_lpszRenProtocDLL[128];	// Nom renomm� en fct du rang du protocole
	HINSTANCE   m_hinstProtocDLL;

	CW_USHORT   LoadProtocDLL( void);
	void        FreeProtocDLL( void);

	virtual CW_BOOL   OnLoadProtocDLL( void)  { return CW_TRUE; }

private:

	MSECS       m_msUpholdPeriod;
	MSECS       m_msUpholdStartTime; // Heure de d�clenchement du timer pour le maintien r�seau

	MSECS       m_msTimeOut;
	MSECS       m_msTurnAroundTime;		// D�lai de retournement

	_Serial_Parameters  m_spSerialParameters;  //#MODIFJS 10/03/99 - Gestion des param�tres s�ries (Prot. NG)

	//#MODIFFRM 19/03/01
	CW_CHAR		m_pcPortName[MAX_PATH];
public:

	CW_ULONG    GetNbEqt( void)                    { return LL_COUNT( m_llEqt); }
	CW_ULONG    GetNbFrame( void)                  { return LL_COUNT( m_llFrame); }
	CW_ULONG    GetNbCyclicFrame( void)            { return LL_COUNT( m_llCyclicFrame); }
	CW_ULONG    GetNbWatchUnsolicitedFrame( void)  { return LL_COUNT( m_llWatchUnsolicitedFrame); }

	void        SetUpholdPeriod( MSECS msPeriod);

	void        SetTimeOut( MSECS msTimeOut);
	void        SetTurnAroundTime( MSECS msTurnAroundTime);
	
	MSECS       GetTimeOut( void)         { return m_msTimeOut; }
	MSECS       GetTurnAroundTime( void)  { return m_msTurnAroundTime; }

	void        StartTurnAroundTime( void);
	void		ProcessTurnAroundTime( void);
	CW_BOOL		IsProcessingTurnAround( void);

	void        GetSerialParameters( _Serial_Parameters &spSerialParameters);  //#MODIFJS 10/03/99 - Gestion des param�tres s�ries (Prot. NG)
	void        SetSerialParameters( _AD *adFile);  //#MODIFJS 10/03/99 - Gestion des param�tres s�ries (Prot. NG)
	void        DumpSerialParameters( void);        //#MODIFJS 10/03/99 - Gestion des param�tres s�ries (Prot. NG)

protected:

	virtual void      OnSetUpholdPeriod( MSECS msPeriod)             {}
	virtual void      OnSetTimeOut( MSECS msTimeOut)                 {}
	virtual void      OnSetTurnAroundTime( MSECS msTurnAroundTime)   {}

	virtual void      ResetConfiguration( void);

	//***
	//*** Network - States
	//***

private:

	CW_BOOL     m_bAvailableManaging;	// TRUE, if the Net manages the disponibility
	
	//#MODIFJS 23/03/98
	CW_LBOOL    m_lbUpholdInTail;   // CW_BOOL -> CW_LBOOL for interlocked operation
	CW_LBOOL    m_lbUpholdActive;   // CW_BOOL -> CW_LBOOL for interlocked operation


public:

	void        SetAvailableManaging( void);
	void        ResetAvailableManaging( void);
	CW_BOOL     IsAvailableManaging( void)     { return m_bAvailableManaging; }

	virtual CW_BOOL	IsAvailable( void) { return CW_TRUE; }

	void        SetUpholdActive( void);
	void        ResetUpholdActive( CW_BOOL bInitialReset);

	void        SetUpholdInTail( void);
	void        ResetUpholdInTail( void);

protected:

	virtual void	OnSetAvailableManaging( void)    {}
	virtual void	OnResetAvailableManaging( void)  {}
	virtual void	OnSetUpholdActive( void)         {}
	virtual void	OnResetUpholdActive( void)       {}
	virtual void	OnSetUpholdInTail( void)         {}
	virtual void	OnResetUpholdInTail( void)       {}
	
public:

	CW_BOOL     IsUpholdInTail( void)   { return m_lbUpholdInTail == CW_LTRUE? CW_TRUE: CW_FALSE; }
	CW_BOOL     IsUpholdActive( void)   { return m_lbUpholdActive == CW_LTRUE? CW_TRUE: CW_FALSE; }

protected:

	void        ResetStates( void);
	

public:

	virtual CW_USHORT GetFluxManagement( void)	// Lecture du type de flux g�r� par le protocol
		{ return CW_FLUX_MONO; } 				// (virtuel car d�riv�e par le protocol, par 
												// d�faut MONO_FLUX)
protected:

	CW_USHORT	m_usFlux;			// M�morisation du type de flux g�r� par le protocole
	void		SetFlux( CW_USHORT usFlux)  { m_usFlux = usFlux; }

public:

	CW_USHORT	GetFlux( void) { return m_usFlux; }

    bool        GetDongleRight(int iKey); 

    //***
	//*** Network - State Errors
	//***

private:

	CW_BOOL     m_bUpholdError;
	CW_BOOL     m_bLastCmdFailed;

public:

	void        SetUpholdError( void);
	void        ResetUpholdError( void);
	void        SetLastCmdFailed( void);
	void        ResetLastCmdFailed( void);

protected:

	virtual void      OnSetUpholdError( void)      {}
	virtual void      OnResetUpholdError( void)    {}
	virtual void      OnSetLastCmdFailed( void)    {}
	virtual void      OnResetLastCmdFailed( void)  {}

public:

	CW_BOOL     IsUpholdError( void)    { return m_bUpholdError; }
	CW_BOOL     IsLastCmdFailed( void)  { return m_bLastCmdFailed; }

	void        ResetStateErrors(BOOL bResetOutOfOrder = TRUE );//#MODIFFRM 02/07/04


	//***
	//*** Network - Constructor & Destructor
	//***

public:

		_CwBaseNetwork( void);
		virtual ~_CwBaseNetwork( void);

	CW_USHORT   Initialize(
		CW_USHORT UserId,
		_CwBaseBoard *Owner,
		_AD *adFile);

	void        TerminateTimer( void);
	void        Terminate( void);

protected:

	virtual CW_USHORT BeforeInitialize( _AD *adFile)  { return CW_OK; }
	virtual CW_USHORT AfterInitialize( _AD *adFile)   { return CW_OK; }

	//***
	//*** Network - Specific Construction
	//***

public:

	CW_USHORT   CreateEqt( _AD *adFile);
	CW_USHORT   CreateFrame( _AD *adFile);

	virtual _CwBaseEqt *OnCreateEqt( CW_USHORT EqtType);

	CW_ULONG	RegistryEqt( _CwBaseEqt *Eqt);
	void		RegistryFrame( _CwBaseFrame *Frame);
	void        RegistryCyclicFrame( _CwBaseFrame *Frame);
	void        RegistryWatchUnsolicitedFrame( _CwBaseFrame *Frame);
	void		RegistryLink( _CwBaseLink *Link);
	void		RegistryData( _CwBaseData *Data);

	void        UnregistryEqt( _CwBaseEqt *Eqt);
	void        UnregistryFrame( _CwBaseFrame *Frame);
	void        UnregistryCyclicFrame( _CwBaseFrame *Frame);
	void        UnregistryWatchUnsolicitedFrame( _CwBaseFrame *Frame);
	void        UnregistryLink( _CwBaseLink *Link);
	void        UnregistryData( _CwBaseData *Data);

protected:

	virtual void      OnRegistryEqt( _CwBaseEqt *Eqt)                        {}
	virtual void      OnRegistryFrame( _CwBaseFrame *Frame)                  {}
	virtual void      OnRegistryCyclicFrame( _CwBaseFrame *Frame)            {}
	virtual void      OnRegistryWatchUnsolicitedFrame( _CwBaseFrame *Frame)  {}
	virtual void      OnRegistryLink( _CwBaseLink *Link)                     {}
	virtual void      OnRegistryData( _CwBaseData *Data)                     {}

	virtual void      OnUnregistryEqt( _CwBaseEqt *Eqt)                      {}
	virtual void      OnUnregistryFrame( _CwBaseFrame *Frame)                {}
	virtual void      OnUnregistryCyclicFrame( _CwBaseFrame *Frame)          {}
	virtual void      OnUnregistryWatchUFrame( _CwBaseFrame *Frame)          {}
	virtual void      OnUnregistryLink( _CwBaseLink *Link)                   {}
	virtual void      OnUnregistryData( _CwBaseData *Data)                   {}

	//***
	//*** Network - Management routines
	//***

public:

	CW_USHORT   GetInfo( CW_LP_NET_INFO lpInfo);
	CW_USHORT   GetStatus( CW_LP_NET_STATUS lpStatus);
	CW_USHORT	GetReadWriteAudit( CW_READWRITE_AUDIT	&a_RWAudit);

	CW_USHORT	m_usFlipFlop;
	void        CyclicActivate( void);

protected:

	CW_USHORT   ReadyToBeActivate( void);
	void        SpecificStart( void);
	CW_USHORT   StartCommand( CW_USHORT usMode);

	CW_USHORT   ReadyToBeInactivate( void);
	CW_USHORT   StopCommand( CW_BOOL bInternalStop, CW_USHORT usMode);

	CW_USHORT   IsCyclicReadyToBeActivate( CW_BOOL bFullStart, CW_BOOL bInconditionalStart);
	void        SpecificStartCyclic( void);
	void        SpecificStopCyclic( void);

	CW_USHORT   IsWatchUnsolicitedReadyToBeActivate( CW_BOOL bFullStart);
	void        SpecificStartWatchUnsolicited( void);
	void        SpecificStopWatchUnsolicited( void);

	virtual void      OnGetInfo( CW_LP_NET_INFO lpInfo)        {}
	virtual void      OnGetStatus( CW_LP_NET_STATUS lpStatus)  {}

public:
	void        SpecificStop( CW_BOOL bInternalStop);
	CW_USHORT   AfterStopCommand(CW_BOOL bInternalStop) override; 
	void		WaitEqtsStart();
	void		WaitEqtsStop();

    void		WaitMailBoxIsEmpty();               // #MODIFDL 20/02/17


	virtual void   OnInitialize(_AD *adFile) {}
	virtual void   OnTerminate(void) {}

	virtual void   StartCyclicCommand( void);
	virtual void   StopCyclicCommand( void);
	virtual void   StartWatchUnsolicitedCommand( void);
	virtual void   StopWatchUnsolicitedCommand( void);

	void SendMessage(LPCTSTR szMessage);
	virtual void   OnReceiveMessage( LPCTSTR szMessage) {}


	void Browse(void);
	void BrowseNetworkDevice(LPCTSTR szDeviceId);




	//***
	//*** Network - Find Methods
	//***

public:

	CW_USHORT   FindEqt_UserId(
		CW_USHORT usEqt_UserId,
		_CwBaseEqt **Eqt);

	CW_USHORT   FindEqt_Rank(
		CW_USHORT usEqt_Rank,
		_CwBaseEqt **Eqt);

	CW_USHORT   FindEqt_Number(
		CW_USHORT usEqt_Number,
		_CwBaseEqt **Eqt);

	CW_USHORT   FindFrame_UserId(
		CW_USHORT usEqt_UserId,
		CW_USHORT usFrame_UserId,
		_CwBaseFrame **Frame);

	CW_USHORT   FindFrame_Rank(
		CW_USHORT usEqt_Rank,
		CW_USHORT usFrame_Rank,
		_CwBaseFrame **Frame);

	CW_USHORT   FindFrame_Number(
		CW_USHORT usEqt_Number,
		CW_USHORT usFrame_Number,
		_CwBaseFrame **Frame);


	//***
	//*** Network - Gestion des I/O
	//***

public:
	_CwIO		*m_CwIO;
	CW_ULONG	GetLayerOne( void) { return m_ulLayerOne; }

private:
	CW_ULONG	m_ulLayerOne;			// Type de couche 1

	void		SetLayerOne(CW_ULONG LayerOne);
	void		OnSetLayerOne(CW_ULONG LayerOne)   {}
	CW_USHORT	InitializeLayerOne( _AD *adFile);
	void        LayerOneTerminate( void);


	//***
	//*** Network - Command Management Routines
	//***

private:

	CW_CHAR		m_szSynchroEventName[SIZE_MAX_SYNCHROEVENT_NAME];
	_Event		*m_SynchroEvent;

	_CriticalSection m_csCommandEndOrAbort;
	_LinkSingleList	*m_llCommandEndOrAbort;		// Cmdes termin�es ou avort�es

	CW_BOOL     ExecuteCmd( _Command *Cmd);

	CW_BOOL     m_bSynchrone;         // Commande en cours est-elle synchrone ?
	CW_USHORT   m_SyncResult;         // Compte-rendu d'ex�cution de la derniere commande synchrone

public:

	CW_LONG     m_lProtocolWorking;

protected:

	CW_USHORT	ClearCmd( _Command *);

	_CriticalSection m_csCommandInProgress;
	_LinkSingleList *m_llCommandInProgress;		// Cmdes en traitement

	void		ControlCommandProtocolInProgress( void);

	_CriticalSection   m_csExtraction;

   	CW_USHORT   SendMessage(_Command *);

public:

	CW_USHORT	WriteCmd( _Command *, CW_BOOL);		// Envoi d'une commande protocole
	CW_USHORT	WriteCmdResp( _Command *);	// Envoi d'une r�ponse d'une commande protocole

	void		TerminateCmd( _Command *);

	void		SetSyncResult( CW_USHORT usSyncResult) { m_SyncResult = usSyncResult;}
	CW_LP_CHAR	GetSynchroEventName( void)             { return m_szSynchroEventName; }
	_Event		*GetSynchroEvent( void)                { return m_SynchroEvent; }

	void		SetProtocolWorking( void)    { InterlockedExchange( &m_lProtocolWorking, 0L); }
	void		ResetProtocolWorking( void)  { InterlockedExchange( &m_lProtocolWorking, 1L); }
	CW_USHORT	GetProtocolWorking( void)    { return (CW_USHORT)m_lProtocolWorking; }
	
	virtual void ControlCommandInProgress( void);
	
protected:

	CW_USHORT   PutCyclicCommand( _CwBaseFrame *Frame);
	CW_USHORT   PutUpholdCommand( void);

    inline void  BeforeCyclicCommand() { m_bBeforeCyclicCommand = CW_TRUE; }
    void        AfterCyclicCommand();

public:

    inline CW_BOOL IsBeforeCyclicCommand() { return m_bBeforeCyclicCommand; }

	void        SetValid( void);
	void        SetInvalid( _ProtError *pErr);
	void        DispatchInvalid( CW_BOOL bDispatchToSystemFrame);

public:

	virtual _ProtRet  Start_Async(
		_ProtStartNetworkCmd *pStartNetworkCmd);

	virtual _ProtRet  Stop_Async(
		_ProtStopNetworkCmd *pStopNetworkCmd);

	virtual _ProtRet  CyclicScan_Async(
		_ProtCyclicScanCmd *pCyclicScanCmd);

	virtual void      AbortStartNetworkCmd(
		_ProtStartNetworkCmd *pStartNetworkCmd);

	virtual void      AbortStopNetworkCmd(
		_ProtStopNetworkCmd *pStopNetworkCmd);

	virtual void      AbortCyclicScanCmd(
		_ProtCyclicScanCmd *pCyclicScanCmd);

    virtual _ProtRet  Browse_Async(
        _ProtBrowseNetworkCmd *pBrowseCmd);

    virtual void    AbortBrowseNetworkCmd(
        _ProtBrowseNetworkCmd *pBrowseCmd);

	virtual _ProtRet  BrowseNetworkDevice_Async(
		_ProtBrowseNetworkDeviceCmd *pBrowseDeviceCmd);

 
protected:

	union _AvailableStatus
	{
		struct {
			CW_ULONG  fAvailable:1;		// 1 : Le ComObject est indisponible
			CW_ULONG  fTurnAround:1;	// 1 : Le ComObject ex�cute un d�lai de retournement
			CW_ULONG  fNs:1;			// 1 : Le ComObject est en erreur
			CW_ULONG  fDummy:30;
		} m_ulFlagAvailableStatus;

		CW_ULONG m_StateAvailableStatus;
	
	} m_ulAvailableStatus;

public:

	_CriticalSection	m_csAvailableStatus;
	CW_BOOL				IsAvailableStatus( void);

	//** Configuration modification management

	virtual void    OnModifyConfig(CW_LPC_CHAR szConfiguration);

protected:

	virtual void    ModifyConfigCommand(CW_LPC_CHAR szConfiguration);

	//#MODIFJS 27/10/98 - Audit des temps de lecture

protected:

	CW_FLOAT m_fltMinReadTime;
	CW_FLOAT m_fltMaxReadTime;
	CW_FLOAT m_fltAverageReadTime;
	CW_FLOAT m_fltScheduleRead;

	CW_DWORD m_dwReadCpt;

public:

	void  statWrite( void);

	void statEndRead(
		CW_FLOAT fltMinReadTime,
		CW_FLOAT fltMaxReadTime,
		CW_FLOAT fltAverageReadTime,
		CW_FLOAT fltScheduleRead);

	//#ENDMODIFJS 27/10/98 - Audit des temps de lecture

public:

	_EqtManagement *m_tabEqtManagement;
	_CwMailBox     *m_CwMailBox;
	CW_BOOL        m_bNetCommandInProgress;
	CW_BOOL        m_bEqtCommandInProgress;

	void Run_MonoFlux( void);
	void Run_MultiFlux( void);

	CW_BOOL DynamicTest( _Command *pCmd);
};

#endif // _CWNET_H_