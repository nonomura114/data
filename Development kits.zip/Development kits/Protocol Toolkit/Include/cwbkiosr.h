/*--------------------------------------------------------------------------*/
/*																			*/
/*		PROJECT		:	LIBRAIRIE GENERIQUE D'ACCES A LA COUCHE PHYSIQUE	*/
/*																			*/
/*		MODULE		:	cwbkiosr.h											*/
/*																			*/
/*		VERSION		:	1.00												*/
/*																			*/
/*		SYSTEMES	:	Windows 95 , Windows NT								*/
/*																			*/
/*		AUTHOR		:	Eric PERROTIN										*/
/*																			*/
/*		PURPOSE		:	Fonctions de services d'acc�s au port s�rie			*/
/*																			*/
/*--------------------------------------------------------------------------*/


#ifndef _CWBKIOSR_H_

	#define _CWBKIOSR_H_

//******************************
//
//	SERVICES functions
//
//******************************
CW_C_IMPORT_EXPORT CW_USHORT  Emission_Trame(
		TYP_DESBLANC far *desblanc,
		OCTET *txBuffer, 
		MOT txLength,
		MOT txTimeOut);

CW_C_IMPORT_EXPORT CW_USHORT  Emission_Break(
		TYP_DESBLANC far *desblanc,
		MOT TimeOut);

CW_C_IMPORT_EXPORT CW_USHORT  Reception_Trame(
		TYP_DESBLANC far *desblanc,
		OCTET *rxBuffer, 
		MOT rxLength,
		MOT rxTimeOut);

CW_C_IMPORT_EXPORT CW_USHORT  Emis_Rcp_Trame(
		TYP_DESBLANC far *desblanc,
		OCTET *txBuffer, 
		MOT txLength,
		OCTET *rxBuffer,
		MOT rxLength, 
		MOT rxTimeOut);

CW_C_IMPORT_EXPORT CW_USHORT  Emis_Break_Rcp_Trame(
		TYP_DESBLANC far *desblanc,
		MOT txTimeOut,
		OCTET *rxBuffer, 
		MOT rxLength,
		MOT rxTimeOut);

#endif	// _CWBKIOSR_H_