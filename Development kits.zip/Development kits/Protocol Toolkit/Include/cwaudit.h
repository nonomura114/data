
#ifndef _CWAUDIT_H_

	#define _CWAUDIT_H_

class CW_IMPORT_EXPORT _CwAudit: public CObject
{
protected:
	_CriticalSection    m_CriticalSection;

	struct	cwstat		sta[GBL_MAX_CW_STAT] ;
	struct	cwstattime	statime[GBL_MAX_CW_STATTIME] ;

public:
	_CwAudit( void);
	~_CwAudit( void);

	//
	// Compteurs d'objects
	//
	void ct_classe(
		CW_USHORT ObjectClass, 
		CW_USHORT Family, 
		CW_ULONG Size);

	void dt_classe(
		CW_USHORT ObjectClass, 
		CW_USHORT Family, 
		CW_ULONG Size);

	//
	// Compteurs de temps
	//
	void begin_time( CW_USHORT ObjectClass);
	void end_time( CW_USHORT ObjectClass);
	CW_ULONG get_time( CW_USHORT ObjectClass);
};

extern _CwAudit *G_CwAudit;

#endif