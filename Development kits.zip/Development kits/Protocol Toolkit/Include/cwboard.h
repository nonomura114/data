#ifndef _CWBOARD_H_
#define _CWBOARD_H_

//************************************************
//**
//** _CwBaseBoard
//**
//************************************************

class CW_IMPORT_EXPORT _CwBaseBoard: public _CommunicationObject
{
	DECLARE_DYNAMIC( _CwBaseBoard)
	
	//***
	//*** Board - Configuration
	//***

protected:

	_LinkedList *m_llNetwork;
	CW_ULONG    m_ulNbCyclicFrame;
	CW_ULONG    m_ulNbWatchUnsolicitedFrame;

	//#MODIFDL 21/09/01
	// Contient les objets non charg�s car non produits
	CMap < CW_USHORT, CW_USHORT, CW_USHORT, CW_USHORT > m_mapIDObjNotProduct;
	CMap< CString, LPCTSTR, CW_USHORT, CW_USHORT > m_mapStrObjNotProduct;

public:

	CW_USHORT   GetNetFromName( char *pszName, _CwBaseNetwork **pNetOut);
    
    CW_USHORT   IsNetworksProduct( 
            CW_BOOL & a_bIsNetworksProduct);	// [out] = CW_TRUE if at least one network is producted	else CW_FALSE

	CW_ULONG    GetNbNetwork( void)   { return LL_COUNT( m_llNetwork); }
	CW_ULONG    GetNbEqt( void);
	CW_ULONG    GetNbFrame( void);
	CW_ULONG    GetNbCyclicFrame( void)            { return m_ulNbCyclicFrame; }
	CW_ULONG    GetNbWatchUnsolicitedFrame( void)  { return m_ulNbWatchUnsolicitedFrame; }

	//***
	//*** Board - Error Counters
	//***

protected:

	void        IncrementErrorCounter( void);
	void        IncrementTransferErrorCounter( void);
	void        IncrementAbortedCommandCounter( _ProtErrorLevel ErrorLevel);

	//***
	//*** Board - Constructor & destructor
	//***

public:

		_CwBaseBoard( void);
		virtual ~_CwBaseBoard( void);

	CW_USHORT   Initialize( CW_USHORT UserId, _Cimway *Base, _AD *adFile);
	void        Terminate( void);

protected:

	virtual CW_USHORT BeforeInitialize( _AD *adFile) { return CW_OK; }
	virtual CW_USHORT AfterInitialize( _AD *adFile)  { return CW_OK; }

	virtual void  SpecificTerminate( void)             {}

	//***
	//*** Board - Specific Construction
	//***

public:

	CW_USHORT   CreateNetwork( _AD *adFile);
	CW_USHORT   CreateEqt( _AD *adFile);
	CW_USHORT   CreateFrame( _AD *adFile);

	virtual _CwBaseNetwork *OnCreateNetwork(
		CW_USHORT usNetworkType);

	ULONG		RegistryNetwork( _CwBaseNetwork *Network);
	void		RegistryEqt( _CwBaseEqt *Eqt);
	void		RegistryFrame( _CwBaseFrame *Frame);
	void        RegistryCyclicFrame( _CwBaseFrame *Frame);
	void        RegistryWatchUnsolicitedFrame( _CwBaseFrame *Frame);
	void		RegistryLink( _CwBaseLink *Link);
	void		RegistryData( _CwBaseData *Data);

	void        UnregistryNetwork( _CwBaseNetwork *Network);
	void        UnregistryEqt( _CwBaseEqt *Eqt);
	void        UnregistryFrame( _CwBaseFrame *Frame);
	void        UnregistryCyclicFrame( _CwBaseFrame *Frame);
	void        UnregistryWatchUnsolicitedFrame( _CwBaseFrame *Frame);
	void        UnregistryLink( _CwBaseLink *Link);
	void        UnregistryData( _CwBaseData *Data);

protected:

	virtual void      OnRegistryNetwork( _CwBaseNetwork *Network)            {}
	virtual void      OnRegistryEqt( _CwBaseEqt *Eqt)                        {}
	virtual void      OnRegistryFrame( _CwBaseFrame *Frame)                  {}
	virtual void      OnRegistryCyclicFrame( _CwBaseFrame *Frame)            {}
	virtual void      OnRegistryWatchUnsolicitedFrame( _CwBaseFrame *Frame)  {}
	virtual void      OnRegistryLink( _CwBaseLink *Link)                     {}
	virtual void      OnRegistryData( _CwBaseData *Data)                     {}

	virtual void      OnUnregistryNetwork( _CwBaseNetwork *Network)          {}
	virtual void      OnUnregistryEqt( _CwBaseEqt *Eqt)                      {}
	virtual void      OnUnregistryFrame( _CwBaseFrame *Frame)                {}
	virtual void      OnUnregistryCyclicFrame( _CwBaseFrame *Frame)          {}
	virtual void      OnUnregistryWatchUFrame( _CwBaseFrame *Frame)          {}
	virtual void      OnUnregistryLink( _CwBaseLink *Link)                   {}
	virtual void      OnUnregistryData( _CwBaseData *Data)                   {}

	//***
	//*** Board - Management routines
	//***

public:

	CW_USHORT   GetInfo( CW_LP_BOARD_INFO lpInfo);
	CW_USHORT   GetStatus( CW_LP_BOARD_STATUS lpStatus);
 
protected:

	CW_USHORT   ReadyToBeActivate( void);
	void        SpecificStart( void);

	CW_USHORT   ReadyToBeInactivate( void);
	void        SpecificStop( CW_BOOL bInternalStop);

	void        SpecificStartCyclic( void);
	void        SpecificStopCyclic( void);

	void        SpecificStartWatchUnsolicited( void);
	void        SpecificStopWatchUnsolicited( void);

	virtual void      OnGetInfo( CW_LP_BOARD_INFO lpInfo)        {}
	virtual void      OnGetStatus( CW_LP_BOARD_STATUS lpStatus)  {}


	//***
	//*** Board - Find methods
	//***

public:

	CW_USHORT   FindNetwork_Number(
		CW_USHORT usNetwork_Number,
		_CwBaseNetwork **Network);

	CW_USHORT   FindNetwork_UserId(
		CW_USHORT usNetwork_UserId,
		_CwBaseNetwork **Network);

	CW_USHORT   FindNetwork_Rank(
		CW_USHORT usNetwork_Rank,
		_CwBaseNetwork **Network);

	CW_USHORT   FindEqt_Number(
		CW_USHORT usNetwork_Number,
		CW_USHORT usEqt_Number,
		_CwBaseEqt **Eqt);

	CW_USHORT   FindEqt_UserId(
		CW_USHORT usNetwork_UserId,
		CW_USHORT usEqt_UserId,
		_CwBaseEqt **Eqt);

	CW_USHORT   FindEqt_Rank(
		CW_USHORT usNetwork_Rank,
		CW_USHORT usEqt_Rank,
		_CwBaseEqt **Eqt);

	CW_USHORT   FindFrame_Number(
		CW_USHORT usNetwork_Number,
		CW_USHORT usEqt_Number,
		CW_USHORT usFrame_Number,
		_CwBaseFrame **Frame);

	CW_USHORT   FindFrame_UserId(
		CW_USHORT usNetwork_UserId,
		CW_USHORT usEqt_UserId,
		CW_USHORT usFrame_UserId,
		_CwBaseFrame **Frame);

	CW_USHORT   FindFrame_Rank(
		CW_USHORT usNetwork_Rank,
		CW_USHORT usEqt_Rank,
		CW_USHORT usFrame_Rank,
		_CwBaseFrame **Frame);

	CW_USHORT SendAllNetworksMessage(CW_LPC_CHAR szMessage);
};

#endif // _CWBOARD_H_