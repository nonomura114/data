
#ifndef _CWPRTCMD_H_

	#define _CWPRTCMD_H_


struct _ProtError;  // Definie dans cwerror.h


class CW_IMPORT_EXPORT _ProtStartNetworkCmd: public _BaseStartNetworkCmd
{
public:

	CW_USHORT   m_NetworkType;   // Type de r�seau

		_ProtStartNetworkCmd(					// Constructeur
			_CwBaseNetwork *	pCwNetwork,
			CW_USHORT			usMode);

		virtual ~_ProtStartNetworkCmd(    // Destructeur
			void);

	// Les comptes-rendus d'execution de la commande

	void Ack( void);             // Acquittement positif
	void Nack(                   // Acquittement negatif
		_ProtError *pErr);        // Pointeur sur l'erreur

	void NotifyCompleted( void){	m_Network->AfterStartCommand(); }; 
};


class CW_IMPORT_EXPORT _ProtStopNetworkCmd: public _BaseStopNetworkCmd
{
public:
	CW_USHORT   m_NetworkType;   // Type de reseau
    CW_BOOL     m_bInternalStop;

		_ProtStopNetworkCmd(					// Constructeur
			_CwBaseNetwork *	pCwNetwork,
			CW_USHORT			usMode,
            CW_BOOL             bInternalStop);

		virtual ~_ProtStopNetworkCmd(     // Destructeur
			void);

	// Les comptes-rendus d'execution de la commande

	void Ack( void);             // Acquittement positif
	void Nack(                   // Acquittement negatif
		_ProtError *pErr);        // Pointeur sur l'erreur

	void NotifyCompleted( void){	m_Network->AfterStopCommand(m_bInternalStop); };
};


class CW_IMPORT_EXPORT _ProtCyclicScanCmd: public _BaseCycScanCmd
{
public:
	CW_USHORT   m_NetworkType;   // Type de reseau

		_ProtCyclicScanCmd(       // Constructeur
			_CwBaseNetwork *pCwNetwork);

		virtual ~_ProtCyclicScanCmd(      // Destructeur
			void);

	// Les comptes-rendus d'execution de la commande

	void Ack( void);             // Acquittement Positif
	void Nack(                   // Acquittement Negatif
		_ProtError *pErr);        // Pointeur sur l'erreur
};


class CW_IMPORT_EXPORT _ProtBrowseNetworkCmd : public _BaseBrowseNetworkCmd
{
public:

	CW_USHORT   m_NetworkType;   // Type de r�seau

	_ProtBrowseNetworkCmd(					// Constructeur
		_CwBaseNetwork *	pCwNetwork);

	virtual ~_ProtBrowseNetworkCmd(    // Destructeur
		void);

	// Les comptes-rendus d'execution de la commande

	void Ack(LPCTSTR l_pBuffer);            // Acquittement positif
	void Nack(_ProtError *pError);

	void NotifyCompleted(void) {  };
};


class CW_IMPORT_EXPORT _ProtBrowseNetworkDeviceCmd : public _BaseBrowseNetworkDeviceCmd
{
public:

	CW_USHORT   m_NetworkType;   // Type de r�seau


	_ProtBrowseNetworkDeviceCmd(					// Constructeur
		_CwBaseNetwork *	pCwNetwork,
		LPCTSTR szDeviceId);

	virtual ~_ProtBrowseNetworkDeviceCmd(    // Destructeur
		void);

	// Les comptes-rendus d'execution de la commande

	void Ack(LPCTSTR l_pBuffer);            // Acquittement positif
	void Nack(_ProtError *pError);

	void NotifyCompleted(void) {  };
};


class CW_IMPORT_EXPORT _ProtStartEqtCmd: public _BaseStartEqtCmd
{
public:

	CW_USHORT m_EqtType;         // Type d'equipement
	CW_ULONG  m_EqtAddress;      // Adresse de l'equipement

		_ProtStartEqtCmd(         // Constructeur
			_CwBaseEqt *		pCwEqt,
			CW_USHORT			usMode);

		virtual ~_ProtStartEqtCmd(        // Destructeur
			void);


	// Les comptes-rendus d'execution de la commande

	void Ack( void);             // Acquittement positif
	void Nack(                   // Acquittement negatif
		_ProtError *pErr);        // Pointeur sur l'erreur

	void NotifyCompleted( void){	m_Eqt->AfterStartCommand(); }; 
};


class CW_IMPORT_EXPORT _ProtStopEqtCmd: public _BaseStopEqtCmd
{
public:

	CW_USHORT   m_EqtType;         // Type d'equipement
	CW_ULONG    m_EqtAddress;      // Adresse de l'equipement
    CW_BOOL     m_bInternalStop;

		_ProtStopEqtCmd(          // Constructeur
			_CwBaseEqt *		pCwEqt,
			CW_USHORT			usMode,
            CW_BOOL             bInternalStop);

		virtual ~_ProtStopEqtCmd(         // Destructeur
			void);


	// Les comptes-rendus d'execution de la commande

	void Ack( void);             // Acquittement positif
	void Nack(                   // Acquittement negatif
		_ProtError *pErr);        // Pointeur sur l'erreur

	void NotifyCompleted( void){	m_Eqt->AfterStopCommand(m_bInternalStop); };
};




class CW_IMPORT_EXPORT _ProtBrowseEqtCmd : public _BaseBrowseEqtCmd
{
public:
	_ProtBrowseEqtCmd(         // Constructeur
		_CwBaseEqt *		pCwEqt);

	virtual ~_ProtBrowseEqtCmd(        // Destructeur
		void);


	// Les comptes-rendus d'execution de la commande

	void Ack(LPCTSTR pDataBuf);             // Acquittement positif
	void Nack(                   // Acquittement negatif
		_ProtError *pErr);        // Pointeur sur l'erreur

	void NotifyCompleted(void) {  };
};



class CW_IMPORT_EXPORT _ProtStartFrameCmd: public _BaseStartFrameCmd
{
public:

	CW_ULONG  m_FrameAddress;    // Adresse de debut de trame
                                // (celle saisie lors de la configuration)
	CW_USHORT m_CwDataType;      // Type de donnees Cimway
                                // (BIT, OCTET, MOT, ...)
	CW_USHORT m_ProtDataType;    // Type de donnees dans l'equipement
	CW_ULONG  m_DataSize;        // Nombre de donnees dans la trame
                                // Ce nombre est exprime dans le type
                                // de donnees Cimway

		_ProtStartFrameCmd(       // Constructeur
			_CwBaseFrame *	pCwFrame,
			CW_USHORT			usMode);

		virtual ~_ProtStartFrameCmd(      // Destructeur
			void);


	// Les comptes-rendus d'execution de la commande

	void Ack( void);             // Acquittement positif
	void Nack(                   // Acquittement negatif
		_ProtError *pErr);        // Pointeur sur l'erreur

	void NotifyCompleted( void){	m_Frame->AfterStartCommand(); }; 
};


class CW_IMPORT_EXPORT _ProtStopFrameCmd: public _BaseStopFrameCmd
{
public:
	CW_ULONG  m_FrameAddress;    // Adresse de debut de trame
                                // (celle saisie lors de la configuration)
	CW_USHORT m_CwDataType;      // Type de donnees Cimway
                                // (BIT, OCTET, MOT, ...)
	CW_USHORT m_ProtDataType;    // Type de donnees dans l'equipement
	CW_ULONG  m_DataSize;        // Nombre de donnees dans la trame
                                // Ce nombre est exprime dans le type
                                // de donnees Cimway
    CW_BOOL     m_bInternalStop;

		_ProtStopFrameCmd(        // Constructeur
			_CwBaseFrame *		pCwFrame,
			CW_USHORT			usMode,
            CW_BOOL             bInternalStop);

		virtual ~_ProtStopFrameCmd(       // Destructeur
			void);


	// Les comptes-rendus d'execution de la commande

	void Ack( void);             // Acquittement positif
	void Nack(                   // Acquittement negatif
		_ProtError *pErr);        // Pointeur sur l'erreur

	void NotifyCompleted( void){	m_Frame->AfterStopCommand(m_bInternalStop); };
};


class CW_IMPORT_EXPORT _ProtReadCmd: public _BaseReadCmd
{
public:

	CW_ULONG  m_FrameAddress;    // Adresse de debut de trame
                                // (celle saisie lors de la configuration)
	CW_ULONG  m_Index;           // Index de debut de lecture par
                                // rapport a l'adresse de la trame
                                // Commence a partir de 0
                                // Il est exprime dans le type de
                                // donnee Cimway
	CW_USHORT m_CwDataType;      // Type de donnees Cimway
                                // (BIT, OCTET, MOT, ...)
	CW_USHORT m_ProtDataType;    // Type de donnees dans l'equipement
	CW_ULONG  m_DataSize;        // Nombre de donnees dans la trame
                                // Ce nombre est exprime dans le type
                                // de donnees Cimway

	CW_BOOL   m_CyclicCmd;       // = CW_TRUE si commande cyclique,
                                // = CW_FALSE sinon
	CW_BOOL   m_SynchroneCmd;    // = CW_TRUE si commande synchrone,
                                // = CW_FALSE sinon

	CW_ULONG m_ulRequestId;//#MODIFFRM 22/08/03

		_ProtReadCmd(             // Constructeur
			_CwBaseFrame *pCwFrame,
			CW_BOOL      bSynchrone,
			CW_BOOL      bCyclic,
			CW_USHORT    usActionCode,
			CW_ULONG	ulRequestId = 0);//#MODIFFRM 22/08/03

		_ProtReadCmd(             // Constructeur
			_CwBaseFrame *pCwFrame,
			CW_BOOL      bSynchrone,
			CW_BOOL      bCyclic,
			CW_USHORT    usActionCode,
			CW_ULONG     ulIndex,
			CW_ULONG     ulSize,
			CW_ULONG	ulRequestId = 0);//#MODIFFRM 22/08/03

		virtual ~_ProtReadCmd(            // Destructeur
			void);


	// Les comptes-rendus d'execution de la commande

	void Ack(                    // Acquittement positif
		CW_LP_VOID pDataBuf);     // Pointeurs sur les donnees lues

	void Ack(                    // Acquittement positif
		CW_ULONG   Index,         // Index sur le debut du buffer
                                // Commence � partir de 0
                                // Il est exprime dans le type de
                                // donnees Cimway
		CW_ULONG   DataSize,      // Taille du buffer
                                // Il est exprime dans le type de
                                // donnees Cimway
		CW_LP_VOID pDataBuf);     // Pointeur sur les donnees lues

	void AckLocal(              // Acquittement positif local
		void);                  // Pas de mise � jour des donn�es

	void	Nack(                  // Acquittement negatif
		_ProtError *pErr);        // Pointeur sur l'erreur

	void	NackLocal(            // Acquittement negatif (pas de mise � jour des donn�es en invalide)
		_ProtError *pErr);        // Pointeur sur l'erreur

	void NotifyCompleted( void); //#MODIFFRM 22/08/03
};


class CW_IMPORT_EXPORT _ProtWriteCmd: public _BaseWriteCmd
{
public:
	CW_ULONG   m_FrameAddress;   // Adresse de debut de trame
                                // (celle saisie lors de la configuration)
	CW_ULONG   m_Index;          // Index de debut d'ecriture par
                                // rapport a l'adresse de la trame
                                // Commence a partir de 0
                                // Il est exprime dans le type de
                                // donnee Cimway
	CW_USHORT  m_CwDataType;     // Type de donnees Cimway
                                // (BIT, OCTET, MOT, ...)
	CW_USHORT  m_ProtDataType;   // Type de donnees dans l'equipement
	CW_ULONG   m_DataSize;       // Nombre de donnees dans la trame
                                // Ce nombre est exprime dans le type
                                // de donnees Cimway
	CW_LP_VOID m_pWriteData;     // Pointeur sur les donnees a ecrire

	CW_BOOL    m_CyclicCmd;      // = CW_TRUE si commande cyclique,
                                // = CW_FALSE sinon
	CW_BOOL    m_SynchroneCmd;   // = CW_TRUE si commande synchrone,
                                // = CW_FALSE sinon

		_ProtWriteCmd(            // Constructeur
			_CwBaseFrame *pCwFrame,
			CW_BOOL      bSynchrone,
			CW_BOOL      bCyclic,
			CW_USHORT    usActionCode);

		_ProtWriteCmd(            // Constructeur
			_CwBaseFrame *pCwFrame,
			CW_BOOL      bSynchrone,
			CW_BOOL      bCyclic,
			CW_USHORT    usActionCode,
			CW_ULONG     ulIndex,
			CW_ULONG     ulSize);

		//#MODIFFRM 28/04/03
		_ProtWriteCmd(				// Constructeur
			_CwBaseFrame *pCwFrame,
			CW_BOOL bSynchrone,
			CW_BOOL bCyclic,
			CW_USHORT usActionCode,
			CW_ULONG ulIndex,
			CW_ULONG ulSize,
			CW_HANDLE hClient,
			CW_TRANSACTID TransactID);
		//#ENDMODIFFRM 28/04/03

		virtual ~_ProtWriteCmd(           // Destructeur
			void);


	// Les comptes-rendus d'execution de la commande

	void Ack( void);             // Acquittement positif
	void AckLocal( void);        // Acquittement positif local
	void Nack(                   // Acquittement negatif
		_ProtError *pErr);        // Pointeur sur l'erreur
	void NackLocal(            // Acquittement negatif (pas de mise � jour des donn�es en invalide)
		_ProtError *pErr);        // Pointeur sur l'erreur

	//#MODIFFRM 28/04/03
	void NotifyCompleted( void);

	CW_TRANSACTID m_TranscactId;
	CW_HANDLE m_hClient;
	_CwBaseLink *GetLink( void)  { return m_Link; }
	//#ENDMODIFFRM 28/04/03
};

#endif /* _CWPRTCMD_H_ */

