/*
** cwmailb.h
*/

#ifndef _CWMAILB_H_

	#define _CWMAILB_H_

	#define CW_MSG_VERSION_V1		1

	#define	CW_MSG_TYPE_BROADCAST	0 	// Requ�te sans acquitement
	#define	CW_MSG_TYPE_REQUEST 	1	// Requ�te (implique un acquitement)
	#define CW_MSG_TYPE_ACK 		2	// R�ponse positive � requ�te
	#define	CW_MSG_TYPE_NACK 		3 	// R�ponse n�gative � requ�te
	#define	CW_MSG_TYPE_INPROCESS	4	// Requ�te en cour de traitement

	#define	CW_MSG_CLASSIC 			0	// Envoi d'un message sans priorit�
	#define	CW_MSG_PRIORITY			1	// Envoi d'un message prioritaire (ex : CMDE WRITE)
	#define	CW_MSG_SYSTEM_PRIORITY	2	// Envoi d'un message syst�me prioritaire (ex : MACRO CMDE)
	

	// D�finition d'un message
	class	_CwMessage : public _Elt
	{
	public:
		CW_UCHAR	m_Version;
		CW_USHORT  	m_Length;		// taille du message
		CW_USHORT  	m_Function;		// fonction de la requ�te
		CW_USHORT 	m_Priority;		// Priorit�
		CW_USHORT 	m_Mode;			// Mode

		_CwMessage(					// constructeur
			CW_USHORT	Length,		// longueur du message
			CW_USHORT	Function,	// fonction
			CW_USHORT 	Mode,		// Mode
			CW_USHORT	Priority = CW_MSG_CLASSIC);
		virtual ~_CwMessage( void);

		CW_BOOL	IsSynchro( void);
	};
	

	// D�finition d'une requ�te
	class	_CwRequest : public _CwMessage
	{
	public:
		CW_ULONG	m_id1;			// premier identificateur
		CW_ULONG	m_id2;			// second identificateur

		_CwRequest(					// constructeur :
			CW_ULONG	id1,		// premier identificateur
			CW_ULONG	id2,		// deuxi�me identificateur
			CW_USHORT	Length,		// longueur du message
			CW_USHORT	Function,	// fonction
			CW_USHORT 	Mode,		// Mode
			CW_USHORT	Priority = CW_MSG_CLASSIC);
		virtual ~_CwRequest( void);
	};

	
	class CW_IMPORT_EXPORT _MailBox: public _LinkedList
	{
	public:
			_MailBox(CW_ULONG lNbMax=2000);
			virtual ~_MailBox( void);

		virtual void WriteToMailBox( 
			CW_LP_VOID lpvMessage);
		virtual CW_LP_VOID ReadFromMailBox( void);

		CW_BOOL	 IsMailBoxEmpty( void);
		CW_ULONG NbMailInBox( void);
	};

#endif

