//*********************
//**
//**  cwtype.h
//**
//*********************
     
#ifndef _CWTYPE_H_

	#define _CWTYPE_H_

#include <afxtempl.h>      // MFC template collections #MODIFDL 21/09/01

class _EltSingleList;
class _LinkSingleList;
class _TimDat;

class _Cimway;		// Definition dans cw.h

class _CwBaseNetwork;
class _CwBaseEqt;
class _CwBaseFrame;
class _CwBaseData;
class _CwBaseLink;

class  _CwBaseItem;
class  _CwCanonicalItem;
struct _CwItemDataAttributs;

class _CwNGNetwork;
class _CwNGEqt;
class _CwNGFrame;

class _CwNetwork;
class _CwEqt;
class _CwFrame;

class _ProtNetwork;
class _ProtEqt;
class _ProtFrame;

//class _BlankBoard;	// Definition dans cwblnk.h

class _Command;		// Definition dans "cwcmd.h"

class _ProtStartNetworkCmd;
class _ProtStopNetworkCmd;
class _ProtCyclicScanCmd;
class _ProtBrowseNetworkCmd;
class _ProtBrowseNetworkDeviceCmd;
class _ProtStartEqtCmd;
class _ProtStopEqtCmd;
class _ProtBrowseEqtCmd;
class _ProtStartFrameCmd;
class _ProtStopFrameCmd;
class _ProtReadCmd;
class _ProtWriteCmd;

struct _ProtPartialDataTable;
struct _ProtError;
struct _CwEltData;
struct _CwVersion;

typedef struct __EqtManagement
{
	CW_BOOL  bTurnAroundRunning;  // Le d�lai de etournement de cet �quipement est-il �coul� ?
	MSECS    msTurnAroundBegin;   // Heure du d�but du retournement
	CW_BOOL  bCommandInProgress;  // Commande en cours pour cet �quipement

	__EqtManagement( void)
	{ bTurnAroundRunning = CW_FALSE; bCommandInProgress = CW_FALSE; }

} _EqtManagement;

class _CwMailBox: public CObject
{
protected:

	HANDLE       m_hMutex;

	_LinkedList  m_llCmdList;

	_Elt         *m_eltCurrentCmd;
	_Elt         *m_eltRespCmd;
	_Elt         *m_eltUpholdCmd;
	_Elt         *m_eltUltraCmd;
	_Elt         *m_eltPriorCmd;
	_Elt         *m_eltCyclicCmd;
	_Elt         *m_eltOneShotCmd;

public:

	_CwMailBox( CString &csMailBoxName);
	~_CwMailBox( void);

	CW_USHORT  SendMessage( _Command *pCmd);
	CW_USHORT  GetMessage( _Command **ppCmd);

    CW_BOOL     IsEmpty();

protected:
	
	CW_USHORT  SendResponseMessage( _Command *pCmd);
	CW_USHORT  SendUpholdMessage( _Command *pCmd);
	CW_USHORT  SendUltraMessage( _Command *pCmd);
	CW_USHORT  SendPriorMessage( _Command *pCmd);
	CW_USHORT  SendOneShotMessage( _Command *pCmd);
	CW_USHORT  SendCyclicMessage( _Command *pCmd);

	CW_USHORT  RemoveResponseCommand( _Elt *eltToRemove);
	CW_USHORT  RemoveUpholdCommand( _Elt *eltToRemove);
	CW_USHORT  RemoveUltraCommand( _Elt *eltToRemove);
	CW_USHORT  RemovePriorCommand( _Elt *eltToRemove);
	CW_USHORT  RemoveOneShotCommand( _Elt *eltToRemove);
	CW_USHORT  RemoveCyclicCommand( _Elt *eltToRemove);
};

// Compte-rendu immediat sur les commandes Cimway
enum _ProtRet
{
	PR_CMD_PROCESSED		= 0,	// Commande d�clenchant un traitement
									// impliquant un ack ou nack
	PR_CMD_NOT_PROCESSED	= 1,	// Commande ne d�clenchant un traitement (CMD_NON_GEREE)
									// pas de ack ou nack
	PR_CMD_NEVER_PROCESSED	= 2,	// Commande jamais trait� par le protocole.
									// Au 1er appel, CW m�morise qu'il ne doit jamais plus appeler cette
									// commande.
	PR_CMD_ABORT			= 3		// Commande avort�e par CW
};

// ----------------- Define de gestion de flux ----------------

#define CW_FLUX_MONO			0
#define CW_FLUX_MULTI			1

#define BK_INTERFACE			10
#define NG_INTERFACE			20

#define LAYERONE_NONE			0
#define LAYERONE_SERIAL_PORT	1
#define LAYERONE_TCPIP			2

#define THIS_DO_NOTHING			0
#define THIS_WORKING			1
#define THIS_ASYNC_SERVICE		2
#define THIS_EXTRACTING			3
#define THIS_SYNC_FINISH		4

#define NO_ACCESS             0x00
#define READ_ACCESS           0x01
#define WRITE_ACCESS          0x02
#define READ_WRITE_ACCESS     0x03

#define CYCLIC_NONE           0x00
#define CYCLIC_READ           0x01
#define CYCLIC_WRITE          0x02

#define WRITE_ONESHOT_DISABLE 0x00
#define WRITE_ONESHOT_SYNC    0x01
#define WRITE_ONESHOT_ASYNC   0x02

#define READ_ONESHOT_DISABLE  0x00
#define READ_ONESHOT_SYNC     0x01
#define READ_ONESHOT_ASYNC    0x02

#define SIZE_MAX_THREAD_NAME  128

#define SIZE_MAX_SYNCHROEVENT_NAME	80
#define SYNCHROEVENT_NAME	"SynchroEvent_%s"

#define CW_STATUS_READY			0L

typedef _ProtNetwork *(*TYPE_CreateProtNetwork)( CW_USHORT usType);
typedef _ProtEqt *(*TYPE_CreateProtEqt)( CW_USHORT usType);
typedef _ProtFrame *(*TYPE_CreateProtFrame)( CW_USHORT usProtocolDataType, CW_USHORT usCwDataType);



#include "cwboard.h"
#include "cwnet.h"
#include "cweqt.h"
#include "cwfrm.h"
#include "cwlink.h"
#include "cwdata.h"
#include "cwngcomobj.h"



#endif /* _CWTYPE_H_ */
