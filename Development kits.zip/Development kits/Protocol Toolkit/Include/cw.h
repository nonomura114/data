/***************************************************************************/
/*                                                                         */
/*  Fichier: cw.h            class _Cimway                                 */
/*                                                                         */
/***************************************************************************/
     
#ifndef _CW_H_

	#define _CW_H_

extern _Cimway *peCimway;

// #MODIF EG 06/11/97
extern CW_BOOL				G_bSimu;
extern LPFN_TRACE			G_lpfnSvTrace;
extern LPFN_RECORDERR		G_lpfnRecordErr;
extern LPFN_OKTOTRACE		G_lpfnOkToTrace;
extern LPFN_ISINPRODUCTLIST	G_lpfnIsInProductList;		//#MODIFDL 21/09/01
extern LPFN_CREATETHREAD	G_lpfnCreateThread;			//#MODIFDL 24/02/10
extern LPFN_GETGBLINT       G_lpfnGetGblInt;

//#MODIFDL 02/03/06
// Si == TRUE cwAudit est aliment�
extern CW_USHORT			g_bTraceEnable;

#define CW_CC	peCimway->m_CwAudit->ct_classe
#define CW_DC	peCimway->m_CwAudit->dt_classe
#define CW_BT	peCimway->m_CwAudit->begin_time
#define CW_ET	peCimway->m_CwAudit->end_time

class _AD;
class _LinkedList;
class _Cimway;
class _CwBaseBoard;
class _CwBaseNetwork;
class _CwBaseEqt;
class _CwBaseFrame;
class _CwBaseLink;
class _CwBaseData;
class _Command;
	

#define MARK_UNKNOW   0
#define MARK_VERSION  1
#define MARK_BOARD    2
#define MARK_NETWORK  3
#define MARK_EQT      4
#define MARK_FRAME    5


typedef struct
{
	CW_BIT Active		: 1;
	CW_BIT Configured	: 1;
	CW_BIT Reserved		: 14;

} CW_CIMWAY_ENHANCED_STATE;


class CW_IMPORT_EXPORT _Cimway: public CObject
{
	DECLARE_DYNAMIC( _Cimway)

private:
	CW_CIMWAY_ENHANCED_STATE m_Status;

	CW_USHORT	m_ErrorCount;
	CW_USHORT	m_TransferErrorCount;
	CW_USHORT	m_NbAbortedCommand;

	CW_USHORT	m_ReadCounter;
	CW_USHORT	m_WriteCounter;
	CW_TRANSACTID m_TansactionIDCounter;	//#MODIFFRM 28/04/03

	CW_BOOL		m_NotifyDataChangeEnable;

	_LinkedList	*m_llBoard;
	_LinkedList	*m_llNetwork;
	_LinkedList	*m_llEqt;
	_LinkedList	*m_llFrame;

	CW_USHORT GetBoardFromName( 	// Get CwBaseBoard from his name
			char *pszName, 			// [in]  Name of Board
			_CwBaseBoard **pBoardOut);	// [out] 

	static bool	m_bStopStartPending;
	static bool	m_bStartPending;
	static bool	m_bStopPending;

public:

inline static void	SetStopStartPending( void)		{ m_bStopStartPending = true; }
inline static void	ResetStopStartPending( void)	{ m_bStopStartPending = false; }
inline static bool	IsStopStartPending(	void)		{ return m_bStopStartPending; }

inline static void	SetStartPending( void)		{ m_bStartPending = true; }
inline static void	ResetStartPending( void)	{ m_bStartPending = false; }
inline static bool	IsStartPending(	void)		{ return m_bStartPending; }

inline static void	SetStopPending(	void)		{ m_bStopPending = true; }
inline static void	ResetStopPending( void)		{ m_bStopPending = false; }
inline static bool	IsStopPending( void)		{ return m_bStopPending; }

	_LinkedList	*m_llLink;
	_LinkedList	*m_llData;

	// Les CallBacks
	LPFN_CWACKWATCHITEM					m_pfnNotifyDataChange;	// CallBack to notify item modification 
	LPFN_CWACKWATCHFRAMESTATE			m_pfnAckFrameState;	// CallBack to notify state frame modification 
	LPFN_CWACKWATCHEQTSTATE				m_pfnAckEqtState;	// CallBack to notify state eqt modification 
	LPFN_CWACKWATCHNETSTATE				m_pfnAckNetState;	// CallBack to notify state network modification 
	LPFN_CWACKWRITEASYNC				m_pfnAckWriteAsync;	// CallBack to notify completed async write
	LPFN_CWACKREADASYNC					m_pfnAckReadAsync;	// CallBack to notify completed async read //#MODIFFRM 22/08/03
	LPFN_CWACKBROWSENETWORKASYNC		m_pfnAckBrowseNetworkAsync;
	LPFN_CWACKBROWSENETWORKDEVICEASYNC	m_pfnAckBrowseNetworkDeviceAsync;
	LPFN_CWACKBROWSEDEVICEASYNC			m_pfnAckBrowseDeviceAsync;

	CW_USHORT GetFrameServerHandle( // Get Server Handle of the frame
		CW_ID        idFrame,		// [in] ID of the Frame
		CW_LP_HANDLE phServerFrame);	// [out] Server Handle of the frame
	CW_USHORT GetEqtServerHandle( // Get Server Handle of the Equipment
		CW_ID        idEqt,		// [in] name ID of the Equipment
		CW_LP_HANDLE phServerEqt);	// [out] Server Handle of the Equipment
	CW_USHORT GetNetServerHandle( // Get Server Handle of the Network
		CW_ID        idNet,		// [in] name ID of the Network
		CW_LP_HANDLE phServerNet);	// [out] Server Handle of the Network

    CW_USHORT IsNetworksProduct( 
            CW_BOOL & a_bIsNetworksProduct);	// [out] = CW_TRUE if at least one network is producted	else CW_FALSE

	CW_USHORT GetLinkFromNameID( // Get Link object
		CW_ID		idFrame,	// [in] name ID of the Frame
		_CwBaseLink	**pLink);	// [out] ptr of the Link
	CW_USHORT GetEqtFromNameID( // Get Equipment object
		CW_ID		idEqt,		// [in] name ID of the Eqt
		_CwBaseEqt	**pEqt);	// [out] ptr of the equipment
	CW_USHORT GetNetFromNameID( // Get Network object
		CW_ID		idNet,		// [in] name ID of the Network
		_CwBaseNetwork	**pNet);	// [out] ptr of the Network

	CW_USHORT SetFrameClientHandle( // Set Client Handle of the frame
		CW_HANDLE	hServerFrame,	// [in] Server Handle of the Frame
		CW_HANDLE	hClientFrame);	// [in] Client Handle of the Frame

	CW_USHORT GetItemsAttributs( // Get attributs of all Items of a Frame
		CW_HANDLE        hFrameServer,      // [in] Server Frame handle
 		CW_ULONG         *pulNumberItems,   // [out] Number of Items in Frame
		_CwItemAttributs **ppItemAttributs); // [out] Array of Items Attributs.

	CW_USHORT SetItemsAttributs( // Set attributs of Items of a Frame
		CW_HANDLE        hFrameServer,    // [in] Server Frame handle
	 	CW_ULONG         ulNumberItems,   // [in] Number of Items in Frame
		_CwItemAttributs *pItemAttributs, // [in] Array of Items Attributs.
		CW_RESULT        *pErrors);       // [out] Array of Result.

	CW_USHORT CreateItems(                   // Create User Item of a Frame
		CW_HANDLE        hFrameServer,           // [in] Server Frame handle
		CW_ULONG         ulNumberItems,          // [in] The number of Item to create
		_CwItemCreation  *pItemCreation,         // [in] Array of Item creation attributes
		_CwItemAttributs **ppItemAttributs,      // [out] Array of Items Attributs.
		CW_RESULT        *pErrors);              // [out] Array of Result.

	CW_USHORT SetActiveItemsState( // Set Items active or inactive
		CW_HANDLE       hFrameServer,   // [in] Server Frame handle
		CW_ULONG	ulNumberItems,	// [in] Number of Item to be affected
		CW_HANDLE	*phServer,	// [in] Array of Server items handles.
						// These were returned from AddItem.
		CW_BOOL		bActive,	// [in] CW_TRUE if items are to be 
						// activated, CW_FALSE if items are
						// to be desactivated.
		CW_RESULT	*pErrors);	// [out] Array of Result. Indicates 
						// which Items were sucessfully affected

	CW_USHORT Advise(		// Create a connection between Cimway and Client
		LPFN_CWACKWATCHITEM					lpfnAckItem,		// [in] CallBack to notify item modification 
		LPFN_CWACKWATCHFRAMESTATE 			lpfnAckFrameState,	// [in] CallBack to notify state frame modification 
		LPFN_CWACKWATCHEQTSTATE 			lpfnAckEqtState,	// [in] CallBack to notify state eqt modification 
		LPFN_CWACKWATCHNETSTATE 			lpfnAckNetState,	// [in] CallBack to notify state network modification 
		LPFN_CWACKWRITEASYNC				lpfnAckWriteAsync,	// [in] CallBack to notify completed async write
		LPFN_CWACKREADASYNC					lpfnAckReadAsync, 	// [in] CallBack to notify completed async read //#MODIFFRM 22/08/03
		LPFN_CWACKBROWSENETWORKASYNC		lpfnAckBrowseNetworkAsync,
		LPFN_CWACKBROWSENETWORKDEVICEASYNC	lpfnAckBrowseNetworkDeviceAsync,
		LPFN_CWACKBROWSEDEVICEASYNC			lpfnAckBrowseDeviceAsync);

	CW_USHORT UnAdvise();		// Terminate a connection between Cimway and Client

	void 	OnSetXon();		// Notify Data change to Client is enable
	void	OnSetXoff();		// Notify Data change to Client is disable

	CW_BOOL 	GetDataChangeEnable( void);
	CW_USHORT 	GetFrameDataType( CW_HANDLE hServerHandle);
	   
protected:
	void SetDataChangeEnable( CW_BOOL bEnable = CW_TRUE);

	//***
	//*** Set/Reset States
	//***

	void	SetActive( void);
	void	ResetActive( void);
	void	SetConfigured( void);
	void	ResetConfigured( void);

public:

	CW_BOOL	IsActive( void);
	CW_BOOL IsConfigured( void);

protected:

	void	InitializeState( void);


	//***
	//*** Modify/Reset Error Counters
	//***

public:

	void	ResetErrorCounter( void);
	void	ResetTransferErrorCounter( void);
	void	ResetAbortedCommandCounter( void);

	void	IncrementErrorCounter( void);
	void	IncrementTransferErrorCounter( void);
	void	IncrementAbortedCommandCounter( _ProtErrorLevel ErrLevel);

	CW_USHORT	GetErrorCounter( void);
	CW_USHORT	GetTransferErrorCounter( void);
	CW_USHORT	GetAbortedCommandCounter( void);

	void	InitializeErrorCounters( void);

	//***
	//*** Modify/Reset Action Counters
	//***

public:

	void	IncrementReadCounter( void);
	void	ResetReadCounter( void);

	void	IncrementWriteCounter( void);
	void	ResetWriteCounter( void);

	CW_USHORT	GetReadCounter( void);
	CW_USHORT	GetWriteCounter( void);

protected:

	void	InitializeActionCounters( void);

	//***
	//*** Global Initialization
	//***

	void	Initialize( void);
	void	Reset( void);

	void	Terminate( void);

	//***
	//*** Constructor & Destructor
	//***

public:

	_Cimway( void);

	virtual ~_Cimway( void);


	//***
	//*** Specific Construction
	//***

protected:

	CW_USHORT	CreateBoard( _AD *adFile);
	CW_USHORT	CreateNetwork( _AD *adFile);
	CW_USHORT	CreateEqt( _AD *adFile);
	CW_USHORT	CreateFrame( _AD *adFile);

public:

	CW_ULONG	RegistryBoard( _CwBaseBoard *Board);
	void		RegistryNetwork( _CwBaseNetwork *Network);
	void		RegistryEqt( _CwBaseEqt *Eqt);
	void		RegistryFrame( _CwBaseFrame *Frame);
	void		RegistryCyclicFrame( _CwBaseFrame *Frame);
	void		RegistryWatchUnsolicitedFrame( _CwBaseFrame *Frame);
	void		RegistryLink( _CwBaseLink *Link);
	void		RegistryData( _CwBaseData *Data);

	void		UnregistryBoard( _CwBaseBoard *Board);
	void		UnregistryNetwork( _CwBaseNetwork *Network);
	void		UnregistryEqt( _CwBaseEqt *Eqt);
	void		UnregistryFrame( _CwBaseFrame *Frame);
	void		UnregistryCyclicFrame( _CwBaseFrame *Frame);
	void        UnregistryWatchUnsolicitedFrame( _CwBaseFrame *Frame);
	void		UnregistryLink( _CwBaseLink *Link);
	void		UnregistryData( _CwBaseData *Data);

	//***
	//*** Management routines
	//***

protected:

	CW_USHORT	DetermineMark( _AD *adFile);

public:

	CW_USHORT	ReadConfiguration( CW_LP_CHAR lpszFile);
	CW_USHORT	ResetConfiguration( void);

	CW_USHORT	Start( void);
	CW_USHORT	Stop( void);

	CW_USHORT	StartBoard(
				CW_USHORT usBoard);

	CW_USHORT	StopBoard(
				CW_USHORT usBoard);

	CW_USHORT	StartNetwork(
				CW_USHORT usBoard,
				CW_USHORT usNetwork);

	CW_USHORT	StartNetwork(
				CW_HANDLE hNetwork);

	CW_USHORT	StopNetwork(
				CW_USHORT usBoard,
				CW_USHORT usNetwork);

	CW_USHORT	StopNetwork(
				CW_HANDLE hNetwork);

	CW_USHORT	StartEqt(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt);

	CW_USHORT	StartEqt(
				CW_HANDLE hEqt);

	CW_USHORT	StopEqt(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt);

	CW_USHORT	StopEqt(
				CW_HANDLE hEqt);

	CW_USHORT	StartFrame(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt,
				CW_USHORT usFrame);

	CW_USHORT	StopFrame(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt,
				CW_USHORT usFrame);

	CW_USHORT	GlobalReadCommand(
				CW_USHORT usLinkId,
				CW_USHORT SyncMode,
				CW_USHORT ActionCode,
				CW_BOOL   bReleaseInterfaceLock,
				CW_ULONG ulRequestId);//#MODIFFRM 22/08/03

	CW_USHORT	GlobalReadCommand(
				CW_HANDLE hLink,
				CW_USHORT SyncMode,
				CW_USHORT ActionCode,
				CW_BOOL   bReleaseInterfaceLock,
				CW_ULONG ulRequestId,
				BOOL bUseCache);//#MODIFFRM 22/08/03

	CW_USHORT	PartialReadCommand(
				CW_USHORT usLinkId,
				CW_USHORT SyncMode,
				CW_USHORT ActionCode,
				CW_USHORT StartPosition,
				CW_USHORT Length,
				CW_BOOL   bReleaseInterfaceLock);

	CW_USHORT	PartialReadCommand(
				CW_HANDLE hLink,
				CW_USHORT SyncMode,
				CW_USHORT ActionCode,
				CW_USHORT StartPosition,
				CW_USHORT Length,
				CW_BOOL   bReleaseInterfaceLock);

	CW_USHORT	GlobalWriteCommand(
				CW_USHORT usLinkId,
				CW_USHORT SyncMode,
				CW_USHORT ActionCode,
				CW_BOOL   bReleaseInterfaceLock);

	CW_USHORT	GlobalWriteCommand(
				CW_HANDLE hLink,
				CW_USHORT SyncMode,
				CW_USHORT ActionCode,
				CW_BOOL   bReleaseInterfaceLock);

	CW_USHORT	PartialWriteCommand(
				CW_USHORT usLinkId,
				CW_USHORT SyncMode,
				CW_USHORT ActionCode,
				CW_USHORT StartPosition,
				CW_USHORT Length,
				CW_BOOL   bReleaseInterfaceLock);

	CW_USHORT	PartialWriteCommand(
				CW_HANDLE hLink,
				CW_USHORT SyncMode,
				CW_USHORT ActionCode,
				CW_USHORT StartPosition,
				CW_USHORT Length,
				CW_BOOL   bReleaseInterfaceLock);

//#MODIFFRM 28/04/03
	CW_USHORT	PartialWriteExCommand(
				CW_HANDLE hLink,
				CW_USHORT SyncMode,
				CW_USHORT ActionCode,
				CW_ULONG StartPosition,
				CW_ULONG Length,
				CW_BOOL   bReleaseInterfaceLock,
				CW_HANDLE hClient,
				CW_TRANSACTID *TransactID);
//#ENDMODIFFRM 28/04/03

	CW_USHORT	ModifyNetworkAttribut(
				CW_USHORT	usBoard_UserID,		// N� de carte
				CW_USHORT 	usNetwork_UserId,	// N� de network
				CW_LP_CHAR	pbuf);				// ptr sur les modifs

	CW_USHORT	ModifyEquipmentAttribut(
				CW_USHORT	usBoard_UserID,		// N� de carte
				CW_USHORT 	usNetwork_UserId,	// N� de network
				CW_USHORT	usEquipment_UserID,	// N� de l'equipement
				CW_LP_CHAR	pszBuf);			// des modifs
	
	CW_USHORT	ModifyActionAttribut(
				CW_USHORT	usLink_UserId, 		// N� utilisateur identifiant la trame
				CW_LP_CHAR	pszBuf);			// ascuid des modifs

	CW_USHORT	ModifyNetworkAttribut(
				CW_HANDLE	hNetwork,			// Handle de network
				CW_LP_CHAR	pbuf);				// ptr sur les modifs

	CW_USHORT	ModifyEquipmentAttribut(
				CW_HANDLE	hEqt,				// Handle de l'equipement
				CW_LP_CHAR	pszBuf);			// des modifs
	
	//#MODIFFRM 06/12/00
	CW_USHORT	ModifyEquipmentAttributEx(
				CW_HANDLE	hEqt,				// Handle de l'equipement
				CW_USHORT pAddress,
				CW_LP_CHAR	pszBuf,				// des modifs
				CW_USHORT pParametersCounter);
	//#ENDMODIFFRM 06/12/00

	//#MODIFFRM 30/09/02
	CW_USHORT	ModifyEquipmentPhoneNumber(
				CW_HANDLE	hEqt,				// Handle de l'equipement
				CString strPhoneNumber);

	CW_USHORT	ModifyEquipmentMaxConnectionDuration(
				CW_HANDLE	hEqt,				// Handle de l'equipement
				CW_USHORT usMaxConnectionDuration);
	//#ENDMODIFFRM 30/09/02

	CW_USHORT	ModifyActionAttribut(
				CW_HANDLE	hLink, 				// Handle de la trame
				CW_LP_CHAR	pszBuf);			// ascuid des modifs

	CW_USHORT   ModifyLinkUserAttributes(
				CW_HANDLE	hLink, 				// Handle de la trame
				CW_LPC_CHAR	pszBuf);			// ascuid des modifs

	CW_USHORT   ModifyLinkUserAttribute(
				CW_HANDLE	hLink, 				// Handle de la trame
				CW_USHORT   usIndex,
				CW_LPC_CHAR	pszBuf);			// ascuid des modifs

	CW_USHORT   GetLinkUserAttributes(
				CW_HANDLE  hLink,
				CW_LP_CHAR szParam,
				int        iParamMaxSize);

	CW_USHORT   GetLinkUserAttribute(
				CW_HANDLE  hLink,
				CW_USHORT  usIndex,
				CW_LP_CHAR szParam,
				int        iParamMaxSize);

	CW_USHORT   ModifyEquipmentUserAttributes(
				CW_HANDLE	hEqt, 				// Handle de l'�quipement
				CW_LPC_CHAR	pszBuf);			// ascuid des modifs

	CW_USHORT   ModifyEquipmentUserAttribute(
				CW_HANDLE	hEqt, 				// Handle de l'�quipement
				CW_USHORT   usIndex,
				CW_LPC_CHAR	pszBuf);			// ascuid des modifs

	CW_USHORT   GetEquipmentUserAttributes(
				CW_HANDLE  hEquipment,
				CW_LP_CHAR szParam,
				int        iParamMaxSize);

	CW_USHORT   GetEquipmentUserAttribute(
				CW_HANDLE  hEquipment,
				CW_USHORT  usIndex,
				CW_LP_CHAR szParam,
				int        iParamMaxSize);

	CW_USHORT   ModifyNetworkUserAttributes(
				CW_HANDLE	hNetwork, 			// Handle du r�seau
				CW_LPC_CHAR	pszBuf);			// ascuid des modifs

	CW_USHORT   ModifyNetworkUserAttribute(
				CW_HANDLE	hNetwork, 			// Handle du r�seau
				CW_USHORT   usIndex,
				CW_LPC_CHAR	pszBuf);			// ascuid des modifs

	CW_USHORT   GetNetworkUserAttributes(
				CW_HANDLE  hNetwork,
				CW_LP_CHAR szParam,
				int        iParamMaxSize);

	CW_USHORT   GetNetworkUserAttribute(
				CW_HANDLE  hNetwork,
				CW_USHORT  usIndex,
				CW_LP_CHAR szParam,
				int        iParamMaxSize);

	CW_USHORT	SetCyclicBoard(
				CW_USHORT usBoard,
				CW_USHORT usEnabled,
				CW_LP_USHORT lpusNbCyclic);

	CW_USHORT	SetCyclicNetwork(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEnabled,
				CW_LP_USHORT lpusNbCylic);

	CW_USHORT	SetCyclicEquipment(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt,
				CW_USHORT usEnabled,
				CW_LP_USHORT lpusNbCyclic);

	CW_USHORT	SetCyclicFrame(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt,
				CW_USHORT usFrame,
				CW_USHORT usEnabled);

	CW_USHORT	SetCyclicFramePeriod(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt,
				CW_USHORT usFrame,
				MSECS tcPeriod);

	CW_USHORT	SetCyclicLink(
				CW_USHORT usLinkId,
				CW_USHORT usEnabled);

	CW_USHORT	SetCyclicLink(
				CW_HANDLE hLink,
				CW_USHORT usEnabled);

	CW_USHORT	SetCyclicLinkPeriod(
				CW_HANDLE hLink,
				MSECS tcPeriod);

	CW_USHORT	SetCyclicLinkPeriod(
				CW_USHORT usLinkId,
				MSECS tcPeriod);

	CW_USHORT	SetWatchUnsolicitedBoard(
		CW_USHORT    usBoard,
		CW_USHORT    usEnabled,
		CW_LP_USHORT lpusNbWatchUnsolicited);

	CW_USHORT	SetWatchUnsolicitedNetwork(
		CW_USHORT    usBoard,
		CW_USHORT    usNetwork,
		CW_USHORT    usEnabled,
		CW_LP_USHORT lpusNbWatchUnsolicited);

	CW_USHORT	SetWatchUnsolicitedEquipment(
		CW_USHORT    usBoard,
		CW_USHORT    usNetwork,
		CW_USHORT    usEqt,
		CW_USHORT    usEnabled,
		CW_LP_USHORT lpusNbWatchUnsolicited);

	CW_USHORT	SetWatchUnsolicitedFrame(
		CW_USHORT usBoard,
		CW_USHORT usNetwork,
		CW_USHORT usEqt,
		CW_USHORT usFrame,
		CW_USHORT usEnabled);

	CW_USHORT	SetWatchUnsolicitedLink(
		CW_USHORT usLinkId,
		CW_USHORT usEnabled);

	CW_USHORT	UpdateDataTable(
				CW_USHORT usLinkId,
				CW_LP_UPDATE_INFO lpUpdateInfo);

	CW_USHORT	UpdateDataTable(
				CW_HANDLE hLink,
				CW_LP_UPDATE_INFO lpUpdateInfo);

	CW_USHORT	UpdateImageTable(
				CW_USHORT usLinkId);

	CW_USHORT	UpdateImageTable(
				CW_HANDLE hLink);

	CW_USHORT	GetLastUpdate(
				CW_USHORT usLinkId,
				CW_LP_LAST_UPDATE lpLastUpdate);

	CW_USHORT	GetStatus(
				CW_LP_PRO_STATUS lpStatus);

	CW_USHORT	GetBoardStatus(
				CW_USHORT usBoard,
				CW_LP_BOARD_STATUS lpBoardStatus);

	CW_USHORT	GetNetworkStatus(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_LP_NET_STATUS lpNetworkStatus);

	CW_USHORT	GetNetworkStatus(
				CW_HANDLE        hNetwork,
				CW_LP_NET_STATUS lpNetworkStatus);

	CW_USHORT	GetEquipmentStatus(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt,
				CW_LP_EQT_STATUS lpEqtStatus);

	CW_USHORT	GetEquipmentStatus(
				CW_HANDLE        hEqt,
				CW_LP_EQT_STATUS lpEqtStatus);

//	CW_USHORT	GetFrameStatus(
//				CW_USHORT usBoard,
//				CW_USHORT usNetwork,
//				CW_USHORT usEqt,
//				CW_USHORT usFrame,
//				CW_LP_FRM_STATUS lpFrameStatus);

	CW_USHORT	GetLinkStatus(
				CW_USHORT usLinkId,
				CW_LP_ACT_STATUS lpLinkStatus);

	CW_USHORT	GetLinkStatus(
				CW_HANDLE hLink,
				CW_LP_ACT_STATUS lpLinkStatus);

	CW_USHORT	ClearErrorCount( void);

	CW_USHORT	ClearBoardErrorCount(
				CW_USHORT usBoard);

	CW_USHORT	ClearNetworkErrorCount(
				CW_USHORT usBoard,
				CW_USHORT usNetwork);

	CW_USHORT	ClearEquipmentErrorCount(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt);

	CW_USHORT	ClearFrameErrorCount(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt,
				CW_USHORT usFrame);

	CW_USHORT	ClearLinkErrorCount(
				CW_USHORT usLinkId);

	// Fct d'audits #MODIFDL 03/04/06
	CW_USHORT	GetReadWriteNetWorkAudit(
				CW_HANDLE			a_hNet,
				CW_READWRITE_AUDIT	&a_RWAudit);

	CW_USHORT	GetReadWriteEqtAudit(
				CW_HANDLE			a_hEqt,
				CW_READWRITE_AUDIT	&a_RWAudit);

	CW_USHORT	GetReadWriteFrameAudit(
				CW_HANDLE			a_hFrame,
				CW_READWRITE_AUDIT	&a_RWAudit);


	//***
	//*** Information routines
	//***

public:

	CW_USHORT	GetInfo(
				CW_LP_PRO_INFO lpInfo);

	CW_USHORT	GetBoardInfo(
				CW_USHORT usBoard,
				CW_LP_BOARD_INFO lpBoardInfo);
	
	CW_USHORT	GetNetworkInfo(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_LP_NET_INFO lpNetworkInfo);

	CW_USHORT	GetEquipmentInfo(
				CW_USHORT usBoard,
				CW_USHORT usNetwork,
				CW_USHORT usEqt,
				CW_LP_EQT_INFO lpEqtInfo);

//	CW_USHORT	GetFrameInfo(
//				CW_USHORT usBoard,
//				CW_USHORT usNetwork,
//				CW_USHORT usEqt,
//				CW_USHORT usFrame,
//				CW_LP_FRM_INFO lpFrameInfo);

	CW_USHORT	GetLinkInfo(
				CW_USHORT usLinkId,
				CW_LP_ACT_INFO lpLinkInfo);

	CW_USHORT	GetLinkInfo(
				CW_HANDLE      hLink,
				CW_LP_ACT_INFO lpLinkInfo);

	CW_USHORT	GetDataInfo(
				CW_USHORT usDataId,
				CW_USHORT usTypeData,
				CW_LP_TAB_INFO lpDataInfo);


	CW_ULONG	GetNbBoard( void);
	CW_ULONG	GetNbNetwork( void);
	CW_ULONG	GetNbEqt( void);
	CW_ULONG	GetNbFrame( void);
	CW_ULONG	GetNbCyclicFrame( void);
	CW_ULONG	GetNbLink( void);
	CW_ULONG	GetNbData( void);

	CW_USHORT	GetVersion(
				struct _CwVersion *pCwVersion);
	CW_USHORT	GetProtocolVersion(
				CW_USHORT usBoard_UserId,
				CW_USHORT usNetwork_UserId,
				struct _CwVersion *pProtVersion);
		

	//***
	//*** Find Methods
	//***

	CW_USHORT	FindBoard_Number(
				CW_USHORT usBoard_Number,
				_CwBaseBoard **Board);

	CW_USHORT	FindBoard_UserId(
				CW_USHORT usBoard_UserId,
				_CwBaseBoard **Board);

	CW_USHORT	FindBoard_Rank(
				CW_USHORT usBoard_Rank,
				_CwBaseBoard **Board);

	CW_USHORT	FindNetwork_Number(
				CW_USHORT usBoard_Number,
				CW_USHORT usNetwork_Number,
				_CwBaseNetwork **Network);

	CW_USHORT	FindNetwork_UserId(
				CW_USHORT usBoard_UserId,
				CW_USHORT usNetwork_UserId,
				_CwBaseNetwork **Network);

	CW_USHORT	FindNetwork_Rank(
				CW_USHORT usBoard_Rank,
				CW_USHORT usNetwork_Rank,
				_CwBaseNetwork **Network);

	CW_USHORT	FindEqt_Number(
				CW_USHORT usBoard_Number,
				CW_USHORT usNetwork_Number,
				CW_USHORT usEqt_Number,
				_CwBaseEqt **Eqt);

	CW_USHORT	FindEqt_UserId(
				CW_USHORT usBoard_UserId,
				CW_USHORT usNetwork_UserId,
				CW_USHORT usEqt_UserId,
				_CwBaseEqt **Eqt);

	CW_USHORT	FindEqt_Rank(
				CW_USHORT usBoard_Rank,
				CW_USHORT usNetwork_Rank,
				CW_USHORT usEqt_Rank,
				_CwBaseEqt **Eqt);

	CW_USHORT	FindFrame_Number(
				CW_USHORT usBoard_Number,
				CW_USHORT usNetwork_Number,
				CW_USHORT usEqt_Number,
				CW_USHORT usFrame_Number,
				_CwBaseFrame **Frame);

	CW_USHORT	FindFrame_UserId(
				CW_USHORT usBoard_UserId,
				CW_USHORT usNetwork_UserId,
				CW_USHORT usEqt_UserId,
				CW_USHORT usFrame_UserId,
				_CwBaseFrame **Frame);

	CW_USHORT	FindFrame_Rank(
				CW_USHORT usBoard_Rank,
				CW_USHORT usNetwork_Rank,
				CW_USHORT usEqt_Rank,
				CW_USHORT usFrame_Rank,
				_CwBaseFrame **Frame);

	CW_USHORT	FindLink_Number(
				CW_USHORT usLink_Number,
				_CwBaseLink **Link);

	CW_USHORT	FindLink_UserId(
				CW_USHORT usLink_UserId,
				_CwBaseLink **Link);

	CW_USHORT	FindData_Number(
				CW_USHORT usData_Number,
				_CwBaseData **Data);

	CW_USHORT	FindData_UserId(
				CW_USHORT usData_UserId,
				CW_USHORT usTypeData,
				_CwBaseData **Data);

	CW_USHORT   SendAllNetworksMessage(
		CW_LPC_CHAR szMessage);

	CW_USHORT   SendNetworkMessage(
		CW_HANDLE   hNetwork,
		CW_LPC_CHAR szMessage);

	CW_USHORT   SendEquipmentMessage(
		CW_HANDLE   hEqt,
		CW_LPC_CHAR szMessage);

	CW_USHORT   SendFrameMessage(
		CW_HANDLE   hLink,
		CW_LPC_CHAR szMessage);

	CW_USHORT   BrowseNetwork(
		CW_HANDLE   hNetwork);

	CW_USHORT   BrowseNetworkDevice(
		CW_HANDLE   hNetwork,
		CW_LPC_CHAR szDeviceId);

	CW_USHORT   BrowseDevice(
		CW_HANDLE   hEqt);


	//
	// AUDIT
	//
public:	
	_CwAudit	*m_CwAudit;
};


extern "C" CW_IMPORT_EXPORT CW_USHORT MemCopy_Bit(
	CW_LP_BYTE Buffer,
	CW_ULONG   BufferPos,
	CW_LP_BYTE Delta,
	CW_ULONG   Len);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemCopyEx_Bit(
	CW_LP_BYTE Buffer,
	CW_ULONG   BufferPos,
	CW_LP_BYTE Delta,
	CW_ULONG   DeltaPos,
	CW_ULONG   Len);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemTestAndCopy_Bit(
	CW_LP_BYTE  Buffer,
	CW_ULONG    BufferPos,
	CW_LP_BYTE  Delta,
	CW_ULONG    Len,
	CW_LP_BYTE  Bitmap,
	CW_LP_ULONG pulCmpt);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemTestAndCopyEx_Bit(
	CW_LP_BYTE  Buffer,
	CW_ULONG    BufferPos,
	CW_LP_BYTE  Delta,
	CW_ULONG    DeltaPos,
	CW_ULONG    Len,
	CW_LP_BYTE  Bitmap,
	CW_LP_ULONG pulCmpt);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemCopy_Byte(
	CW_LP_BYTE Buffer,
	CW_ULONG   BufferPos,
	CW_LP_BYTE Delta,
	CW_ULONG   Len);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemCopyEx_Byte(
	CW_LP_BYTE Buffer,
	CW_ULONG   BufferPos,
	CW_LP_BYTE Delta,
	CW_ULONG   DeltaPos,
	CW_ULONG   Len);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemTestAndCopy_Byte(
	CW_LP_BYTE  Buffer,
	CW_ULONG    BufferPos,
	CW_LP_BYTE  Delta,
	CW_ULONG    Len,
	CW_LP_BYTE  Bitmap,
	CW_LP_ULONG pulCmpt);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemTestAndCopyEx_Byte(
	CW_LP_BYTE  Buffer,
	CW_ULONG    BufferPos,
	CW_LP_BYTE  Delta,
	CW_ULONG    DeltaPos,
	CW_ULONG    Len,
	CW_LP_BYTE  Bitmap,
	CW_LP_ULONG pulCmpt);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemCopy_Word(
	CW_LP_WORD Buffer,
	CW_ULONG   BufferPos,
	CW_LP_WORD Delta,
	CW_ULONG   Len);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemCopyEx_Word(
	CW_LP_WORD Buffer,
	CW_ULONG   BufferPos,
	CW_LP_WORD Delta,
	CW_ULONG   DeltaPos,
	CW_ULONG   Len);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemTestAndCopy_Word(
	CW_LP_WORD  Buffer,
	CW_ULONG    BufferPos,
	CW_LP_WORD  Delta,
	CW_ULONG    Len,
	CW_LP_BYTE  Bitmap,
	CW_LP_ULONG pulCmpt);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemTestAndCopyEx_Word(
	CW_LP_WORD  Buffer,
	CW_ULONG    BufferPos,
	CW_LP_WORD  Delta,
	CW_ULONG    DeltaPos,
	CW_ULONG    Len,
	CW_LP_BYTE  Bitmap,
	CW_LP_ULONG pulCmpt);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemCopy_DWord(
	CW_LP_DWORD Buffer,
	CW_ULONG    BufferPos,
	CW_LP_DWORD Delta,
	CW_ULONG    Len);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemCopyEx_DWord(
	CW_LP_DWORD Buffer,
	CW_ULONG    BufferPos,
	CW_LP_DWORD Delta,
	CW_ULONG    DeltaPos,
	CW_ULONG    Len);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemTestAndCopy_DWord(
	CW_LP_DWORD Buffer,
	CW_ULONG    BufferPos,
	CW_LP_DWORD Delta,
	CW_ULONG    Len,
	CW_LP_BYTE  Bitmap,
	CW_LP_ULONG pulCmpt);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemTestAndCopyEx_DWord(
	CW_LP_DWORD Buffer,
	CW_ULONG    BufferPos,
	CW_LP_DWORD Delta,
	CW_ULONG    DeltaPos,
	CW_ULONG    Len,
	CW_LP_BYTE  Bitmap,
	CW_LP_ULONG pulCmpt);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemCopy_Real(
	CW_LP_REAL Buffer,
	CW_ULONG   BufferPos,
	CW_LP_REAL Delta,
	CW_ULONG   Len);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemCopyEx_Real(
	CW_LP_REAL Buffer,
	CW_ULONG   BufferPos,
	CW_LP_REAL Delta,
	CW_ULONG   DeltaPos,
	CW_ULONG   Len);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemTestAndCopy_Real(
	CW_LP_REAL  Buffer,
	CW_ULONG    BufferPos,
	CW_LP_REAL  Delta,
	CW_ULONG    Len,
	CW_LP_BYTE  Bitmap,
	CW_LP_ULONG pulCmpt);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemTestAndCopyEx_Real(
	CW_LP_REAL  Buffer,
	CW_ULONG    BufferPos,
	CW_LP_REAL  Delta,
	CW_ULONG    DeltaPos,
	CW_ULONG    Len,
	CW_LP_BYTE  Bitmap,
	CW_LP_ULONG pulCmpt);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemSet_ExtraSize(
	CW_LP_VOID lpvDest,
	CW_BYTE    c,
	CW_ULONG   ulSize);

extern "C" CW_IMPORT_EXPORT CW_USHORT MemCpy_ExtraSize(
	CW_LP_VOID lpvDest,
	CW_LP_VOID lpvSrc,
	CW_ULONG   ulSize);




// Code Erreur Protocole

#define	TABLE_IMAGE				0 /* Table image concern�e */
#define	TABLE_DONNEES			1 /* Table de donn�es concern�e */

#define CMDE_INCONNUE			1
#define ADR_BUFFER_INVALIDE		4
#define TAILLE_BUFFER_ERRONE	5
#define TRANSF_DONNEES_INTERDIT	6
#define ATTENTE_DUREE_NULLE		7

#endif /* _CW_H_ */
