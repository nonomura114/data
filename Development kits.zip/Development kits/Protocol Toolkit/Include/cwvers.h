
#ifndef _CWVERSION_H_

	#define _CWVERSION_H_

	#ifdef __cplusplus
	extern "C" {
	#endif

	struct _CwVersion
	{
		CW_USHORT	MajorVersion;
		CW_USHORT	MinorVersion;
		CW_ULONG	BuildNumber;
		CW_CHAR		VendorInfo[255];
	};

	typedef void
		(*TYPE_GetProtocolVersion)( struct _CwVersion *pProtVersion);

	#ifdef __cplusplus
	}
	#endif


#endif // _CWVERSION_H_
