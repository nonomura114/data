/*--------------------------------------------------------------------------*/
/*																			*/
/*		PROJECT		:	LIBRAIRIE GENERIQUE D'ACCES A LA COUCHE PHYSIQUE	*/
/*																			*/
/*		MODULE		:	cwio.h												*/
/*																			*/
/*		VERSION		:	1.00												*/
/*																			*/
/*		SYSTEMES	:	Windows 95 , Windows NT								*/
/*																			*/
/*		AUTHOR		:	Eric PERROTIN										*/
/*																			*/
/*		PURPOSE		:	Classe g�n�rique d'acc�s � la couche physique		*/
/*																			*/
/*--------------------------------------------------------------------------*/


#ifndef _CWIO_H_

	#define _CWIO_H_


// Definition of layer 1 types driven by Cimway
#define		LAYERONE_NONE			0
#define		LAYERONE_SERIAL_PORT	1
#define		LAYERONE_TCPIP			2

// Working modes of the comm.port
#define		WMODE_MASTER			0
#define		WMODE_SLAVE				1
#define		WMODE_MASTERMASTER		2





//******************************
//
//	_CwIO Class
//
//******************************

class _CwIO: public CObject 
{
//***
//***	CONSTRUCTOR
//***
public:

		_CwIO( _CwBaseNetwork *pNetworkOwner);  //#MODIFJS 10/03/99 - Gestion des param�tres s�ries (Prot. NG)


// Members
protected:

	_CwBaseNetwork  *m_pNetworkOwner;   //#MODIFJS 10/03/99 - Gestion des param�tres s�ries (Prot. NG)

//***
//***	ERROR
//***
private:

	CW_BOOL       m_bCwIOError;
	_ProtError    m_pCwIOError;

protected:

	CW_VOID       CwIOResetError( CW_VOID);
	CW_VOID       CwIOSetError( _ProtErrorLevel PEL, _ProtErrorClass PEC, CW_LONG PECODE);
	
public:

	CW_BOOL       CwIOGetLastError( _ProtError *pErr);
	CW_BOOL       CwIOIsErrorOccured( void);

public:

	CW_CHAR       m_ucMsgLastError[255];
	CW_VOID       CwIOGetLastError( CW_VOID );

//***
//***	WORKING MODE
//***
protected:
	CW_UCHAR		m_ucWorkingMode;	// Comm mode:master,slave,master/master

	CW_VOID			SetWorkingMode( CW_UCHAR );
	CW_UCHAR		GetWorkingMode( CW_VOID );
	

	
//***
//***	PORT INIT/RESET & COMM START/STOP
//***
public:
	// Initialize communication port settings and create threads
	virtual	CW_USHORT		Initialize(_AD *)	= 0;

	// Reset communication port settings
	virtual	CW_VOID			Reset(CW_VOID)		= 0;
	
	// Open communication port and start threads
	virtual	CW_USHORT		Start(CW_VOID)		= 0;
	
	// Close communication port
	virtual	CW_VOID			Stop(CW_VOID)		= 0;
};


#endif