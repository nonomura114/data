#ifndef _CWEQT_H_
#define _CWEQT_H_

//************************************************
//**
//** _CwBaseEqtThread
//**
//************************************************
class _CwBaseEqtThread: public _CwThreadMail
{
private:
	_CwBaseEqt	*m_pCwBaseEqt;	// Pointeur sur l'objet EQT

public:
	_CwBaseEqtThread(
		CString      &csThreadName,
		_CwBaseEqt   *pCwBaseEqt);

protected:
	void SpecificRun( CW_ULONG ulEvent);
};

//************************************************
//**
//** _CwBaseEqt
//**
//************************************************
class CW_IMPORT_EXPORT _CwBaseEqt: public _CommunicationObject
{
	DECLARE_DYNAMIC( _CwBaseEqt)

public:
	//***
	//*** Eqt - Configuration
	//***

public:

	CW_USHORT   GetFrameFromName( char *pszName, _CwBaseFrame **pNetFrame);
	//#MODIFFRM 07/12/00
	virtual void    OnModifyConfigEx(CW_USHORT pAddress, CW_LPC_CHAR lpszConfigBuffer,CW_USHORT pParametersCounter){};
	virtual void    ModifyConfigEx(CW_USHORT pAddress, CW_LPC_CHAR lpszConfigBuffer,CW_USHORT pParametersCounter);
	//#ENDMODIFFRM 07/12/00
	//#MODIFFRM 30/09/02
	virtual void	OnModifyPhoneNumber( CString strPhoneNumber) {};
	virtual void    ModifyPhoneNumber( CString strPhoneNumber);
	virtual void	OnModifyMaxConnectionDuration(CW_USHORT usMaxConnectionDuration) {};
	virtual void    ModifyMaxConnectionDuration(CW_USHORT usMaxConnectionDuration);
	//#ENDMODIFFRM 30/09/02
	
protected:

	_LinkedList *m_llFrame;
	_LinkedList *m_llCyclicFrame;
	_LinkedList *m_llWatchUnsolicitedFrame;

private:

	CW_ULONG    m_ulAddress;
	MSECS       m_msTimeOut;

	MSECS       m_msTurnAroundTime;		// D�lai de retournement
	MSECS       m_msReturnStartTime;

	MSECS		m_msDeltaTS;			//#MODIFED 12/10/10

    CW_USHORT   m_usRoutingAddress; //#MODIFED 17/04/13

public:
	_CwBaseNetwork *GetNetwork( void) { return ( _CwBaseNetwork *)GetOwner(); }

	CW_ULONG    GetNbFrame( void)                  { return LL_COUNT( m_llFrame); }
	CW_ULONG    GetNbCyclicFrame( void)            { return LL_COUNT( m_llCyclicFrame); }
	CW_ULONG    GetNbWatchUnsolicitedFrame( void)  { return LL_COUNT( m_llWatchUnsolicitedFrame); }

	void        SetAddress( CW_ULONG usAddress);
	void        SetTimeOut( MSECS msTimeOut);
	void        SetDeltaTS( MSECS msDeltaTS);	//#MODIFED 12/10/10
	void        SetTurnAroundTime( MSECS msTurnAroundTime);
    void        SetRoutingAddress( CW_USHORT usRoutingAddress); //#MODIFED 17/04/13

	CW_ULONG    GetAddress( void)           { return m_ulAddress; }
	MSECS       GetTimeOut( void)           { return m_msTimeOut; }
	MSECS       GetTurnAroundTime( void)    { return m_msTurnAroundTime; }
	MSECS       GetDeltaTS( void)           { return m_msDeltaTS; }		//#MODIFED 12/10/10
    CW_USHORT   GetRoutingAddress( void)    { return m_usRoutingAddress; }//#MODIFED 17/04/13

	void        StartTurnAroundTime( void);
	void		ProcessTurnAroundTime( void);
	CW_BOOL		IsProcessingTurnAround( void);

protected:

	virtual void      ResetConfiguration( void);
	virtual void      OnSetAddress( CW_ULONG ulAddress)               {}
	virtual void      OnSetTimeOut( MSECS msTimeOut)                  {}
	virtual void      OnSetTurnAroundTime( MSECS msTurnAroundTime)    {}
	virtual void      OnSetDeltaTS( MSECS msDeltaTS)                  {} //#MODIFED 12/10/10
    virtual void      OnSetRoutingAddress(CW_USHORT usRoutingAddress) {} //#MODIFED 17/04/13

	//***
	//*** Eqt - States
	//***

private:

	CW_BOOL			m_bNS;
	CW_BOOL			m_bBroadcast;

public:

	void			SetNS( void);
	void			SetBroadcast( void);
	void			SetAvailable( void);

	void			ResetNS( void);
	void			ResetBroadcast( void);
	void			ResetAvailable( void);

	CW_BOOL			IsNS( void)          { return m_bNS; }
	CW_BOOL			IsBroadcast( void)   { return m_bBroadcast; }
	virtual CW_BOOL	IsAvailable( void);

protected:
	virtual void	OnSetNS( void)             {}
	virtual void	OnResetNS( void)           {}
	virtual void	OnSetAvailable( void)      {}
	virtual void	OnResetAvailable( void)    {}
	virtual void	OnSetBroadcast( void)      {}
	virtual void	OnResetBroadcast( void)    {}

protected:

	void        ResetStates( void);


	//***
	//*** Eqt - State Errors
	//***

private:

	CW_BOOL     m_bLastCmdFailed;

public:

	void        SetLastCmdFailed( void);
	void        ResetLastCmdFailed( void);
	CW_BOOL     IsLastCmdFailed( void)      { return m_bLastCmdFailed; }

	void        ResetStateErrors(BOOL bResetOutOfOrder = TRUE );//#MODIFFRM 02/07/04

protected:

	virtual void	OnSetLastCmdFailed( void)    {}
	virtual void	OnResetLastCmdFailed( void)  {}


	//***
	//*** Eqt - Constructor & Destructor
	//***

public:

		_CwBaseEqt( void);
		virtual ~_CwBaseEqt( void);

	CW_USHORT   Initialize(
		CW_USHORT UserId,
		_CwBaseNetwork *Owner,
		_AD *adFile);

	void        Terminate( void);

protected:

	virtual CW_USHORT  BeforeInitialize( _AD *adFile)  { return CW_OK; }
	virtual CW_USHORT  AfterInitialize( _AD *adFile)   { return CW_OK; }

public:

	
	//***
	//*** Eqt - Specific Construction
	//***

public:

	CW_USHORT	CreateFrame( _AD *adFile);

	virtual _CwBaseFrame	*OnCreateFrame( void);

	CW_ULONG	RegistryFrame( _CwBaseFrame *Frame);
	void		RegistryCyclicFrame( _CwBaseFrame *Frame);
	void        RegistryWatchUnsolicitedFrame( _CwBaseFrame *Frame);
	void		RegistryLink( _CwBaseLink *Link);
	void		RegistryData( _CwBaseData *Data);

	void		UnregistryFrame( _CwBaseFrame *Frame);
	void		UnregistryCyclicFrame( _CwBaseFrame *Frame);
	void        UnregistryWatchUnsolicitedFrame( _CwBaseFrame *Frame);
	void		UnregistryLink( _CwBaseLink *Link);
	void		UnregistryData( _CwBaseData *Data);

protected:

	virtual void	OnRegistryFrame( _CwBaseFrame *Frame)                  {}
	virtual void	OnRegistryCyclicFrame( _CwBaseFrame *Frame)            {}
	virtual void    OnRegistryWatchUnsolicitedFrame( _CwBaseFrame *Frame)  {}
	virtual void	OnRegistryLink( _CwBaseLink *Link)                     {}
	virtual void	OnRegistryData( _CwBaseData *Data)                     {}

	virtual void	OnUnregistryFrame( _CwBaseFrame *Frame)                {}
	virtual void	OnUnregistryCyclicFrame( _CwBaseFrame *Frame)          {}
	virtual void    OnUnregistryWatchUFrame( _CwBaseFrame *Frame)          {}
	virtual void	OnUnregistryLink( _CwBaseLink *Link)                   {}
	virtual void	OnUnregistryData( _CwBaseData *Data)                   {}

	//***
	//*** Eqt - Management Routines
	//***

public:

	CW_USHORT	GetInfo( CW_LP_EQT_INFO lpInfo);
	CW_USHORT	GetStatus( CW_LP_EQT_STATUS lpStatus);
	CW_USHORT	GetReadWriteAudit( CW_READWRITE_AUDIT	&a_RWAudit);

protected:

	virtual void   OnGetInfo( CW_LP_EQT_INFO lpInfo)            {}
	virtual void   OnGetStatus( CW_LP_EQT_STATUS lpStatus)      {}

	CW_USHORT   ReadyToBeActivate( void);
	void        SpecificStart( void);
	CW_USHORT   StartCommand( CW_USHORT usMode);

	CW_USHORT   ReadyToBeInactivate( void);
	void        SpecificStop( CW_BOOL bInternalStop);
	CW_USHORT   StopCommand( CW_BOOL bInternalStop, CW_USHORT usMode);
	CW_USHORT   BeforeStopCommand( void);

	void           SpecificStartCyclic( void);
	void           SpecificStopCyclic( void);
	void           SpecificStartWatchUnsolicited( void);
	void           SpecificStopWatchUnsolicited( void);

	CW_USHORT      IsCyclicReadyToBeActivate( CW_BOOL bFullStart, CW_BOOL bInconditionalStart);
	CW_USHORT      IsWatchUnsolicitedReadyToBeActivate( CW_BOOL bFullStart);
	CW_USHORT      IsCyclicReadyToBeInactivate( void)             { return CW_OK; }
	CW_USHORT      IsWatchUnsolicitedReadyToBeInactivate( void)   { return CW_OK; }

public:
	
	CW_USHORT   AfterStopCommand(CW_BOOL bInternalStop) override;

	virtual void   OnInitialize(_AD *adFile) {}
	virtual void   OnTerminate(void) {}

	virtual void   StartCyclicCommand( void)           {}
	virtual void   StopCyclicCommand( void)            {}
	virtual void   StartWatchUnsolicitedCommand( void) {}
	virtual void   StopWatchUnsolicitedCommand( void)  {}

	void SendMessage(LPCTSTR szMessage);
	virtual void   OnReceiveMessage( LPCTSTR szMessage) {}

	virtual void BrowseDevice(void);

protected:

	//***
	//*** Eqt - Command Management Routines
	//***

	virtual void    ModifyConfigCommand(CW_LPC_CHAR szConfiguration);

private:

	CW_CHAR		m_szSynchroEventName[SIZE_MAX_SYNCHROEVENT_NAME];
	_Event		*m_SynchroEvent;

	_CriticalSection m_csCommandEndOrAbort;
	_LinkSingleList	*m_llCommandEndOrAbort;		// Cmdes termin�es ou avort�es

public:

	CW_BOOL     ExecuteCmd( _Command *Cmd);

private:

	CW_BOOL     m_bSynchrone;         // Commande en cours est-elle synchrone ?
	CW_USHORT   m_SyncResult;         // Compte-rendu d'�xecution de la derniere commande synchrone

protected:

	CW_USHORT	ClearCmd( _Command *);

	_CriticalSection m_csCommandInProgress;
	_LinkSingleList *m_llCommandInProgress;		// Cmdes en traitement

protected:

	CW_USHORT   SendMessage(_Command *);

public:

	CW_USHORT	WriteCmd( _Command *, CW_BOOL);		// Envoi d'une commande protocole
	CW_USHORT	WriteCmdResp( _Command *);	// Envoi d'une r�ponse d'une commande protocole

	void		TerminateCmd( _Command *);
	
	void		SetSyncResult( CW_USHORT usSyncResult)   { m_SyncResult = usSyncResult; }
	CW_LP_CHAR	GetSynchroEventName( void)               { return m_szSynchroEventName; }
	_Event		*GetSynchroEvent( void)                  { return m_SynchroEvent; }
	
	virtual void ControlCommandInProgress( void);

	//***
	//*** Eqt - Find Methods
	//***

public:

	CW_USHORT   FindFrame_UserId(
		CW_USHORT    usFrame_UserId,
		_CwBaseFrame **Frame);

	CW_USHORT   FindFrame_Rank(
		CW_USHORT    usFrame_Rank,
		_CwBaseFrame **Frame);

	CW_USHORT   FindFrame_Number(
		CW_USHORT    usFrame_Number,
		_CwBaseFrame **Frame);

	CW_USHORT   FindFrame_AddressType(
		CW_ULONG     ulData_Addr,
		CW_USHORT    usData_Type,
		_CwBaseData  **Data);


	//***
	//*** Eqt - Specific routines
	//***

public:

	void        SetValid( void);
	void        SetInvalid( _ProtError *pErr);
	void        DispatchInvalid( CW_BOOL bDispatchToSystemFrame);

	virtual _ProtRet Start_Async( _ProtStartEqtCmd *pStartEqtCmd)   { return PR_CMD_NOT_PROCESSED; }
	virtual _ProtRet Stop_Async( _ProtStopEqtCmd *pStopEqtCmd)      { return PR_CMD_NOT_PROCESSED; }
	virtual _ProtRet BrowseDevice_Async(_ProtBrowseEqtCmd *pBrowseEqtCmd) { return PR_CMD_NEVER_PROCESSED; }

	virtual void AbortStartEqtCmd( _ProtStartEqtCmd *pStartEqtCmd)  {}
	virtual void AbortStopEqtCmd( _ProtStopEqtCmd *pStopEqtCmd)     {}

protected:
	union _AvailableStatus
	{
		struct {
			CW_ULONG  fAvailable:1;		// 1 : Le ComObject est indisponible
			CW_ULONG  fTurnAround:1;	// 1 : Le ComObject ex�cute un d�lai de retournement
			CW_ULONG  fNs:1;			// 1 : Le ComObject est en erreur
			CW_ULONG  fDummy:30;
		} m_ulFlagAvailableStatus;

		CW_ULONG m_StateAvailableStatus;
	};

public:

	union _AvailableStatus m_ulAvailableStatus;

public:

	_CriticalSection	m_csAvailableStatus;
	CW_BOOL				IsAvailableStatus( void);

	//#MODIFJS 27/10/98 - Audit des temps de lecture

protected:

	CW_FLOAT m_fltMinReadTime;
	CW_FLOAT m_fltMaxReadTime;
	CW_FLOAT m_fltAverageReadTime;
	CW_FLOAT m_fltScheduleRead;

	CW_DWORD m_dwReadCpt;

public:

	void  statWrite( CString &csBuffer);

	void statEndRead(
		CW_FLOAT fltMinReadTime,
		CW_FLOAT fltMaxReadTime,
		CW_FLOAT fltAverageReadTime,
		CW_FLOAT fltScheduleRead);

	//#ENDMODIFJS 27/10/98 - Audit des temps de lecture

private: 

	_CwMailBox  *m_CwMailBox;

public:

	#define THREADEQT_NAME	"CwThreadEqt_%s"
	_CwBaseEqtThread  *m_ThreadProtocolEqt;

	void Run_MultiFlux( void);

	CW_BOOL DynamicTest(
		_Command       *pCmd,
		_EqtManagement &eqtManagement,
		CW_BOOL        bAvailableManaging);

	CW_BOOL DynamicTest(
		_Command       *pCmd);

    inline CW_BOOL MailBoxIsEmpty( void)
    {
	    return m_CwMailBox->IsEmpty();
    }
};

#endif _CWEQT_H_