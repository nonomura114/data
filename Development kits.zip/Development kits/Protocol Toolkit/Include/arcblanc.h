	/***********************************************************************;
	;-----------------------------------------------------------------------;
	;
	: Definition des constantes et des structures utilisees pour un
	; protocole blanc realise par ARC INFORMATIQUE.
	;
	;-----------------------------------------------------------------------;
	;************************************************************************/

#ifndef _ARCBLANC_H_

	#define _ARCBLANC_H_

/* definition des constantes du protocole */

	 /* commandes application */
#define INIT_RESEAU					1
#define MAINTIEN_RESEAU				2
#define ARRET_RESEAU					3
#define INIT_EQT						4
#define ARRET_EQT 					5
#define LECTURE						6
#define ECRITURE						7
#define TST_DISPO						8
#define RAZ_DISPO						9

	 /* comptes rendus */
#define FIN_EMIS_CAR					1
#define FIN_EMIS_BREAK				2
#define TO_EMISSION					3
#define FIN_RCP_TRAME				4
#define FIN_RCP_BREAK				5
#define TO_RECEPTION					6
#define FIN_ATTENTE					7
#define FIN_TRANSFERT				8
#define ABORT							9
#define FIN_INDIC_ERR				10
#define FIN_CREDIT					11
#define FIN_PURGE_MESSAGE			12

	 /* demandes de traitement specifique */
#define FIN_TRAITEMENT				1
#define EMISSION						2
#define RECEPTION 					3
#define EMIS_RCP						4
#define ATTENTE						5
#define TRANSFERT_CIM				6
#define TRANSFERT_PROT				7
#define TRANSFERT_PAGE_CIM 		8
#define TRANSFERT_PAGE_PROT		9
#define INDICATION_ERREUR			10
#define TRANSFERT_PARTIEL_CIM		11
#define TRANSFERT_PARTIEL_PROT	12
#define EMIS_ECHO						13
#define CREDIT							14
#define PURGE_MESSAGE				15

	 /* niveaux d'erreur */
#define NIVEAU_RESEAU				1
#define NIVEAU_AP 					2
#define NIVEAU_ECHANGE				3

	 /* codes d'erreur */

		/* pas d'erreur */
#define TRAITEMENT_OK				0
#define CMDE_NON_GEREE				255

//#MODIF JS 13/06/1996

	/* erreurs detect�es par le driver blanc */
#define CMDE_INCONNUE				1
#define EMISSION_INCONNUE			2
#define EMISSION_DUREE_NULLE		3
#define ADR_BUFFER_INVALIDE			4
#define TAILLE_BUFFER_ERRONE		5
#define TRANSF_DONNEES_INTERDIT		6
#define ATTENTE_DUREE_NULLE			7

#define PARAMETRE_ERRONE			10
#define INVALID_DESBLANC			11
#define INVALID_DESPAG				12
#define INVALID_DESAP				13
#define INVALID_DESVOIE				14
#define INVALID_ERRNIV7				15

//#ENDMODIF JS

		/* erreur de transmission */
#define FRAMING_ERR					30
#define OVERRUN_ERR					31
#define PARITE_ERR					32
#define CHECKSUM_ERR 				33
#define BREAK_ERR 					34

		/* erreur de protocole */
#define NBDATA_ERR					35
#define DATA_ADR_FIELD_ERR			36
#define DATA_FIELD_ERR				37
#define EQT_ADR_FIELD_ERR			38
#define CMDE_NACKEE					39
#define EMISSION_ERR 	  			40

		/* erreur de configuration */
#define ADR_EQT_ERR					41
#define TYPE_EQT_ERR 				42
#define ADR_DONNEES_ERR 			43
#define TYPE_DONNEES_ERR			44
#define LG_DONNEES_ERR				45

			/* erreur retourn�e par le correspondant */
#define ERR_RECUPEREE				46 /* erreur d�tect�e par l'�quipement */
#define ERR_TRANSMIT				48 /* erreur de transmission, de d�phasage */
#define ERR_PROTOCOLE				49 /* erreur d�tect�e par le protocole */
#define ERR_DU_RESEAU				50 /* erreur d�tect�e par le r�seau */

//#MODIFJS 04/12/98 - Gestion d'erreur 'DLL not found'
#define ERR_LIBRARY                 51
//#ENDMODIFJS 04/12/98 - Gestion d'erreur 'DLL not found'

			/* Fin de la commande en cours */
			/* On indique que celle-ci c'est mal passee */
#define TRAITEMENT_PASOK			47

/* constante type des donnees dans la B.D Cimway */
#define TYPE_BIT						1
#define TYPE_OCTET					2
#define TYPE_MOT						3
#define TYPE_REEL 					4
#define TYPE_LONG 					5

/* types d'emission */
#define EMISSION_BREAK				1
#define EMISSION_CAR 				2


/* Constantes utilisees pour le champ gravite_erreur du DESBLANC */
/* -------------------------------------------------------------- */
#define	ERREUR_NON_FATALE			0 /* Erreur non catastrophique pour l'echange */
#define	ERREUR_FATALE				1 /* Erreur catastrophique pour l'echange: Il n'y a pas de repetition d'effectuee pour ce type d'erreur.*/

/* Les diff�rents type de table */
/* ---------------------------- */
#define	TABLE_IMAGE					0 /* Table image concern�e */
#define	TABLE_DONNEES				1 /* Table de donn�es concern�e */


/* Les diff�rents types de datation (interne par defaut) */
/* ----------------------------------------------------- */
#define	DATATION_INTERNE			0
#define	DATATION_EXTERNE			1


/* Param�tre au chargement du protocole (re�us sur le main()) */ 
#define NBMAX_PARAM					8  /* Nombre max de param�tre: Attention le 1er param�tre est le nom du protocole avec son chemin d'acc�s */
#define SIZEMAX_PARAM				32 /* La taille max d'un param�tre doit etre inf�rieure � 32 octets. */
	
/* D�claration des variables externes */	
/* ---------------------------------- */
/* Tableau o� sont stock�s les param�tres de chargement du protocole */
extern char Param[NBMAX_PARAM][SIZEMAX_PARAM+1]; 

/* type du bloc de commande DESBLANC */
typedef struct
{
	MOT					commande_appli;
	MOT					compte_rendu;
	MOT					commande_protoc;
	MOT					code_erreur;
	MOT					adresse_eqt;
	MOT					type_eqt;
	MOT					adresse_donnees;
	MOT					type_donnees_eqt;
	MOT					type_donnees_cim;
	MOT					nbre_donnees;
	MOT					type_emission;
	MOT					duree_emission;
	MOT					duree_reception;
	MOT					duree_attente;
	OCTET 				*adr_emis;
	MOT					index_emis_max;
	MOT					index_emis_deb;
	OCTET 				*adr_rcv;
	MOT					index_rcv_max;
	MOT					index_rcv_courant;
	struct sdesvoie 	*desvoie;			/* pointeur far sur le DESVOIE courant */
	MOT					rang;
	struct sdescom 	*descom;				/* pointeur far sur le DESCOM */
	MOT					ofs_pag;				/* offset du DESPAG courant */
	MOT					frame_len;			/* nombre de car restant dans la trame recue */
	MOT					gravite_erreur;	/* Non fatale = 0 sinon fatale */
	struct sErrNiv7	*ptr_ErrNiv7;		/* ptr sur une strutrure de type sErrNiv7 */
	MOT			 		sous_code_erreur;
	MOT					com_auto;			/* type de la commande 0 si appli, 1 si autocad geree par la couche 7 */
	MOT					type_table;			/* Type de la table, donn�es ou image */
	MOT					ofs_ap;				/* offset du DESAP courant */
	MOT					type_datation;		/* type de datation, interne ou externe */
	OCTET					date_jour;
	OCTET					date_mois;
	OCTET					date_annee;		// #MODIFDL 22/09/97
	OCTET					date_heure;
	OCTET					date_minute;
	MOT					date_millisec;
	MOT					bloquant;
	MOT					dispo;
  	MOT					valeur_credit;
  	MOT					(*si_credit)();
	MOT					seg_prot;
  	OCTET   				*message;

	CW_LP_VOID			lpNetwork;
	CW_LP_VOID			lpEqt;
	CW_LP_VOID			lpFrame;
	CW_LP_VOID			lpCommand;
	
	//#MODIFJS 04/12/98 - Gestion d'erreur 'DLL not found'
	CHAR                lpszErrorDesc[ 64];
	//#ENDMODIFJS 04/12/98 - Gestion d'erreur 'DLL not found'

} TYP_DESBLANC;


/* constantes de codage de donnees sur la ligne */
#define CODLIG_BIN				1
#define CODLIG_BCD				4

#endif /* _ARCBLANC_H_ */
