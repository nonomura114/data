#ifndef _CWLINK_H_
#define _CWLINK_H_

//************************************************
//**
//** _CwBaseLink
//**
//************************************************


class CW_IMPORT_EXPORT _CwBaseLink: public _DefaultObject
{
	DECLARE_DYNAMIC( _CwBaseLink)

	//***
	//*** Link - Configuration
	//***

private:

	_CwBaseFrame   *m_Frame;
	_CwBaseData    *m_Data;

	CW_HANDLE	m_hClientFrame;

protected:

	void		SetData( _CwBaseData *Data);
	void		SetFrame( _CwBaseFrame *Frame);

	virtual void   OnSetFrame( _CwBaseFrame *Frame);
	virtual void   OnSetData( _CwBaseData *Data);

public:

	_CwBaseFrame   *GetFrame( void);
	_CwBaseData    *GetData( void);

	void		SetFrameClientHandle( CW_HANDLE hClientFrame);
	CW_HANDLE 	GetFrameClientHandle( void);

	//***
	//*** Link - Constructor & Destructor
	//***

public:

		_CwBaseLink( void);
		virtual ~_CwBaseLink( void);

	CW_USHORT	Initialize( CW_USHORT UserId, _CwBaseFrame *Owner, _AD *adFile);
	void		Terminate( void);

protected:

	virtual void	Reset( void);

	virtual CW_USHORT BeforeInitialize( _AD *adFile);
	virtual CW_USHORT AfterInitialize( _AD *adFile);

	//***
	//*** Link - Specific Constructor
	//***

	CW_USHORT	CreateData( _AD *adFile);

	virtual _CwBaseData	*OnCreateByteData( _AD *adFile);
	virtual _CwBaseData	*OnCreateWordData( _AD *adFile);
	virtual _CwBaseData	*OnCreateRealData( _AD *adFile);
	virtual _CwBaseData	*OnCreateDWordData( _AD *adFile);
	virtual _CwBaseData	*OnCreateBitData( _AD *adFile);

	virtual _CwBaseData	*OnCreateSpecificData(
		CW_USHORT usDataType,
		_AD *adFile);

public:

	void		RegistryData( _CwBaseData *Data);

	void		UnregistryData( _CwBaseData *Data);

protected:

	virtual void	OnRegistryData( _CwBaseData *Data);

	virtual void	OnUnregistryData( _CwBaseData *Data);

	//***
	//*** Link - Management Routines
	//***

public:

	CW_USHORT	GetInfo( CW_LP_ACT_INFO lpInfo);
	CW_USHORT	GetStatus( CW_LP_ACT_STATUS lpStatus);

protected:

	virtual void	OnGetInfo( CW_LP_ACT_INFO lpInfo);
	virtual void	OnGetStatus( CW_LP_ACT_STATUS lpStatus);


	//***
	//*** Link - Specific Methods
	//***
};

#endif // _CWLINK_H_