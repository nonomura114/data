//****************************************************************************
//*                                                                          *
//*  MODULE NAME :  CWTIMDAT.h                                               *
//*                                                                          *
//*  AUTHOR      :  Thierry DESBIENS                                         *
//*                                                                          *
//*  PURPOSE     :  This file contains structure definitions, defined        *
//*                 constants and class to encapsulate the TimDat object     *
//*                 that represents an absolute time and date.               *
//*                                                                          *
//*                 An absolute time and date is a number of milliseconds    *
//*                 elapsed since January 1, 1970. Note that DOS and OS/2 do *
//*                 not accommodate the value in dates prior to January 1,   *
//*                 1980. This TimDat value is stored in a double and is     *
//*                 limited in the range 1980 to 2037, approximately.        *
//*                                                                          *
//*                 The TimDat class is not designed for derivation. Because *
//*                 there are no virtual functions, the size of TimDat       *
//*                 objects is exactly 8 bytes. Some member functions are    *
//*                 inline.                                                  *
//*                                                                          *
//****************************************************************************


#ifndef _CWTIMDAT_H_         // Only include it once
#define _CWTIMDAT_H_


#ifndef __cplusplus
#error _TimDat class require C++ compilation
#endif


// Structure to represent an absolute time and date (for backward compatibility)
// -----------------------------------------------------------------------------

typedef struct
{
long            tim;  // Absolute time and date in secondes.
unsigned short  ms;   // Milliseconds in the range 0 through 999.
}
_OldTimDat;


// TimDat extraction components (TimDat::GetComponents() member function)
// ----------------------------------------------------------------------

typedef struct
{
int     nYear;               // Specifies the year in the range 1980 to 2037.
int     nMonth;              // Specifies the month in the range 1 through 12 (1 = January).
int     nDay;                // Specifies the day of the month in the range 1 through 31.
int     nDayOfWeek;          // Specifies the day of the week in the range 0 through 6 (0 = Sunday).
int     nDayOfYear;          // Specifies the day of the year in the range 1 through 366.
int     nWeekOfYear;         // Specifies the week of the year in the range 1 through 53.
int     nHour;               // Specifies the hour in the range 0 through 23.
int     nMinute;             // Specifies the minute in the range 0 through 59.
int     nSecond;             // Specifies the second in the range 0 through 59.
int     nMillisecond;        // Specifies the millisecond in the range 0 through 999.
long    lTotalDays;          // Specifies the total number of complete days in a TimDat object.
long    lTotalHours;         // Specifies the total number of complete hours in a TimDat object.
long    lTotalMinutes;       // Specifies the total number of complete minutes in a TimDat object.
long    lTotalSeconds;       // Specifies the total number of complete seconds in a TimDat object.
double  dTotalMilliseconds;  // Specifies the total number of complete milliseconds in a TimDat object.
int     fLeapYear;           // Specifies whether the year is a leap year.
}
_TimDatComp;


// TimDat class :
// --------------

class CW_IMPORT_EXPORT _TimDat
{
private:

    double msecs;   // Number of milliseconds elapsed since 00:00:00, January 1, 1970.
                    // Note that FAT system do not accommodate the value in dates prior to January 1, 1980.

public:

    enum Kind           // Specifies whether a date-time data (year, month, day, weekday, hour, and minute)
        {               // is either in Coordinated Universal Time (UTC) or local time.
        kindUTC = 0,    // The date-time representation is based on UTC.
        kindLocal = 1   // The date-time representation is based on local time.
        };

// Constructors

    _TimDat ();                     // Constructs a _TimDat object with a zero (illegal) value.
                                    // You should initialize such object with valid _TimDat prior to use.

    _TimDat (const _OldTimDat &);   // Constructs a _TimDat object from an old _TimDat object.

    _TimDat (                       // Constructs a _TimDat object from the following components :
        Kind kind,                  // Date and time representation (UTC or local time).
        int nYear,                  // Year in the range 1980 to 2037.
        int nMonth,                 // Month in the range 1 through 12.
        int nDay,                   // Day of the month in the range 1 through 31.
        int nHour = 0,              // Hour in the range 0 through 23.
        int nMin  = 0,              // Minute in the range 0 through 59.
        int nSec  = 0,              // Second in the range 0 through 59.
        int nMSec = 0);             // Millisecond in the range 0 through 999.

    _TimDat (                       // Constructs a _TimDat object from the following components :
        Kind kind,                  // Date and time representation (UTC or local time).
        int nYear,                  // Year in the range 1980 to 2037.
        int nMonth,                 // Month in the range 1 through 12.
        int nDay,                   // Day of the month in the range 1 through 31.
        int nHour,                  // Hour in the range 0 through 23.
        double dMSec);              // Millisecond in a double range.

    _TimDat (                       // Constructs a _TimDat object from a MS-DOS date and time values.
        WORD wDosDate,
        WORD wDosTime);

    _TimDat (                       // Constructs a _TimDat object from a SYSTEMTIME structure.
        Kind kind,                  // Date and time representation (UTC or local time).
        const SYSTEMTIME & sysTime);

    _TimDat (                       // Constructs a _TimDat object from a FILETIME structure.
        const FILETIME & fileTime);

// Static member functions

    static _TimDat Null ();         // Returns a _TimDat object with a zero (illegal) value.

    static _TimDat Min ();          // Returns a _TimDat object with the minimum time and date
                                    // (00:00:00.000, January 1, 1980).

    static _TimDat Max ();          // Returns a _TimDat object with the maximum time and date
                                    // (23:59:59.999, December 31, 2037).

    static _TimDat GetCurrent ();   // Returns a _TimDat object that represents the current date and time.

    static BOOL IsBadDate (         // Test whether a date is valid or not.
        int nYear,                  // Year in the range 1980 to 2037.
        int nMonth,                 // Month in the range 1 through 12.
        int nDay);                  // Day of the month in the range 1 through 31.

    static BOOL IsBadTime (         // Test whether a time is valid or not.
        int nHour,                  // Hour in the range 0 through 23.
        int nMin,                   // Minute in the range 0 through 59.
        int nSec,                   // Second in the range 0 through 59.
        int nMSec = 0);             // Millisecond in the range 0 through 999.

// Conversion member functions

    BOOL GetAsSystemTime (
        Kind kind,                  // Date and time representation (UTC or local time).
        SYSTEMTIME & sysTime) const;

    BOOL GetAsFileTime (
        FILETIME & fileTime) const;

    _OldTimDat CvOld () const;      // Returns an old _TimDat object that corresponds to this _TimDat object.

    BOOL FormatString (             // Generates a formatted string that corresponds to this _TimDat object.
        Kind kind,                  // Date and time representation (UTC or local time).
        LPTSTR pszFormat) const;    // Formatted string.

    BOOL CvString (                 // Generates a formatted string that corresponds to this _TimDat object.
        LPTSTR pszFormat) const;    // Formatted string (in local time representation).

// Extraction member functions

    BOOL IsBad () const;            // Specifies whether this _TimDat object is valid or not.

    BOOL GetComponents (            // Returns components that corresponds to this _TimDat object.
        Kind kind,                  // Date and time representation (UTC or local time).
        _TimDatComp &tdc) const;

    int GetYear (                   // Returns the year in the range 1980 to 2037.
        Kind kind) const;           // Year representation (UTC or local time).

    int GetMonth (                  // Returns the month in the range 1 through 12 (1 = January).
        Kind kind) const;           // Month representation (UTC or local time).

    int GetDay (                    // Returns the day of the month in the range 1 through 31.
        Kind kind) const;           // Day representation (UTC or local time).

    int GetDayOfWeek (              // Returns the day of the week in the range 0 through 6 (0 = Sunday).
        Kind kind) const;           // Weekday representation (UTC or local time).

    int GetDayOfYear (              // Returns the day of the year in the range 1 through 366.
        Kind kind) const;           // Yearday representation (UTC or local time).

    int GetWeekOfYear (             // Returns the week of the year in the range 1 through 53.
        Kind kind) const;           // Yearweek representation (UTC or local time).

    int GetHour (                   // Returns the hour in the range 0 through 23.
        Kind kind) const;           // Hour representation (UTC or local time).

    int GetMinute (                 // Returns the minute in the range 0 through 59.
        Kind kind) const;           // Minute representation (UTC or local time).

    int GetSecond () const;         // Returns the second in the range 0 through 59.

    int GetMillisecond () const;    // Returns the millisecond in the range 0 through 999.

    long GetTotalDays () const;     // Returns the total number of complete days in this _TimDat object.
    long GetTotalHours () const;    // Returns the total number of complete hours in this _TimDat object.
    long GetTotalMinutes () const;  // Returns the total number of complete minutes in this _TimDat object.
    long GetTotalSeconds () const;  // Returns the total number of complete seconds in this _TimDat object.

    double GetTotalMilliseconds () const; // Returns the total number of complete milliseconds in this _TimDat object.

    BOOL IsLeapYear (               // Specifies whether the year is a leap year.
        Kind kind) const;           // Date representation (UTC or local time).

// Modification member functions

    BOOL SetDate (                  // Modifies the date components of this _TimDat object.
        Kind kind,                  // Date representation (UTC or local time).
        int nYear,                  // Year in the range 1980 to 2037.
        int nMonth,                 // Month in the range 1 through 12.
        int nDay);                  // Day of the month in the range 1 through 31.

    BOOL SetTime (                  // Modifies the time components of this _TimDat object.
        Kind kind,                  // Time representation (UTC or local time).
        int nHour,                  // Hour in the range 0 through 23.
        int nMin,                   // Minute in the range 0 through 59.
        int nSec,                   // Second in the range 0 through 59.
        int nMSec = 0);             // Millisecond in the range 0 through 999.

    BOOL SetTotalMilliseconds (     // Modifies the number of milliseconds elapsed since 00:00:00, January 1, 1970.
        double dMsec);              // Number of milliseconds.

// Comparison operators

    friend int operator == (const _TimDat &td1, const _TimDat &td2)
                           { return (td1.msecs == td2.msecs); }
    friend int operator != (const _TimDat &td1, const _TimDat &td2)
                           { return (td1.msecs != td2.msecs); }
    friend int operator <= (const _TimDat &td1, const _TimDat &td2)
                           { return (td1.msecs <= td2.msecs); }
    friend int operator >= (const _TimDat &td1, const _TimDat &td2)
                           { return (td1.msecs >= td2.msecs); }
    friend int operator <  (const _TimDat &td1, const _TimDat &td2)
                           { return (td1.msecs <  td2.msecs); }
    friend int operator >  (const _TimDat &td1, const _TimDat &td2)
                           { return (td1.msecs >  td2.msecs); }

// Assignment operators

    _TimDat & operator = (const _TimDat &td) { msecs  = td.msecs; return *this; }
    _TimDat & operator = (double d)         { msecs  = d;        return *this; }

    void operator += (double d) { msecs += d; }
    void operator -= (double d) { msecs -= d; }

// Arithmetic operators

    friend _TimDat operator + (const _TimDat &td, double d)
                             { _TimDat tdx; tdx.msecs = td.msecs + d; return tdx; }
    friend _TimDat operator + (double d, const _TimDat &td)
                             { _TimDat tdx; tdx.msecs = d + td.msecs; return tdx; }
    friend _TimDat operator - (const _TimDat &td, double d)
                             { _TimDat tdx; tdx.msecs = td.msecs - d; return tdx; }
    friend double operator - (const _TimDat &td1, const _TimDat &td2)
                             { return td1.msecs - td2.msecs; }

// Serialization operators

#ifdef __AFX_H__

    friend CArchive& operator << (CArchive& ar, const _TimDat& td) { ar << td.msecs; return ar; }
    friend CArchive& operator >> (CArchive& ar, _TimDat& td)       { ar >> td.msecs; return ar; }

#endif

//#MODIFJS
    void GetDatation (struct _CwDatation * pDatation) const;
    void GetUpdate (struct _CwUpdate * pUpdate) const;
//#ENDMODIFJS
};


// Global TimDat functions (which have TimDat member functions equivalents)
// ------------------------------------------------------------------------

_TimDat CW_IMPORT_EXPORT cwTiGetTd ();      // Returns a _TimDat object that represents the current time and date.

_TimDat CW_IMPORT_EXPORT cwTiGetTd (        // Returns a _TimDat object from the following components :
    _TimDat::Kind kind, // Time representation (UTC or local time).
    int Year,           // Year in the range 1980 to 2037.
    int Month,          // Month in the range 1 through 12.
    int Day,            // Day of the month in the range 1 through 31.
    int Hour = 0,       // Hour in the range 0 through 23.
    int Min  = 0,       // Minute in the range 0 through 59.
    int Sec  = 0,       // Second in the range 0 through 59.
    int MSec = 0);      // Millisecond in the range 0 through 999.

_TimDat CW_IMPORT_EXPORT cwTiGetTd (        // Returns a _TimDat object from a string in the following format : "YYMMDDhhmmsslll".
    _TimDat::Kind kind, // Time representation (UTC or local time).
    LPCTSTR pszDateTime);


#define _TimDatNULL _TimDat::Null()
#define _TimDatMIN  _TimDat::Min()
#define _TimDatMAX  _TimDat::Max()


#define TIMDAT_ONE_WEEK   (604800000.0)
#define TIMDAT_ONE_DAY    ( 86400000.0)
#define TIMDAT_ONE_HOUR   (  3600000.0)
#define TIMDAT_ONE_MINUTE (    60000.0)
#define TIMDAT_ONE_SECOND (     1000.0)


#endif  // _CWTIMDAT_H_
