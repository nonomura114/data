#ifndef _CWFRM_H_
#define _CWFRM_H_

#define CW_MODE_NONE          0x00
#define CW_MODE_CYCLIC_READ   0x01
#define CW_MODE_CYCLIC_WRITE  0x02
#define CW_MODE_UNSOLICITED   0x04

#define CW_READ_NONE	0x00
#define CW_READ_SYNC	0x01
#define CW_READ_ASYNC	0x02

#define CW_WRITE_NONE	0x00
#define CW_WRITE_SYNC	0x01
#define CW_WRITE_ASYNC	0x02

//************************************************
//**
//** _CwBaseFrame
//**
//************************************************

class CW_IMPORT_EXPORT _CwBaseFrame: public _CommunicationObject
{
	DECLARE_DYNAMIC( _CwBaseFrame)

	//***
	//*** Frame - Configuration
	//***

public:

	//#MODIFDL 04/03/98
	CW_BOOL     m_FirstCyclic;
	virtual CW_USHORT	Load() { return CW_OK;};

private:

	CW_ULONG    m_ulDataAddress;     // despag->padrmemap
	CW_USHORT   m_usDataType;        // despag->ptypdon
	CW_USHORT   m_usDataCodage;      // despag->pcodlig

	MSECS       m_msPeriod;          // despag->pcadence
	MSECS       m_msDefaultPeriod;
	MSECS       m_msCyclicStartTime;

	CW_USHORT   m_ReadConfig;
	CW_USHORT   m_WriteConfig;
	CW_USHORT   m_ConfigMode;

	_CwBaseLink *m_Link;

public:

	CW_BOOL	    GetIndexFromAddress( CW_ULONG ulAddress, CW_ULONG *ulIndex);
	CW_ULONG    GetDataAddress( void)  { return m_ulDataAddress; }
	CW_USHORT   GetDataType( void)     { return m_usDataType; }
	CW_USHORT   GetDataCodage( void)   { return m_usDataCodage; }

	void        SetDataAddress( CW_ULONG ulAddress);
	void        SetDataType( CW_USHORT usType);
	void        SetDataCodage( CW_USHORT usCodage);

	_CwBaseLink *GetLink( void)  { return m_Link; }
	_CwBaseData *GetData( void);

	CW_USHORT   GetConfigMode( void);
	CW_BOOL     IsCyclic( void);
	CW_BOOL     IsCyclicRead( void);
	CW_BOOL     IsWatchUnsolicited( void);

protected:

	virtual void      OnSetDataAddress( CW_ULONG ulAddress)     {}
	virtual void      OnSetDataType( CW_USHORT usType)          {}
	virtual void      OnSetDataCodage( CW_USHORT usDataCodage)  {}

	void        ResetMode( void);
	void        ResetCyclicMode( void);
	void        SetReadCyclicMode( void);
	void        SetWriteCyclicMode( void);
	void        SetUnsolicitedMode( void);
	void        ResetUnsolicitedMode( void);

	virtual void      OnResetCyclicMode( void)       {}
	virtual void      OnSetReadCyclicMode( void)     {}
	virtual void      OnSetWriteCyclicMode( void)    {}
	virtual void      OnSetUnsolicitedMode( void)    {}
	virtual void      OnResetUnsolicitedMode( void)  {}

	void        ResetReadConfig( void);
	void        SetSynchroReadEnabled( void);
	void        SetAsynchroReadEnabled( void);

	virtual void      OnResetReadConfig( void)         {}
	virtual void      OnSetSynchroReadEnabled( void)   {}
	virtual void      OnSetAsynchroReadEnabled( void)  {}

public:

	CW_USHORT   GetReadConfig( void);
	CW_BOOL     IsReadEnabled( void);
	CW_BOOL     IsSynchroReadEnabled( void);
	CW_BOOL     IsAsynchroReadEnabled( void);

protected:

	void        ResetWriteConfig( void);
	void        SetSynchroWriteEnabled( void);
	void        SetAsynchroWriteEnabled( void);

	virtual void      OnResetWriteConfig( void)           {}
	virtual void      OnSetSynchroWriteEnabled( void)     {}
	virtual void      OnSetAsynchroWriteEnabled( void)    {}

public:

	CW_USHORT   GetWriteConfig( void);
	CW_BOOL     IsWriteEnabled( void);
	CW_BOOL     IsSynchroWriteEnabled( void);
	CW_BOOL     IsAsynchroWriteEnabled( void);

	MSECS       GetCyclicPeriod( void);
	CW_USHORT   SetCyclicPeriod( MSECS msPeriod, CW_BOOL bInitialize = CW_FALSE);
	CW_USHORT   ResetCyclicPeriod( void);
	CW_BOOL     IsValidCyclicPeriod( MSECS msPeriod);
	CW_BOOL     IsCyclicTimeElapsed( void);

protected:

	virtual void OnSetCyclicPeriod( MSECS msPeriod, CW_BOOL bInitialize) {}

	void        StartCyclicTime( void);

	virtual void      ResetConfiguration( void);


	//***
	//*** Frame - States
	//***

private:

	CW_BOOL     m_bForceExeCyclic;	// For�age du Cyclic pour 1er raff.
	CW_BOOL     m_bSequencement;
	CW_BOOL     m_bPrior;
	CW_BOOL     m_bCyclicInTail;
	CW_BOOL     m_bCyclicAlreadyInTail;     //#MODIFDL 23/02/17
	CW_BOOL     m_bCyclicInProgress;
	CW_BOOL     m_bOneShotInTail;
	CW_BOOL     m_bOneShotInProgress;
	CW_BOOL     m_bSystemFlag;
	
protected:

	CW_BOOL     IsForceExeCyclic( void)    { return m_bForceExeCyclic; }
	void        SetForceExeCyclic( void)   { m_bForceExeCyclic = CW_TRUE; }
	void        ResetForceExeCyclic( void) { m_bForceExeCyclic = CW_FALSE; }


public:

	void        SetSystemFlag( void)    { m_bSystemFlag = CW_TRUE; }
	void        ResetSystemFlag( void)  { m_bSystemFlag = CW_FALSE; }

	void        SetSequencement( void);
	void        ResetSequencement( void);
	void        SetPrior( void);
	void        ResetPrior( void);
	void        SetCyclicInTail( void);
	void        ResetCyclicInTail( void);
	void        SetCyclicInProgress( void);
	void        ResetCyclicInProgress( void);
	void        SetOneShotInTail( void);
	void        ResetOneShotInTail( void);
	void        SetOneShotInProgress( void);
	void        ResetOneShotInProgress( void);

protected:

	virtual void      OnSetSequencement( void)         {}
	virtual void      OnResetSequencement( void)       {}
	virtual void      OnSetPrior( void)                {}
	virtual void      OnResetPrior( void)              {}
	virtual void      OnSetCyclicInTail( void)         {}
	virtual void      OnResetCyclicInTail( void)       {}
	virtual void      OnSetCyclicInProgress( void)     {}
	virtual void      OnResetCyclicInProgress( void)   {}
	virtual void      OnSetOneShotInTail( void)        {}
	virtual void      OnResetOneShotInTail( void)      {}
	virtual void      OnSetOneShotInProgress( void)    {}
	virtual void      OnResetOneShotInProgress( void)  {}
	
public:

	inline CW_BOOL     IsSequencement( void)           { return m_bSequencement; }
	inline CW_BOOL     IsPrior( void)                  { return m_bPrior; }
	inline CW_BOOL     IsCyclicInTail( void)           { return m_bCyclicInTail; }
	inline CW_BOOL     IsCyclicAlreadyInTail( void)    { return m_bCyclicAlreadyInTail; }
    inline void        SetCyclicAlreadyInTail( void)   { m_bCyclicAlreadyInTail = CW_TRUE; }
    inline void        ResetCyclicAlreadyInTail( void) { m_bCyclicAlreadyInTail = CW_FALSE; }
	inline CW_BOOL     IsCyclicInProgress( void)       { return m_bCyclicInProgress; }
	inline CW_BOOL     IsOneShotInTail( void)          { return m_bOneShotInTail; }
	inline CW_BOOL     IsOneShotInProgress( void)      { return m_bOneShotInProgress; }
	inline CW_BOOL     GetSystemFlag( void)            { return m_bSystemFlag; }

protected:

	void        ResetStates( void);


	//***
	//*** Frame - State Errors
	//***

private:

	CW_LONG     m_lCompState;

	CW_BOOL     m_bLastCmdFailed;
	CW_BOOL     m_bTransferError;
	CW_BOOL     m_bProtocolError;
	CW_BOOL     m_bCorrespondentError;
	CW_BOOL     m_bNetworkError;
	CW_BOOL     m_bTimeOutError;
	CW_BOOL     m_bOneShotFull;
	CW_BOOL     m_bCyclicFull;
	CW_BOOL     m_bPriorFull;

public:
	
	void        SetLastCmdFailed( void);
	void        ResetLastCmdFailed( void);

	void        SetCompState( CW_LONG lState);

protected:

	void        SetTransferError( void);
	void        ResetTransferError( void);
	void        SetProtocolError( void);
	void        ResetProtocolError( void);
	void        SetCorrespondentError( void);
	void        ResetCorrespondentError( void);
	void        SetNetworkError( void);
	void        ResetNetworkError( void);

public:

	void        SetTimeOutError( void);
	void        ResetTimeOutError( void);
	void        SetOneShotFull( void);
	void        ResetOneShotFull( void);
	void        SetCyclicFull( void);
	void        ResetCyclicFull( void);
	void        SetPriorFull( void);
	void        ResetPriorFull( void);

protected:

	virtual void      OnSetCompState( CW_LONG lState)   {}
	virtual void      OnSetLastCmdFailed( void)         {}
	virtual void      OnResetLastCmdFailed( void)       {}
	virtual void      OnSetTransferError( void)         {}
	virtual void      OnResetTransferError( void)       {}
	virtual void      OnSetProtocolError( void)         {}
	virtual void      OnResetProtocolError( void)       {}
	virtual void      OnSetCorrespondentError( void)    {}
	virtual void      OnResetCorrespondentError( void)  {}
	virtual void      OnSetNetworkError( void)          {}
	virtual void      OnResetNetworkError( void)        {}
	virtual void      OnSetTimeOutError( void)          {}
	virtual void      OnResetTimeOutError( void)        {}
	virtual void      OnSetOneShotFull( void)           {}
	virtual void      OnResetOneShotFull( void)         {}
	virtual void      OnSetCyclicFull( void)            {}
	virtual void      OnResetCyclicFull( void)          {}
	virtual void      OnSetPriorFull( void)             {}
	virtual void      OnResetPriorFull( void)           {}

public:

	CW_LONG     GetCompState( void)          { return m_lCompState; }
	CW_BOOL     IsLastCmdFailed( void)       { return m_bLastCmdFailed; }
	CW_BOOL     IsTransferError( void)       { return m_bTransferError; }
	CW_BOOL     IsProtocolError( void)       { return m_bProtocolError; }
	CW_BOOL     IsCorrespondentError( void)  { return m_bCorrespondentError; }
	CW_BOOL     IsNetworkError( void)        { return m_bNetworkError; }
	CW_BOOL     IsTimeOutError( void)        { return m_bTimeOutError; }
	CW_BOOL     IsOneShotFull( void)         { return m_bOneShotFull; }
	CW_BOOL     IsCyclicFull( void)          { return m_bCyclicFull; }
	CW_BOOL     IsPriorFull( void)           { return m_bPriorFull; }

	void        ResetStateErrors(BOOL bResetOutOfOrder = TRUE );//#MODIFFRM 02/07/04


	//***
	//*** Frame - Constructor & Destructor
	//***

public:

		_CwBaseFrame( void);
		virtual ~_CwBaseFrame( void);

	CW_USHORT   Initialize(
		CW_USHORT UserId,
		_CwBaseEqt *Owner,
		_AD *adFile);

	void        Terminate( void);

protected:

	virtual CW_USHORT BeforeInitialize( _AD *adFile)  { return CW_OK; }
	virtual CW_USHORT AfterInitialize( _AD *adFile)   { return CW_OK; }

	//***
	//*** Frame - Specific Constructor
	//***

	CW_USHORT         CreateLink( _AD *adFile);

	virtual _CwBaseLink *OnCreateLink( void);

public:

	void		RegistryLink( _CwBaseLink *Link);
	void		RegistryData( _CwBaseData *Data);

	void        UnregistryLink( _CwBaseLink *Link);
	void        UnregistryData( _CwBaseData *Data);

protected:

	virtual void      OnRegistryLink( _CwBaseLink *Link)    {}
	virtual void      OnRegistryData( _CwBaseData *Data)    {}

	virtual void      OnUnregistryLink( _CwBaseLink *Link)  {}
	virtual void      OnUnregistryData( _CwBaseData *Data)  {}

	//***
	//*** Frame - Management Routines
	//***

public:

	CW_USHORT   GetInfo( CW_LP_ACT_INFO lpInfo);
	CW_USHORT   GetStatus( CW_LP_ACT_STATUS lpStatus);
	CW_USHORT	GetReadWriteAudit( CW_READWRITE_AUDIT	&a_RWAudit);

protected:

	virtual void  OnGetInfo( CW_LP_ACT_INFO lpInfo)         {}
	virtual void  OnGetStatus( CW_LP_ACT_STATUS lpStatus)   {}

	CW_USHORT     IsCyclicReadyToBeActivate( CW_BOOL bFullStart, CW_BOOL bInconditionalStart);
	CW_USHORT     IsCyclicReadyToBeInactivate( void);
	CW_USHORT     IsWatchUnsolicitedReadyToBeActivate( CW_BOOL bFullStart);
	CW_USHORT     IsWatchUnsolicitedReadyToBeInactivate( void);

	void          SpecificStartCyclic( void);
	void          SpecificFullStartCyclic( void);
	void          SpecificStopCyclic( void);
	void          SpecificFullStopCyclic( void);
	void          SpecificStartWatchUnsolicited( void);
	void          SpecificStopWatchUnsolicited( void);

	CW_USHORT   ReadyToBeActivate( void);
	CW_USHORT   ReadyToBeInactivate( void);
	
	virtual CW_USHORT   StartCommand( CW_USHORT usMode);
	virtual CW_USHORT   StopCommand( CW_BOOL bInternalStop, CW_USHORT usMode);

public:
	CW_USHORT   AfterStopCommand(CW_BOOL bInternalStop) override; 

	virtual void   OnInitialize(_AD *adFile) {}
	virtual void   OnTerminate(void) {}

	virtual void  StartCyclicCommand( void)               {}
	virtual void  StopCyclicCommand( void);
	virtual void  StartWatchUnsolicitedCommand( void);
	virtual void  StopWatchUnsolicitedCommand( void)      {}

	void SendMessage(LPCTSTR szMessage);
	virtual void   OnReceiveMessage( LPCTSTR szMessage) {}
	
	//***
	//*** Frame- Specific Methods
	//***

protected:

	virtual void    ModifyConfigCommand(CW_LPC_CHAR szConfiguration);

	CW_USHORT   GetTransferMode( void);

	CW_USHORT   DetermineRWAccess(
		_AD *adFile,
		CW_USHORT usPos);

public:

	CW_USHORT   IsValidAction(
		CW_USHORT Origin,
		CW_USHORT Type,
		CW_USHORT Mode);

	void        SetValid( void);
	void        SetInvalid( _ProtError *pErr);

	virtual _ProtRet  Start_Async( _ProtStartFrameCmd *pStartFrameCmd)  { return PR_CMD_NOT_PROCESSED; }
	virtual _ProtRet  Stop_Async( _ProtStopFrameCmd *pStopFrameCmd)     { return PR_CMD_NOT_PROCESSED; }
	virtual _ProtRet  Read_Async( _ProtReadCmd *pReadCmd)               { return PR_CMD_NOT_PROCESSED; }
	virtual _ProtRet  Write_Async( _ProtWriteCmd *pWriteCmd)            { return PR_CMD_NOT_PROCESSED; }

	virtual void  AbortStartFrameCmd( _ProtStartFrameCmd *pStartFrameCmd)  {}
	virtual void  AbortStopFrameCmd( _ProtStopFrameCmd *pStopFrameCmd)     {}
	virtual void  AbortReadCmd( _ProtReadCmd *pReadCmd)                    {}
	virtual void  AbortWriteCmd( _ProtWriteCmd *pWriteCmd)                 {}

	//#MODIFJS 27/10/98 - Audit des temps de lecture

protected:

	MSECS m_msBeginRead;
	MSECS m_msBeginRead_Previous;

	CW_FLOAT m_fltMinReadTime;
	CW_FLOAT m_fltMaxReadTime;
	CW_FLOAT m_fltAverageReadTime;
	CW_FLOAT m_fltScheduleRead;

	CW_DWORD m_dwReadCpt;

public:

	void  statBeginRead( void);
	void  statEndRead( void);

	void  statWrite( CString &csBuffer);

	//#ENDMODIFJS 27/10/98 - Audit des temps de lecture
};

#endif // _CWFRM_H_