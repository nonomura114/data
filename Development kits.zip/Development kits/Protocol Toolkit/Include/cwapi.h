//*********************
//**
//**  cwapi.h
//**
//*********************

#ifndef _CWAPI_H_

	#define _CWAPI_H_

	#ifdef __cplusplus
	extern "C" {
	#endif


//--------------------------------------------------------------------------
	// Information
	CW_USHORT CW_IMPORT_EXPORT Cw_GetVersion(
		struct _CwVersion *pCwVersion);

	CW_USHORT CW_IMPORT_EXPORT Cw_GetProtocolVersion(
		CW_USHORT nBoard,
		CW_USHORT nNetwork,
		struct _CwVersion *pProtocolVersion);

//--------------------------------------------------------------------------
	// Flow control
	void CW_IMPORT_EXPORT CwOnSetXon( void);
	void CW_IMPORT_EXPORT CwOnSetXoff( void);

//--------------------------------------------------------------------------
	// Get Frame data type
		// CW_DATA_BIT      0 // Bit.
		// CW_DATA_BYTE     1 // Byte (8 bits).
		// CW_DATA_WORD     2 // Word (16 bits).
		// CW_DATA_REAL     3 // Real (32 bits).
		// CW_DATA_DWORD    4 // Double word (32 bits).
	CW_USHORT CW_IMPORT_EXPORT CwGetFrameDataType( CW_HANDLE hServerHandle);

//--------------------------------------------------------------------------
//; 1 Format des structures associ�es � l'enregistrement CW_STMFORMATDATATIME
//;   Cette enregistrement est utilis� par CIMWAY pour notifier les changements 
//;   de valeurs des items d'une m�me trame � ses clients.

//  typedef	CHAR			CW_STMFORMATDATATIME;
//  typedef	CW_STMFORMATDATATIME	*CW_LPSTMFORMATDATATIME;

//; 1.1 _CwFrameHeader
//;   Cette structure est situ�e au d�but de l'enregistrement CW_STMFORMATDATATIME.
//;   Elle est suivie par un tableau de _CwItemHeader

typedef struct
{
   CW_ULONG	ulSize;		// The total size in byte of the data stream
  				// CW_STMFORMATDATATIME
   CW_ULONG	ulNumberItem;	// The number of _CwItemHeader which follow.
				// This will vary depending on the number of 
				// values being reporting.
   CW_HANDLE	hServerFrame;	// The Server handle for the frame
   CW_HANDLE	hClientFrame;	// The client provided handle for the frame
   				// which data is being reporting. This allows
				// a single CallBack handler to identify which
				// of many possible frames are reporting data.
   CW_ULONG	ulTransactionID;// For normal subscription this is 0.
   				// For Async operation Refresh or Read this is the
				// transactionID returned by the method.
} _CwFrameHeader;

//; 1.2 _CwItemHeader
//;    Un tableau de cette structure apparait dans l'enregistrement 
//;    CW_STMFORMATDATATIME apr�s le _CwFrameHeader. Les valeurs des items 
//;    apparaissent apr�s ce tableau.

typedef struct
{
   CW_HANDLE	hClientItem;	// The client provided handle associated with 
   				// this Item.
   CW_ULONG	ulValueOffset;	// Offset in the data stream (the global
				// memory section) of the serialised data.
   _TimDat	tdTimeStamp;	// The time for the data.
   CW_USHORT	usQualityState; // The quality bits for the data.
} _CwItemHeader;

//; 1.3 _CwDataItem
//;   Un tableau de cette structure apparait dans l'enregistrement 
//;   CW_STMFORMATDATATIME apr�s le tableau de _CwItemHeader.
/*
//#MODIFJS 23/04/98
// Cette d�finition est d�sormais plac� dans le fichier CW_TYPES.H
typedef struct
{
   CW_ITEMTYPE	ItemType;	// Type
   CW_ULONG     ulSize;     // Taille en elt de ItemType
   union
   {
   	CW_BOOL		bVal;		// CW_TRUE, CW_FALSE
	CW_UCHAR	ucVal;		// Unsigned char (1 byte) 
	CW_CHAR		cVal;		// Signed char (1 byte) 
	CW_USHORT	uiVal;		// Unsigned short (2 bytes) 
	CW_SHORT	iVal;		// Signed short	(2 bytes) 
	CW_ULONG	ulVal;		// Unsigned long (4 bytes) 
	CW_LONG		lVal;		// Signed long (4 bytes)
	CW_UQINT    uqVal;      // Unsigned ultra long (9 bytes)
	CW_QINT     qVal;       // Signed ultra long (9 bytes)
	CW_FLOAT	fltVal;		// Reel simple pr�cision (4 bytes) 
	CW_DOUBLE	dblVal;		// Reel double pr�cision (8 bytes) 
	CW_CHAR		strVal;		// Chaine de caract�re termin�e par \0
	CW_DWORD 	dwRaw;    	// Valeur brute
   } CwValue;
} _CwDataItem;
*/

//--------------------------------------------------------------------------

//--------------------------- Items functions ---------------------------
// Cononical Item ID:
// Board.Network.Equipment.Frame.EltIndex
// Sample1: 1.MBP.EQT1.WORD2.3	Fourth word in frame "WORD2" of equipement
//				"EQT1" on the network "MBP" connected to the
//				board "1"
// Sample2: 1.MBP.EQT1.BIT2.4	Fifth bit in frame "BIT2" of equipement
//				"EQT1" on the network "MBP" connected to the
//				board "1"
//
// derived Item Format:	     		// A FINALISER
// String Item : size = 10
// Sample1: 1.MBP.EQT1.WORD2.3.10#8
// Sample2: 1.MBP.EQT1.BYTE2.3.10
// Bit in Word Item : 
// Sample1: 1.MBP.EQT1.WORD2.3:12#1
// Byte in Word Item : 
// Sample1: 1.MBP.EQT1.WORD2.3:1#8

#define CWITEMID_MAXSIZE 255

// This structure is use by CwGetItemServerAttributes
typedef	struct
{
	char        idItem[ CWITEMID_MAXSIZE+1];  // The unique identifier for this item
	CW_BOOL     bActive;                      // CW_TRUE if items are to be 
	                                          // activated, CW_FALSE if items are
	                                          // to be desactivated.
	CW_HANDLE   hServer;                      // The server handle used to 
	                                          // refer to this Item.
	CW_HANDLE   hClient;                      // The Client handle has associated 
	                                          // with this Item.
	CW_ULONG    ulAccessRights;               // Indicates if the item is read only, 
	                                          // write only or read/write
	CW_ITEMTYPE itCanonicalDataType;          // The native data type. The type 
	                                          // of data maintained within the server for
	                                          // this Item.
	CW_ITEMTYPE RequestDataType;              // The data type in which the item's value
	                                          // will be returned
} _CwItemAttributs;


// This structure is use by CwCreateItem
typedef struct
{
	CW_ID       idItem;              // The unique identifier for this item
	CW_BOOL     bActive;             // CW_TRUE if items are to be 
	                                 // activated, CW_FALSE if items are
	                                 // to be desactivated.
	CW_HANDLE   hClient;             // The Client handle has associated 
	                                 // with this Item.
	CW_ITEMTYPE RequestDataType;     // The data type in which the item's value
	                                 // will be returned

} _CwItemCreation;


//---------------------------
CW_USHORT CW_IMPORT_EXPORT  CwGetItemsAttributs(	// Get attributs of all Items of a Frame
	CW_HANDLE	hFrameServer,	// [in] Server Frame handle
 	CW_ULONG	*pulNumberItems,// [out] Number of Items in Frame
	_CwItemAttributs **ppItemAttributs);// [out] Array of Items Attributs.

//; Return Codes
//; CW_OK		The function was successful	
//; CW_FAIL		The function was unsuccessful
//; CW_INVALIDHANDLE	The server handle was invalid

//---------------------------
CW_USHORT CW_IMPORT_EXPORT CwSetItemsAttributs(	// Set attributs of Items of a Frame
	CW_HANDLE	hFrameServer,	// [in] Server Frame handle
 	CW_ULONG	ulNumberItems,	// [in] Number of Items in Frame
	_CwItemAttributs *pItemAttributs,// [in] Array of Items Attributs.
	CW_RESULT	*pErrors);	// [out] Array of Result.

//; Return Codes
//; CW_OK		The function was successful	
//; CW_PFAIL		The function was partially successful. See the pErrors
//;			to determine what happened
//; CW_FAIL		The function was unsuccessful
//; CW_INVALIDHANDLE	The frame server handle was invalid

//; pErrors Codes
//; CW_OK		The function was successful	
//; CW_INVALIDHANDLE	The item server handle was invalid
//; CW_INVALIDPARAMETER	One or more parameters are invalids

//---------------------------
CW_USHORT CW_IMPORT_EXPORT CwGetItemAttributsById(	// Get One Item attributs of a Frame
	CW_HANDLE	hFrameServer,	// [in] Server Frame handle
	CW_ULONG	ulNumberItems,	// [in] The number of Item to get attributs
	CW_ID		*idItem, 	// [in] Array of Item ID
	_CwItemAttributs **ppItemAttributs, // [out] Array of Items Attributs.
	CW_RESULT	*pErrors);	// [out] Array of Result.

//; Return Codes
//; CW_OK		The function was successful	
//; CW_PFAIL		The function was partially successful. See the pErrors
//;			to determine what happened
//; CW_FAIL		The function was unsuccessful
//; CW_INVALIDHANDLE	The frame server handle was invalid

//; pErrors Codes
//; CW_OK		The function was successful	
//; CW_INVALIDID	The item ID was invalid

//---------------------------
CW_USHORT CW_IMPORT_EXPORT CwSetActiveItemsState(	// Set Items active or inactive
	CW_HANDLE       hFrameServer,   // [in] Server Frame handle
	CW_ULONG	ulNumberItems,	// [in] Number of Item to be affected
	CW_HANDLE	*phServer,	// [in] Array of Server items handles.
					// These were returned from AddItem.
	CW_BOOL		bActive,	// [in] CW_TRUE if items are to be 
					// activated, CW_FALSE if items are
					// to be desactivated.
	CW_RESULT	*pErrors);	// [out] Array of Result. Indicates 
					// which Items were sucessfully affected

//---------------------------
//; Description
//;  Set One or more items in a frame to active or inactive. This controls 
//;  whether or not valid data can be obtain from CwRead fot thos Items 
//;  and whether or not they are included in advise subscription to the
//;  Frame.
//; Comments
//;  Deactivating items will not result in a callback (since by definition 
//;  callbacks do not occur for inactive items). Activating items will 
//;  result in a Advice callback at the next update period or immediately
//;  if items are valid in a cache.

//; Return Codes
//; CW_OK		The function was successful	
//; CW_PFAIL		The function was partially successful. See the pErrors
//;			to determine what happened
//; CW_FAIL		The function was unsuccessful
//; CW_INVALIDHANDLE	The frame server handle was invalid

//; pErrors Codes
//; CW_OK		The function was successful	
//; CW_INVALIDHANDLE	The item server handle was invalid

//--------------------------- Set Client Handle ---------------------------
CW_USHORT CW_IMPORT_EXPORT CwSetFrameClientHandle(	// Set Server Handle of frame
	CW_HANDLE	hServerFrame,	// [in] Server Handle of the Frame
	CW_HANDLE	hClientFrame); 	// [in] Client Handle of the Frame

//; Return Codes
//; CW_OK		The function was successful	
//; CW_FAIL		The function was unsuccessful
//; CW_INVALIDHANDLE	The frame server handle was invalid

//--------------------------- Get Server Handle ---------------------------

CW_USHORT CW_IMPORT_EXPORT CwGetServerHandle(	// Get Server Handle of the cimway object
	CW_ID		idOject, 	// [in] ID of the cimway object
	CW_LP_HANDLE	phServer);	// [out] Server Handle of the Frame

//; Return Codes
//; CW_OK		The function was successful	
//; CW_FAIL		The function was unsuccessful
//; CW_INVALIDIDHANDLE	The server ID was invalid

//---------------------------
CW_USHORT CW_IMPORT_EXPORT CwGetFrameServerHandle(	// Get Server Handle of the Frame
	CW_ID		idFrame,	// [in] ID of the Frame
	CW_LP_HANDLE	phServerLink);	// [out] Server Handle of the Frame

//; Return Codes
//; CW_OK		The function was successful	
//; CW_FAIL		The function was unsuccessful
//; CW_INVALIDIDHANDLE	The server ID was invalid

//---------------------------
CW_USHORT CW_IMPORT_EXPORT CwGetEqtServerHandle(	// Get Server Handle of the Equipement
	CW_ID		idEqt,		// [in] ID of the Equipement
	CW_LP_HANDLE	phServerEqt);	// [out] Server Handle of the Equipement

//; Return Codes
//; CW_OK		The function was successful	
//; CW_FAIL		The function was unsuccessful
//; CW_INVALIDIDHANDLE	The server ID was invalid

//---------------------------
CW_USHORT CW_IMPORT_EXPORT CwGetNetServerHandle(	// Get Server Handle of the Network
	CW_ID		idNet,		// [in] ID of the Network
	CW_LP_HANDLE	phServerNet);	// [out] Server Handle of the Network

//; Return Codes
//; CW_OK		The function was successful	
//; CW_FAIL		The function was unsuccessful
//; CW_INVALIDIDHANDLE	The server ID was invalid

//---------------------------
CW_USHORT CW_IMPORT_EXPORT CwIsNetworksProduct( 
            CW_BOOL & a_bIsNetworksProduct);	// [out] = CW_TRUE if at least one network is producted	else CW_FALSE

//; Return Codes
//; CW_ERR_PROTOCOL_NOT_INIT;              
//; CW_OK

//--------------------------------------------------------------------------


// Les CallBacks
	// CallBack for notify Items modifcation in a frame
	// or completion of ReadAsync or RefreshAsync command
typedef	CW_BOOL (CALLBACK *LPFN_CWACKWATCHITEM)(CW_LPSTMFORMATDATATIME);

	// CallBack of WriteAsync completion
typedef	CW_BOOL (CALLBACK *LPFN_CWACKWRITEASYNC)(CW_HANDLE hClient, CW_TRANSACTID tidWrite, CW_LP_ACT_STATUS pFrameState);

	// CallBack for notify modification of Frame Status
typedef	CW_BOOL (CALLBACK *LPFN_CWACKWATCHFRAMESTATE)(CW_HANDLE hClient, CW_LP_ACT_STATUS pFrameState);

	// CallBack for notify modification of Equipment Status
typedef	CW_BOOL (CALLBACK *LPFN_CWACKWATCHEQTSTATE)(CW_HANDLE hClient, CW_LP_EQT_STATUS pEqtState);

	// CallBack for notify modification of Network Status
typedef	CW_BOOL (CALLBACK *LPFN_CWACKWATCHNETSTATE)(CW_HANDLE hClient, CW_LP_NET_STATUS pNetState);

//#MODIFFRM 22/08/03
	// CallBack of WriteAsync completion
typedef	CW_BOOL (CALLBACK *LPFN_CWACKREADASYNC)(CW_ULONG ulRequestId, CW_LP_ACT_STATUS pFrameState);

	// CallBack of BrowseNetworkAsync completion
typedef	CW_BOOL(CALLBACK *LPFN_CWACKBROWSENETWORKASYNC)(CW_ULONG ulRequestId, LPCTSTR szResult);

// CallBack of BrowseNetworkDeviceAsync completion
typedef	CW_BOOL(CALLBACK *LPFN_CWACKBROWSENETWORKDEVICEASYNC)(CW_ULONG ulRequestId, LPCTSTR szResult);

// CallBack of BrowseDeviceAsync completion
typedef	CW_BOOL(CALLBACK *LPFN_CWACKBROWSEDEVICEASYNC)(CW_ULONG ulRequestId, LPCTSTR szResult);

//#ENDMODIFFRM 22/08/03
CW_USHORT CW_IMPORT_EXPORT CwAdvise(		// Create a connection between Cimway and Client
	LPFN_CWACKWATCHITEM					lpfnAckItem,		// [in] CallBack to notify item modification 
	LPFN_CWACKWATCHFRAMESTATE 			lpfnAckFrameState,	// [in] CallBack to notify state frame modification 
	LPFN_CWACKWATCHEQTSTATE 			lpfnAckEqtState,	// [in] CallBack to notify state eqt modification 
	LPFN_CWACKWATCHNETSTATE 			lpfnAckNetState,	// [in] CallBack to notify state network modification 
	LPFN_CWACKWRITEASYNC				lpfnAckWriteAsync,	// [in] CallBack to notify completed async write
	LPFN_CWACKREADASYNC					lpfnAckReadAsync,		// [in] CallBack to notify completed async read//#MODIFFRM 22/08/03
	LPFN_CWACKBROWSENETWORKASYNC		lpfnAckBrowseNetworkAsync,
	LPFN_CWACKBROWSENETWORKDEVICEASYNC	lpfnAckBrowseNetworkDeviceAsync,
	LPFN_CWACKBROWSEDEVICEASYNC			lpfnAckBrowseDeviceAsync);
	
CW_USHORT CW_IMPORT_EXPORT CwUnAdvise( void);	// Terminate the connections between Cimway and Client

//; Return Codes
//; CW_OK		The function was successful	
//; CW_FAIL		The function was unsuccessful

// Watch Status of Frame
// ---------------------
      
CW_USHORT CW_IMPORT_EXPORT CwStartWatchFrameState(	// Start Watch Status of the Frame
	CW_HANDLE	hServerFrame,	// [in] Server Frame Handle 
	CW_HANDLE	hClientFrame,	// [in] 	
	CW_TRANSACTID	*ptidState);	// [out] Place to return a Server 
					// generated transaction ID.
					// Unique by server handle frame
//; Return Codes
//; CW_OK		The function was successful	
//; CW_FAIL		The function was unsuccessful
//; CW_INVALIDHANDLE	The frame server handle was invalid

CW_USHORT CW_IMPORT_EXPORT CwStopWatchFrameState(	// Stop Watch Status of the frame
	CW_HANDLE	hServerFrame,	// [in] Server Frame Handle 
	CW_TRANSACTID	tidState);	// [in] Transaction ID

//; Return Codes
//; CW_OK		The function is successful	
//; CW_FAIL		The function is unsuccessful
//; CW_INVALIDHANDLE	The frame server handle is invalid
//; CW_INVALIDTID	The transaction ID is invalid

// Watch Status of Equipment
// -------------------------

CW_USHORT CW_IMPORT_EXPORT CwStartWatchEqtState(	// Start Watch Status of the Equipment
	CW_HANDLE	hServerEqt,	// [in] Server Equipement Handle 
	CW_HANDLE	hClientEqt,	// [in] 	
	CW_TRANSACTID	*ptidState);	// [out] Place to return a Server 
					// generated transaction ID.
					// Unique by server handle eqt

//; Return Codes
//; CW_OK		The function is successful	
//; CW_FAIL		The function is unsuccessful
//; CW_INVALIDHANDLE	The frame server handle is invalid

CW_USHORT CW_IMPORT_EXPORT CwStopWatchEqtState(	// Start Watch Status of the Equipement
	CW_HANDLE	hServerEqt,	// [in] Server Eqt Handle 
	CW_TRANSACTID	tidState);	// [in] Transaction ID

//; Return Codes
//; CW_OK		The function is successful	
//; CW_FAIL		The function is unsuccessful
//; CW_INVALIDHANDLE	The frame server handle is invalid
//; CW_INVALIDTID	The transaction ID is invalid

// Watch Status of Network
// -----------------------

CW_USHORT CW_IMPORT_EXPORT CwStartWatchNetState(	// Start Watch Status of the Network
	CW_HANDLE	hServerNet,	// [in] Server Network Handle 
	CW_HANDLE	hClientNet,	// [in] 	
	CW_TRANSACTID	*ptidState);	// [out] Place to return a Server 
					// generated transaction ID.
					// Unique by server handle net.

//; Return Codes
//; CW_OK		The function is successful	
//; CW_FAIL		The function is unsuccessful
//; CW_INVALIDHANDLE	The frame server handle is invalid

CW_USHORT CW_IMPORT_EXPORT CwStopWatchNetState(	// Stop Watch Status of the Network
	CW_HANDLE	hServerNet,	// [in] Server Net. Handle
	CW_TRANSACTID	tidState);	// [in] Transaction ID

//; Return Codes
//; CW_OK		The function is successful	
//; CW_FAIL		The function is unsuccessful
//; CW_INVALIDHANDLE	The frame server handle is invalid
//; CW_INVALIDTID	The transaction ID is invalid


// Write One or more items in a frame
// ----------------------------------

class CTransaction
{
public:
	HANDLE			m_hEndEvent;
	CW_ACT_STATUS	m_FrameStatus;
	BOOL			m_bEqtRequest;
	virtual ~CTransaction() {};
};

struct	_CwWriteAsyncParamEx
{
   CW_HANDLE		hServerFrame;	// [in] Serveur Handle of the frame
   CW_USHORT		ActionCode;	// [in] Parameter
   CW_ULONG			ulStartPosition;// [in] Position in the array of the first Item.
   CW_ULONG		ulNumberItems;	// [in] Number of Item to be written
   CW_HANDLE		hClient;	// [in] Client Handle 
};

CW_USHORT CW_IMPORT_EXPORT CwPartWriteAsyncEx(		// Write one or more items in a frame
	   _CwWriteAsyncParamEx	*pWriteParam,	// [in] 
	   CW_TRANSACTID	*ptidWrite); 	// [out] Place to return 
 	   				     	// a Server generated 
					     	// transaction ID.

//; Return Codes
//; CW_OK		The function is successful	
//; CW_FAIL		The function is unsuccessful
//; CW_INVALIDHANDLE	The frame server handle is invalid

//---------------------------


// Create user items on a frame
// ----------------------------

CW_USHORT CW_IMPORT_EXPORT CwCreateItems(     // Create User Item of a Frame
	CW_HANDLE        hFrameServer,           // [in] Server Frame handle
	CW_ULONG         ulNumberItems,          // [in] The number of Item to create
	_CwItemCreation  *pItemCreation,         // [in] Array of Item creation attributes
	_CwItemAttributs **ppItemAttributs,      // [out] Array of Items Attributs.
	CW_RESULT        *pErrors);              // [out] Array of Result.

//; Return Codes
//; CW_OK             The function was successful	
//; CW_PFAIL          The function was partially successful. See the pErrors
//;                   to determine what happened
//; CW_FAIL           The function was unsuccessful
//; CW_INVALIDHANDLE  The frame server handle was invalid

//; pErrors Codes
//; CW_OK             The function was successful	
//; CW_INVALIDID      The item ID was invalid

//---------------------------

	#ifdef __cplusplus
	}
	#endif

CW_USHORT CW_IMPORT_EXPORT  CwReleaseMemoryGetItemsAttributs(_CwItemAttributs **ppItemAttributs);
CW_USHORT CW_IMPORT_EXPORT  CwReleaseMemoryCreateItems(_CwItemAttributs **ppItemAttributs, int itemAttributesCount);

#endif /* _CWAPI_H_ */

