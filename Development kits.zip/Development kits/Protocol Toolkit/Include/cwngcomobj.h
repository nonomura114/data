#ifndef _CWNGCOMOBJ_H_
#define _CWNGCOMOBJ_H_

//************************************************
//**
//** _CwNGNetwork
//**
//************************************************

class CW_IMPORT_EXPORT _CwNGNetwork: public _CwBaseNetwork
{
	DECLARE_DYNAMIC( _CwNGNetwork)

protected:
	TYPE_CreateProtNetwork	m_CreateProtNetwork;
	TYPE_CreateProtEqt		m_CreateProtEqt;
	TYPE_CreateProtFrame	m_CreateProtFrame;

	CW_USHORT		CreateProtNetwork( void);

	_ProtNetwork	*m_ProtNetwork;

public:
	_ProtEqt		*CreateProtEqt( CW_USHORT usType);
	_ProtFrame		*CreateProtFrame(
		CW_USHORT   usProtocolDataType,
		CW_USHORT   usCwDataType);

	_ProtNetwork	*GetProtNetwork( void);

protected:
					_CwNGNetwork( void);
					virtual ~_CwNGNetwork( void);

	CW_USHORT		AfterInitialize( _AD *adFile);
	CW_USHORT		BeforeInitialize( _AD *adFile);
	CW_BOOL			OnLoadProtocDLL( void);

	virtual void    OnModifyConfig(CW_LPC_CHAR szConfiguration);
	
	virtual void	ControlCommandInProgress( void);

public:

	_ProtRet		Start_Async( _ProtStartNetworkCmd *pStartNetworkCmd);
	_ProtRet		Stop_Async( _ProtStopNetworkCmd *pStopNetworkCmd);
	_ProtRet		CyclicScan_Async( _ProtCyclicScanCmd *pCyclicScanCmd);
	_ProtRet		Browse_Async(_ProtBrowseNetworkCmd *pBrowseNetworkCmd);
	_ProtRet		BrowseNetworkDevice_Async(_ProtBrowseNetworkDeviceCmd *pBrowseDeviceCmd);

	void            OnInitialize( _AD *adFile);
	void			OnTerminate( void);

	void			AbortStartNetworkCmd(_ProtStartNetworkCmd *pStartNetworkCmd);
	void			AbortStopNetworkCmd(_ProtStopNetworkCmd *pStopNetworkCmd);
	void			AbortCyclicScanCmd(_ProtCyclicScanCmd *pCyclicScanCmd);
	void			AbortBrowseNetworkCmd(_ProtBrowseNetworkCmd *pBrowseCmd);


	virtual CW_USHORT GetFluxManagement( void);


protected:

	void   StartCyclicCommand( void);
	void   StopCyclicCommand( void);

	void   StartWatchUnsolicitedCommand( void);
	void   StopWatchUnsolicitedCommand( void);

	void   OnReceiveMessage( LPCTSTR szMessage);

	//**
	//** User Attributes
	//**

private:

	void          UserAttributes_Extract(
		_AD              *adFile);
};



//************************************************
//**
//** _CwNGEqt
//**
//************************************************

class CW_IMPORT_EXPORT _CwNGEqt: public _CwBaseEqt
{
	DECLARE_DYNAMIC( _CwNGEqt)

protected:

	_ProtEqt    *m_ProtEqt;

		_CwNGEqt( void);
		virtual ~_CwNGEqt( void);

	CW_USHORT		AfterInitialize( _AD *adFile);
	CW_USHORT		BeforeInitialize( _AD *adFile);

	virtual void    OnModifyConfig(CW_LPC_CHAR szConfiguration);
	//#MODIFFRM 07/12/00
	virtual void    OnModifyConfigEx(CW_USHORT pAddress, CW_LPC_CHAR lpszConfigBuffer,CW_USHORT pParametersCounter);
	//#ENDMODIFFRM 07/12/00
	//#MODIFFRM 30/09/02
	virtual void    OnModifyPhoneNumber(CString strPhoneNumber);
	virtual void    OnModifyMaxConnectionDuration(CW_USHORT usMaxConnectionDuration);
	//#ENDMODIFFRM 30/09/02
	
	virtual void	ControlCommandInProgress( void);

public:

	void        OnInitialize( _AD *adFile);
	void		OnTerminate( void);

	_ProtRet	Start_Async( _ProtStartEqtCmd *pStartEqtCmd);
	_ProtRet    Stop_Async( _ProtStopEqtCmd *pStopEqtCmd);
	_ProtRet	BrowseDevice_Async(_ProtBrowseEqtCmd *pBrowseEqtCmd);

	void        AbortStartEqtCmd( _ProtStartEqtCmd *pStartEqtCmd);
	void        AbortStopEqtCmd( _ProtStopEqtCmd *pStopEqtCmd);

protected:

	void        StartCyclicCommand( void);
	void        StopCyclicCommand( void);

	void        StartWatchUnsolicitedCommand( void);
	void        StopWatchUnsolicitedCommand( void);

	void        OnReceiveMessage( LPCTSTR szMessage);

	CW_USHORT   CreateProtEqt( void);

public:

	_ProtFrame  *CreateProtFrame(
		CW_USHORT   usProtocolDataType,
		CW_USHORT   usCwDataType);

	_ProtEqt    *GetProtEqt( void);

	//**
	//** User Attributes
	//**

private:

	void          UserAttributes_Extract(
		_AD              *adFile);
};



//************************************************
//**
//** _CwNGFrame
//**
//************************************************

class CW_IMPORT_EXPORT _CwNGFrame: public _CwBaseFrame
{
	DECLARE_DYNAMIC( _CwNGFrame)

protected:

	_ProtFrame *m_ProtFrame;

		_CwNGFrame( void);
		virtual ~_CwNGFrame( void);

	CW_USHORT  AfterInitialize( _AD *adFile);
	CW_USHORT  BeforeInitialize( _AD *adFile);

public:

	void       OnInitialize( _AD *adFile);
	void	   OnTerminate( void);

	virtual		CW_USHORT Load();


	_ProtRet   Start_Async( _ProtStartFrameCmd *pStartFrameCmd);
	_ProtRet   Stop_Async( _ProtStopFrameCmd *pStopFrameCmd);
	_ProtRet   Read_Async( _ProtReadCmd *pReadcmd);
	_ProtRet   Write_Async( _ProtWriteCmd *pWriteCmd);

	void       AbortStartFrameCmd( _ProtStartFrameCmd *pStartFrameCmd);
	void       AbortStopFrameCmd( _ProtStopFrameCmd *pStopFrameCmd);
	void       AbortReadCmd( _ProtReadCmd *pReadCmd);
	void       AbortWriteCmd( _ProtWriteCmd *pWriteCmd);

protected:

	void       StartCyclicCommand( void);
	void       StopCyclicCommand( void);
	void       StartWatchUnsolicitedCommand( void);
	void       StopWatchUnsolicitedCommand( void);

	void       OnReceiveMessage( LPCTSTR szMessage);

	void       OnSetCyclicPeriod( MSECS msPeriod, CW_BOOL bInitialize);
	void       OnModifyConfig(CW_LPC_CHAR szConfiguration);
	void       ModifyProtocolCyclicPeriod(MSECS msPeriod);

	CW_USHORT  CreateProtFrame( _AD *adFile);

public:

	_ProtFrame *GetProtFrame( void);

	//**
	//** User Attributes
	//**

private:

	void          UserAttributes_Extract(
		_AD              *adFile);
};

#endif // _CWNGCOMOBJ_H_