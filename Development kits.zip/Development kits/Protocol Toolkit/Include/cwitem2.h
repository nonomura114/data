

#ifndef _CWITEM2_H_

	#define _CWITEM2_H_

class _CwItemWatch;
class _CwUserWatch;

class _CwBaseItem: public CObject
{
protected:

	_CwBaseData         *m_pOwner;            // Objet Data proprietaire

	_CwItemStatus       m_Status;
	_TimDat             m_HDate;

	CW_HANDLE           m_hClient;
	CW_ITEMTYPE         m_RequestedDataType;

	CW_BOOL             m_bActive;

protected:

	CW_BOOL             Initialize(
		_CwBaseData     *pOwner);

public:

	_CwBaseData         *GetOwner( void);
	virtual CW_LP_CHAR  GetId( void);
	CW_HANDLE           GetServerHandle( void);
	
	CW_HANDLE           GetClientHandle( void);
	void                SetClientHandle( CW_HANDLE hClient);

	CW_ITEMTYPE         GetRequestDataType( void);
	void                SetRequestDataType( CW_ITEMTYPE RequestDataType);

	CW_BOOL             GetActive( void);
	void                SetActive( CW_BOOL bActive);
	virtual void        OnSetActive( void) = 0;
	virtual void        OnSetInactive( void) = 0;

	CW_BOOL             IsUpdate( void);
	CW_BOOL             IsRefresh( void);
	void                ResetUpdate( void);
	//#MODIFJS 19/11/98 - Forcer un rafraichissement apres StopCyclic ou StopWatchUnsolicited
	void                ForceRefresh( void);

	virtual CW_ITEMTYPE GetType( void) = 0;

public:

		_CwBaseItem( void);
		virtual ~_CwBaseItem( void);

protected:

	virtual void        OnSetItemInit( void);

	virtual _eDataUpdate  TestAndSet(
		_CwItemValue    *itNewValue,
		CW_LP_VOID      lpvTable,
		CW_BOOL         bWithoutTest);

	virtual void        OnNotifyItemHDateChange(
		_CwItemDataAttributs  *pAttributs);

	virtual CW_BOOL     OnNotify(
		_CwItemDataAttributs  *pAttributs);

	virtual CW_BOOL     OnNotifyNoneAccessible(
		_TimDat               td);

public:

	CW_USHORT           Notify(
		_CwItemDataAttributs  *pAttributs,
		CW_LP_VOID            lpvTable);

	CW_USHORT           NotifyNoneAccessible(
		_TimDat               td);

	void                RegistryForWatchCallBack(
		void);

	virtual CW_ULONG    UpdateDataItem(
		_CwDataItem     *pDataItem) = 0;

	virtual void        UpdateStatusItem(
	    void);
};


class _CwItemWatch;

typedef struct
{
	_CwItemWatch *pWatch;
	CW_HANDLE    hWatchHandle;

} _CwCanonicalWatchElt;

class _CwCanonicalItem: public _CwBaseItem
{
protected:

	_CwItemValue      m_Value;

	CW_ULONG          m_ulItemIndex; // Index de la donnee dans le type 
	                                 // de la trame
	_LinkedList       *m_llUserWatch;

	void              OnSetActive( void);
	void              OnSetInactive( void);

protected:

	void              OnSetItemInit( void);

	_eDataUpdate      TestAndSet(
		_CwItemValue    *itNewValue,
		CW_LP_VOID      lpvTable,
		CW_BOOL         bWithoutTest);

	void              OnNotifyItemHDateChange(
		_CwItemDataAttributs  *pAttributs);

	CW_BOOL           OnNotify(
		_CwItemDataAttributs  *pAttributs);

	CW_BOOL           OnNotifyNoneAccessible(
		_TimDat               td);

public:

	CW_BOOL       Initialize(
		_CwBaseData   *pOwner,
		CW_ULONG      ulIndex);

	void          GetId( char idItem[ CWITEMID_MAXSIZE+1]);
	CW_ITEMTYPE   GetType( void);

		_CwCanonicalItem( void);
		virtual ~_CwCanonicalItem( void);

	CW_ULONG              UpdateDataItem(
		_CwDataItem    *pDataItem);

	void                  AddWatch(
		_CwItemWatch   *pWatch,
		CW_HANDLE      hWatchHandle);

	void                  RemoveWatch(
		_CwItemWatch   *pWatch);
};


typedef struct
{
	CW_UCHAR             ucSubMotifPosition;
	CW_UCHAR             ucNbEltMotif;
	CW_LP_UCHAR          pucEltMotif;
} _sUserItemSubMotif;

typedef struct
{
	CW_UCHAR             ucNbSubMotif;
	_sUserItemSubMotif   *psSubMotif;
} _sUserItemMotif;

typedef struct
{
	CW_ULONG             ulPosition;
	CW_ULONG             ulPositionMultiplier;
	CW_ULONG             ulSize;
	CW_UCHAR             ucSizeMultiplier;
	CW_UCHAR             ucFormat;
	_sUserItemMotif      *psMotif;
} _sInitUserItem;


class _CwUserWatch;

class _CwUserItem: public _CwBaseItem
{
protected:

	_CwDataItem     *m_Value;
	CW_ULONG        m_ulDataItemSize;
	CW_LP_CHAR      m_lpszIdBuffer;
	CW_BOOL         m_bRegisteredForCallBack;
	_CwUserWatch    *m_pUserWatch;

	void            OnSetActive( void);
	void            OnSetInactive( void);

	CW_BOOL         OnNotify(
		_CwItemDataAttributs  *pAttributs);

	CW_BOOL         OnNotifyNoneAccessible(
		_TimDat        td);

	_eDataUpdate    TestAndSet(
		_CwItemValue    *itNewValue,
		CW_LP_VOID      lpvUserWatch,
		CW_BOOL         bWithoutTest);

	CW_BOOL         InitializeUserAccess(
		_sInitUserItem *psInitUserItem);
	CW_BOOL         InitializeUserBoolAccess(
		_sInitUserItem *psInitUserItem);
	CW_BOOL         InitializeUserUnsignedAccess(
		_sInitUserItem *psInitUserItem);
	CW_BOOL         InitializeUserSignedAccess(
		_sInitUserItem *psInitUserItem);
	CW_BOOL         InitializeUserRealAccess(
		_sInitUserItem *psInitUserItem);
	CW_BOOL         InitializeUserCharAccess(
		_sInitUserItem *psInitUserItem);
	
	CW_BOOL         InitializeUserWatch(
		_sInitUserItem *psInitUserItem);

	CW_BOOL         BuildId(
		CW_LP_CHAR     lpszUserItemDescriptor,
		_sInitUserItem *psInitUserItem);

	CW_BOOL         BuildMotif(
		CW_LP_CHAR     lpszMotifDescriptor,
		_sInitUserItem *psInitUserItem);

public:

	CW_BOOL         Initialize(
		_CwBaseData    *pOwner,
		CW_LP_CHAR     lpszUserItemDescriptor);

	void            GetId( char idItem[ CWITEMID_MAXSIZE+1]);
	CW_ITEMTYPE     GetType( void);

		_CwUserItem( void);
		~_CwUserItem( void);

	CW_ULONG        UpdateDataItem(
		_CwDataItem    *pDataItem);

	void            UpdateStatusItem(
	    void);
};


class _CwItemWatch: public CObject
{
public:

	virtual ~_CwItemWatch(void);

	virtual void      Notify(
		_CwItemDataAttributs *pAttributs,
		CW_HANDLE            hWatchHandle) = 0;

	virtual void      NotifyNoneAccessible(
		_TimDat              td,
		CW_HANDLE            hWatchHandle) = 0;
};


typedef struct
{
	CW_ULONG  ulCanonicalIndex;
	CW_UCHAR  ucCanonicalIndexComp_Begin;
	CW_UCHAR  ucCanonicalIndexComp_End;
	CW_UCHAR  ucCanonicalEltSize;
	CW_ULONG  ulUserIndex;
	CW_UCHAR  ucUserIndexComp_Begin;
	CW_UCHAR  ucUserIndexComp_End;
	CW_UCHAR  ucUserEltSize;

} _sAddUserWatch;


class _CwUserWatchElt: public _EltSingleList
{
public:

	_sAddUserWatch            m_sAddUserWatch;

		_CwUserWatchElt(
			_sAddUserWatch    *psAddUserWatch);
};


class _CwUserWatch: public _CwItemWatch
{
protected:

	_CwUserItem       *m_pUserItem;
	_LinkSingleListS  *m_llUserWatch;
	
	CW_ULONG          m_ulNbCanonicalWatch;
	_sAddUserWatch    *m_pCanonicalWatch;
//	void              *m_pCanonicalWatch;

public:

	_CwUserWatch(
		_CwUserItem     *pUserItem);
	virtual ~_CwUserWatch(void);

	void          Add(
		_sAddUserWatch  *psAddUserWatch);

	void          Consolidate(
		void);

protected:

	virtual void      *AllocCanonicalWatch(
		CW_ULONG             ulSize);

	virtual void      ConsolidateWatchElt(
		CW_ULONG             ulCanonicalWatchIndex,
		_sAddUserWatch       *psAddUserWatch);

public:

	virtual void      Notify(
		_CwItemDataAttributs *pAttributs,
		CW_HANDLE            hWatchHandle);

	virtual void      NotifyNoneAccessible(
		_TimDat              td,
		CW_HANDLE            hWatchHandle);
};

#endif // _CWITEM2_H_

