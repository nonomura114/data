
//**
//** cwtimer.h
//**
//** Interface du thread Timer de Cimway
//**

#ifndef _CWTIMER_H_
#define _CWTIMER_H_

class _Cimway;
class _CwBaseNetwork;

class _CwThreadTimer: public _CwThread
{
private:

	#define TIMER_DEFAULT_ACTIVATION_PERIOD 50L

	_CwBaseNetwork	*m_Network;
	CW_ULONG		m_ulActivationPeriod;

public:

	//
	//	Constructeur / destructeur
	//
	_CwThreadTimer(
		_CwBaseNetwork	*pNetwork,
		CString     &csThreadName,
		CW_ULONG	ulActivationPeriod = TIMER_DEFAULT_ACTIVATION_PERIOD,
		CW_ULONG	ulWaitStart = DEFAULT_WAIT_START,
		CW_ULONG	ulWaitStop = DEFAULT_WAIT_STOP);
	virtual ~_CwThreadTimer( void);

	CW_BOOL			Start( void);

	virtual DWORD	Run( void);
	virtual void	SpecificRun( CW_ULONG ulEvent);

	CW_ULONG		GetActivationPeriod( void);
};

#endif	// _CWTIMER_H_
