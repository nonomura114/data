//
//
//	CWLLIST.H
//	---------
//
// Definition des classes liees aux listes chainees :
// - _EltSingleList
// - _LinkSingleList
// - _LinkSingleListS
//
// La classe _EltSingleList definit un element de liste chainee. Elle s'utilise
// par heritage et permet d'inclure dans l'objet herite les informations
// de chainage.
//
// La classe _LinkSingleList definit une liste d'elements _EltSingleList. La limite
// physique d'une liste est de sizeof( ULONG) elements mais l'utilisateur peut
// restreindre ce nombre (parametre du constructeur).



#ifndef _CWLLIST_H_
#define _CWLLIST_H_

// _EltSingleList : Element d'une liste chainee
// -------------------------------------

class _LinkSingleList;		// declaration prealable
class _LinkSingleListS;

class CW_IMPORT_EXPORT _EltSingleList: public CObject
{
	DECLARE_DYNAMIC( _EltSingleList)

	friend class _LinkSingleList;
	friend class _LinkSingleListS;

private:
	_LinkSingleList	*m_plist;    // pointeur sur la liste contenant l'element
	_EltSingleList  *m_previous; // element precedent dans la liste
	_EltSingleList  *m_next;     // element suivant dans la liste
	short           m_type ;     // reserve ici

public:

	_EltSingleList();
	virtual ~_EltSingleList();

	void *operator new( size_t);
	void operator delete( void *);
};


// _LinkSingleList : Liste Chainee
// -------------------------------

class CW_IMPORT_EXPORT _LinkSingleList: public CObject
{
	DECLARE_DYNAMIC( _LinkSingleList)

public:

	_EltSingleList *m_pfirst;          // pointeur sur le premier element

private:

	_EltSingleList *m_plast;           // pointeur sur le dernier element
	CW_ULONG       m_nbmax;            // nombre d'elts max
	CW_ULONG       m_nbelt;            // nombre d'elts

public:
		_LinkSingleList(               // construteur
			CW_ULONG maxelt = 32767);  // nombre max d'elements

		virtual ~_LinkSingleList( void);       // destructeur

	CW_ULONG GetNb( void);             // obtention du nombre d'elements
	_EltSingleList *GetFirst( void);   // obtention du premier element
	_EltSingleList *GetLast( void);    // obtention du dernier element

	_EltSingleList *GetNext(           // obtention de l'element suivant
		_EltSingleList *eltref);       // element de reference
	_EltSingleList *GetPrev(           // obtention de l'element precedent
		_EltSingleList *eltref);       // element reference

	CW_USHORT LinkBegin(               // chaine un element en debut de liste
		_EltSingleList *elt);          // element a chainer
	CW_USHORT LinkEnd(                 // chaine un element en fin de liste
		_EltSingleList *elt);          // element a chainer
	
	CW_USHORT LinkBefore(              // chaine un element avant un autre
		_EltSingleList *elt,           // element a chainer
		_EltSingleList *eltref);       // element de reference
	CW_USHORT LinkAfter(               // chaine un element apr�s un autre
		_EltSingleList *elt,           // element a chainer
		_EltSingleList *eltref);       // element de reference

	_EltSingleList *UnlinkFirst( void);// dechaine le premier element
	_EltSingleList *UnlinkLast( void); // dechaine le dernier element

	CW_USHORT Unlink(                  // dechaine un element
		_EltSingleList *elt);          // element a dechainer

	void Purge();                      // dechaine tous les elements

	CW_BOOL IsInList(                  // teste l'appartenance a une liste
		_EltSingleList * elt);         // element a tester
};


class CW_IMPORT_EXPORT _LinkSingleListS: public CObject
{
	DECLARE_DYNAMIC( _LinkSingleListS)

public:

	_EltSingleList  *m_pfirst;         // pointeur sur le premier element

public:
		_LinkSingleListS( void);       // contructeur
		virtual ~_LinkSingleListS( void);      // destructeur

	CW_ULONG GetNb( void);             // obtention du nombre d'elements
	
	_EltSingleList *GetFirst( void);   // obtention du premier element
	_EltSingleList *GetLast(void);     // obtention du dernier element

	_EltSingleList *GetNext(           // obtention de l'element suivant
		_EltSingleList *eltref);       // element de reference
	_EltSingleList *GetPrev(           // obtention de l'element precedent
		_EltSingleList *eltref);       // element reference
	
	CW_USHORT LinkBegin(               // chaine un element en debut de liste
		_EltSingleList *elt);          // element a chainer
	CW_USHORT LinkEnd(                 // chaine un element en fin de liste
		_EltSingleList *elt);          // element a chainer
	
	CW_USHORT	LinkBefore(            // chaine un element avant un autre
		_EltSingleList *elt,           // element a chainer
		_EltSingleList *eltref);       // element de reference
	CW_USHORT	LinkAfter(             // chaine un element apr�s un autre
		_EltSingleList *elt,           // element a chainer
		_EltSingleList *eltref);       // element de reference
	
	_EltSingleList *UnlinkFirst( void);// dechaine le premier element
	_EltSingleList *UnlinkLast( void); // dechaine le dernier element
	
	CW_USHORT Unlink(                  // dechaine un element
		_EltSingleList *elt);          // element a dechainer

	void Purge( void);                 // dechaine tous les elements
};


#define _LinkSingleListSearch(a, b, c) \
	c = (b *)a.GetFirst(); c != 0; c = (b *)a.GetNext(c)

#define _LinkSingleListSearchP(a, b, c) \
	c = (b *)a->GetFirst(); c != 0; c = (b *)a->GetNext(c)


#endif  // _CWLLIST_H_
