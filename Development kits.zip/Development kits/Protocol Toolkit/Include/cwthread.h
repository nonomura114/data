/*
** cwthread.h
*/


#ifndef _CWTHREAD_H_

	#define _CWTHREAD_H_

// The following THREAD_LOCAL_STORAGE extended storage-class modifier is
// used to declare a thread local variable. Thread Local Storage (TLS) is a
// Win32 mechanism that allows multiple threads of a process to store data
// that is unique for each thread.
// This attribute is a Microsoft-specific extensions to the C/C++ languages.

#define THREAD_LOCAL_STORAGE  __declspec( thread )

/*=====================*/
/*                     */
/*  _Thread Interface  */
/*                     */
/*=====================*/

/***************************/
/* _Thread class interface */
/***************************/

class CW_IMPORT_EXPORT _Thread: public CObject
{
	DECLARE_DYNAMIC( _Thread)

private:
	friend DWORD  WINAPI  ThreadRoutine( _Thread *Thread);

	HANDLE   m_ThreadHandle;   /* Thread Handle */

protected:
	HANDLE	 m_hThreadClosed;  // handle signaled when the routine thread is ended 
	DWORD    m_ThreadId;       /* Thread Identity */
	INT      m_ThreadPriority; /* Thread Priority */

public:
		_Thread( void);
		virtual ~_Thread( void);

	virtual CW_BOOL	CreateThread(
		int nPriority = THREAD_PRIORITY_NORMAL,
		UINT nStackSize = 0,
		DWORD dwCreationFlags = 0,
		LPSECURITY_ATTRIBUTES lpSecurityAttrs = NULL);

	HANDLE    GetHandle( void);
	DWORD     GetPid( void);
	CW_BOOL   SetPriority( int nPriority);
	int       GetPriority( void);
	CW_BOOL   Resume( void);
	CW_BOOL   Suspend( void);
	CW_BOOL   Terminate( DWORD dwExitCode=0);

	CW_BOOL   IsThreadActive( void);

	virtual DWORD   Run( void) { return 0; }
};


/****************************/
/* _Thread associated macro */
/****************************/

_Thread *BeginThread(
	int nPriority = THREAD_PRIORITY_NORMAL,
	UINT nStackSize = 0,
	DWORD dwCreationFlags = 0,
	LPSECURITY_ATTRIBUTES lpSecurityAttrs = NULL);

void EndThread( _Thread *Thread);


/*****************************/
/* _CwThread class interface */
/*****************************/

class CW_IMPORT_EXPORT _CwThread: public _Thread
{
	DECLARE_DYNAMIC( _CwThread)

protected:

	// 
	// Manage start & stop thread
	//
	#define DEFAULT_WAIT_START			INFINITE
	#define DEFAULT_WAIT_STOP			INFINITE
	#define DEFAULT_WAIT_EVENT			INFINITE

	#define STOPEVENT_NAME				"CwThreadStopEvent_%s"
	#define SYNCHROSTARTEVENT_NAME		"CwThreadSynchroEvent_%s"
	
	CW_LP_CHAR	m_lpszThreadName;
	CW_LP_CHAR	m_lpszStopEventName;
	CW_LP_CHAR	m_lpszSynchroStartEventName;

	CW_ULONG	m_ulWaitStart;
	CW_ULONG	m_ulWaitStop;
	CW_ULONG	m_ulWaitEvent;

	CW_ULONG	m_ulTabSizeEvents;
	HANDLE		m_hTabEvents[32];

public:
	CW_BOOL Start( void);
	CW_BOOL Stop( void);

	void	SetWaitStart( CW_ULONG ulWaitStart = DEFAULT_WAIT_START);
	void	SetWaitStop( CW_ULONG ulWaitStop = DEFAULT_WAIT_STOP);
	void	SetWaitEvent( CW_ULONG ulWaitEvent = DEFAULT_WAIT_EVENT);

	CW_ULONG	GetWaitStart( void);
	CW_ULONG	GetWaitStop( void);
	CW_ULONG	GetWaitEvent( void);

	//
	//	Constructeur / destructeur
	//
public:
	_CwThread(
		LPCSTR   lpszThreadName,	
		CW_ULONG ulWaitStart = DEFAULT_WAIT_START,
		CW_ULONG ulWaitStop = DEFAULT_WAIT_STOP,
		CW_ULONG ulWaitEvent = DEFAULT_WAIT_EVENT);
	virtual ~_CwThread( void);

	virtual DWORD	Run( void);
	virtual void	SpecificRun( CW_ULONG ulEvent);

};


/*********************************/
/* _CwThreadMail class interface */
/*********************************/

class CW_IMPORT_EXPORT _CwThreadMail: public _CwThread
{
	DECLARE_DYNAMIC( _CwThreadMail)

protected:
	//
	// Semaphore Rcv Mail
	//
	#define MAILBOX_NAME	"CwMailBoxName_%s"
	CW_LP_CHAR	m_lpszMailBoxName;
	_Event *m_RcvMsg;	// Notification de l'arriv�e d'un msg

public:

	void   NotifyActivation( void);
	//
	// MailBox du Thread
	//
	CW_LP_VOID m_MailBox;
	
	//
	//	Constructeur / destructeur
	//
	_CwThreadMail(
		LPCSTR      lpszThreadName,	
		CW_LP_VOID	lpMailBox,
		CW_ULONG ulWaitStart = DEFAULT_WAIT_START,
		CW_ULONG ulWaitStop  = DEFAULT_WAIT_STOP,
		CW_ULONG ulWaitEvent = DEFAULT_WAIT_EVENT);
	virtual ~_CwThreadMail( void);

	virtual DWORD	Run( void);
	virtual void	SpecificRun( CW_ULONG ulEvent);
};


#endif /* _CWTHREAD_H_ */

