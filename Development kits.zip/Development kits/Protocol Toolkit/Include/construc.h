

	/***************************************************************/
	/*-------------------------------------------------------------*/
	/* 																				*/
	/* 					C O N S T R U C  .  H								*/
	/* 																				*/
	/* 	 Constantes et structures definies dans le noyau et		*/
	/* 	 utilisables dans tous les modules de communication.		*/
	/* 																				*/
	/* 				C I M W A Y 	version	1 . 3							*/
	/* 																				*/
	/*-------------------------------------------------------------*/
	/***************************************************************/

#pragma pack(1)

#ifdef __cplusplus
	extern "C" {
#endif

	#define	VRAI		1
	#define	FAUX		- VRAI

	#define	OK		1
	#define	PASOK		- OK


	#define	NIL		0				/* Pointeur nul */

	#define	SIZPARA		16			/* Taille d'un paragraphe */


		/* Numerotation des primitives CIMWAY */
		/* __________________________________ */

	/* Fonction de marche arret */
	/* ------------------------ */
#define DESACT_CIMWAY				00		/* Desactivation de cimway */
#define DESACT_RESEAU				02		/* Desactivation de reseau */
#define DESACT_EQUIPEMENT			03		/* Desactivation d'equipement */
#define ACT_CIMWAY					10		/* Activation de cimway */
#define ACT_RESEAU					12		/* Activation de reseau */
#define ACT_EQUIPEMENT				13		/* Activation d'equipement */

	/* Fonction de lecture de donnees */
	/* ------------------------------ */
#define	LECTURE_CPC_BLOQUANT		20		/* Lecture CPC bloquant */
#define	LECTURE_CPC_N_BLOQUANT	21		/* Lecture CPC non bloquant */
#define	LECTURE_PAR_BLOQUANT		25		/* Lecture partielle bloquant */
#define	LECTURE_PAR_N_BLOQUANT	26		/* Lecture partielle non bloquant */

	/* Fonction d'ecriture de donnees */
	/* ------------------------------ */
#define	ECRITURE_CPC_BLOQUANT	30		/* Ecriture CPC bloquant */
#define	ECRITURE_CPC_N_BLOQUANT	31		/* Ecriture CPC non bloquant */
#define	ECRITURE_PAR_BLOQUANT	35		/* Ecriture partielle bloquant */
#define	ECRITURE_PAR_N_BLOQUANT	36		/* Ecriture partielle non bloquant */

	/* Fonction de controle */
	/* -------------------- */
#define	AUTO_INTERDIT_RELATION	40		/* Echange autocadence interdit pour la relation */
#define	AUTO_AUTORISE_RELATION	41		/* Echange autocadence autorise pour la relation */
#define	PERIODE_AUTOCADE			42		/* Modification de la periode autocade */
#define	AUTO_INTERDIT_EQUIP		50		/* Echange autocadence interdit pour l'equipement */
#define	AUTO_AUTORISE_EQUIP		51		/* Echange autocadence autorise pour l'equipement */
#define	AUTO_INTERDIT_RESEAU		55		/* Echange autocadence interdit pour le reseau */
#define	AUTO_AUTORISE_RESEAU		56		/* Echange autocadence autorise pour le reseau */

	/* Fonctions de transferts internes */
	/* -------------------------------- */
#define	MAJ_TAB_DONNEES		60		/* MAJ de la table de donnee indiquee */
#define	MAJ_TAB_IMAGE			62		/* MAJ de la table d'image indiquee */
#define	MAJ_TAB_DONNEES_PRIO	64		/* MAJ de la table de donnee rafraichie pour la priorite demandee */
#define	JOURNAL_RESEAU			68		/* Consultation du journal d'un reseau */
#define	JOURNAL_CHRONO			69		/* Consultation du journal chronologique */

	/* Fonctions de status */
	/* ------------------- */
#define	STATUS_CPT_RELATION		70		/* Status et compteur d'erreur d'une relation */
#define	STATUS_CPT_EQUIPEMENT	71		/* Status et compteur d'erreur d'un equipement */
#define	STATUS_CPT_RESEAU			72		/* Status et compteur d'erreur d'un reseau */
#define	RAZ_CPT_RELATION			75		/* RAZ du compteur d'erreur d'une relation */
#define	RAZ_CPT_EQUIPEMENT		76		/* RAZ du compteur d'erreur d'un equipement */
#define	RAZ_CPT_RESEAU				77		/* RAZ du compteur d'erreur d'un reseau */

	/* Fonctions divers */
	/* ---------------- */
#define	IDENTIF_EQUIPEMENT		90		/* Identification d'un equipement */
#define	IDENTIF_RELATION			91		/* Identification d'une relation */
#define	IDENTIF_TAB_DON			92		/* Identification d'une table de donnees */
#define	PRIMIT_DEBUG				99		/* Primitive pour le debug */
#define	CW_CYCLIC_ACTIVATE   	100  	/* Activation cyclique de CIMWAY */
#define	CW_CFG_ACTION        	110  	/* Modif param d'une trame */
#define	CW_CFG_EQUIP           	111  	/* Modif param d'un eqt */
#define	CW_CFG_NET             	112  	/* Modif param d'un reseau */

/**/

		/*	CODE DES ENVIRONNEMENTS SUPPORTES PAR CIMWAY	*/
		/* -------------------------------------------- */

#define	CODE_TOUT_ENV	0		/* Tout environnement			*/
#define	CODE_PC			1		/* Environnement PC				*/
#define	CODE_RIC_2P		2		/* Environnement RIC 2 ports	*/
#define	CODE_RIC_4P		3		/* Environnement RIC 4 ports	*/
#define	CODE_RIC_8P		4		/* Environnement RIC 8 ports	*/
#define	CODE_FACTOR		5		/* Environnement FACTOR			*/
#define	CODE_ETHER		6		/* Environnement ETHERNET		*/
#define	CODE_COMPEX		7		/* Environnement LAC (COMPEX)	*/
#define	CODE_MODICON	8		/* Environnement MODICON		*/

/**/
	/* Valeurs prises par le champ codret du descom */
	/* -------------------------------------------- */

#define	PASERR			0			/* Pas d'erreur de commande */
#define	ERRCFG			1			/* Erreur de configuration */
#define	ERRINT			2			/* Erreur interne a CIMWAY */
#define	CDE_N_EXIST		3			/* Commande inconnue */
#define	CDE_N_IMM		4			/* Commande implementee ulterieurement */
#define	CDE_N_GEREE		5			/* Commande inexistante pour ce protocole */
#define	ERRCDE			6			/* Commande avec erreur(s) de parametre */
#define	CIMWAY_INIT		7			/* CIMWAY deja initialise */
#define	CIMWAY_N_INIT	8			/* CIMWAY non initialise */
#define	RES_N_EXIST		9			/* Reseau inexistant */
#define	RES_ACTIF		10			/* Reseau deja actif */
#define	RES_N_ACTIF		11			/* Reseau non actif */
#define	AP_N_EXIST		12			/* Equipement inexistant */
#define	AP_ACTIF			13			/* Equipement deja actif */
#define	AP_N_ACTIF		14			/* Equipement non actif */
#define	LIEN_N_EXIST	15			/* DESLIEN inexistant */
#define	LIEN_N_GERE		16			/* DESLIEN non gere par CIMWAY */
#define	MEM_N_EXIST		17			/* DESMEM inexistant */
#define	MEM_N_GERE		18			/* DESMEM non gere par CIMWAY */
#define	AUTO_ACTIF		19			/* Autocadence(s) deja autorise(s) */
#define	AUTO_N_ACTIF	20			/* Autocadence(s) deja suspendu(s) */
#define	FILPL_PRIO		21			/* File prioritaire pleine */
#define	FILPL_APPLI		22			/* File application pleine */
#define	PAG_N_ACTIF		23			/* Echange non actif */
#define	PAS_LECT			24			/* Lecture coup par coup interdite */
#define	PAS_ECR			25			/* Ecriture coup par coup interdite */
#define	PAS_AUTO			26			/* Echange non defini en autocadence */
#define	ERR_RG_NB		27			/* Erreur sur le rang et/ou le nombre */
#define	CDE_FREQ_0		28			/* Periode nulle interdite */
#define	PAS_LECT_NBLOQ	29			/* Lecture cpc NON bloquante interdite	*/
#define	CDE_INTERDITE	30			/* Cde interdite pour cet echange	*/
#define	DEF_INIT_RES	31			/* Cde d'init. reseau en defaut		*/
#define	DEF_INIT_AP		32			/* Cde d'init. AP en defaut			*/
#define	DEF_ARRET_RES	33			/* Commande d'arret reseau en defaut*/
#define	DEF_ARRET_AP	34			/* Commande d'arret AP en defaut		*/
#define	CDE_BLOQ_DEF	35			/* Cde bloquante en defaut				*/
#define	CDE_BLOQ_ABORT	36			/* Cde bloquante abandonnee			*/
#define	PAS_RAF			37			/* Pas de donnees rafraichies			*/
#define	DATA_N_INIT		38			/* Donnees non initialisees			*/
#define	ERR_VERSION		39			/* Erreur de version des descripteurs de CIMWAY	*/
#define	CDE_N_TRAITEE	40			/* Commande non traitee par le protocole	*/

	  /*Flags particuliers utilises pour CPARA1
		 ---------------------------------------*/

#define		CPAR1_PRIO	      0x01	/* Indication d'echange prioritaire*/
#define		CPAR1_SEQ	      0x02	/* Sequencement obligatoire pour l'echange*/
#define		CPAR1_COND	      0x04  /* Traitement conditionnel pour l'echange */
#define	   CPAR1_TYPETABLE	0x08	// Param�trage du type de table utilis�
#define	   CPAR1_TUSER	      0x10	// Traitement de cde d'�criture sur la
					                     // table user( utilis� si TYPETABLE = 1)

		/*Valeurs prises par CPARA1 en retour de la primitive 70
		 ------------------------------------------------------*/

#define	CP1P_DEFECH	  0x0001		/*Defaut au cours du dernier echange*/
#define	CP1P_VHS		  0x0002		/*Reseau concerne hors service*/
#define	CP1P_APHS	  0x0004		/*Equipement concerne hors service*/
#define	CP1P_ERLIGN	  0x0008		/*Erreur de transmission*/
#define	CP1P_ERPROT	  0x0010		/*Erreur de protocole*/
#define	CP1P_ERRECUP  0x0020		/*Erreur signalee par l'equipement*/
#define	CP1P_ERESEAU  0x0040		/*Erreur reseau*/
#define	CP1P_ERTO	  0x0080		/*Erreur time-out sur l'echange*/
#define	CP1P_FILAPPL  0x0100		/*File des commandes d'application pleine*/
#define	CP1P_FILAUTO  0x0200		/*File des commandes autocadencees pleine*/
#define	CP1P_FILPRIO  0x0400		/*File des commandes prioritaires pleine*/
#define	CP1P_EXECDE	  0x1000		/*Commande en cours de traitement*/
#define	CP1P_GAUT	  0x2000		/*Echange autocadence actif*/
#define	CP1P_AEF		  0x4000		/*Echange autocadence deja en file*/
#define	CP1P_RAF		  0x8000		/*Table image rafraichie*/


		/*Valeurs prises par CPARA1 en retour de la primitive 71*/
		/*------------------------------------------------------*/

#define	CP1A_HS		0x0001		/*Equipement hors service*/
#define	CP1A_BLQ		0x0002		/*Equipement indisponible*/
#define	CP1A_ERINIT	0x0004		/*Erreur d'init. de l'equipement*/
#define	CP1A_ERFIN	0x0008		/*Erreur d'arret de l'equipement*/
#define	CP1A_DEFAUT	0x0010		/*Defaut pour la derniere commande*/
#define	CP1A_DIF		0x0020		/*Equipement de diffusion*/
#define	CP1A_VAL		0x0100		/*Equipement operationnel*/
#define	CP1A_GAUT	0x0200		/*Autocadence(s) actif(s) pour l'equipement*/
#define	CP1A_VCAD	0x0400		/*Autocadence(s) autorise(s) pour l'equipement*/


		/*Valeurs prises par CPARA1 en retour de la primitive 72*/
		/*------------------------------------------------------*/

#define	CP1V_HS			0x0001	/*Reseau hors service*/
#define	CP1V_ERINIT		0x0002	/*Erreur d'init. du reseau*/
#define	CP1V_ERFIN		0x0004	/*Erreur d'arret du reseau*/
#define	CP1V_ERMAINT	0x0008	/*Erreur de maintien du reseau*/
#define	CP1V_DEFAUT		0x0010	/*Defaut pour la derniere commande*/
#define	CP1V_VAL			0x0100	/*Reseau operationnel*/
#define	CP1V_GAUT		0x0200	/*Autocadence(s) actif(s) sur le reseau*/
#define	CP1V_VCAD		0x0400	/*Autocadence(s) autorise(s) sur le reseau*/



		/* Valeurs prises CPARA4 en retour des primitives 60 et 64 */
		/*---------------------------------------------------------*/


#define CP4D_NRAF		01 		/* donnees non rafraichies */
#define CP4D_XRAF		02			/* donnees plusieurs fois rafraichies */
#define CP4D_DATEXT	04			/* datation externe */



/*----------------
	TABLE DESCOM :
  ----------------*/

         /*  Valeurs prises par CPAR_HORL
  			    ----------------------------  */

#define	CPH_RIEN				0	/*Sans signification ou inexistante*/
#define	CPH_RTC				1	/*Horloge type IBM AT ( PC ou PS )*/
#define	CPH_RTC_SANS_BIOS	2	/*horloge non geree par le BIOS*/


#define  SIZCDYNCFG  256+1    /* Taille du buffer pour les parametres
                                 de configuration */

/*----------------
	TABLE DESVOIE :
  ----------------*/


	/* Constantes utilisees pour VMOD_VIT
		----------------------------------	*/

#define	VMV_RIEN		0		/*Vitesse = Sans signification*/
#define	VMV_50		1		/*Vitesse = 50 bauds*/
#define	VMV_75		2		/*Vitesse = 75 bauds*/
#define	VMV_150		3		/*Vitesse = 150 bauds*/
#define	VMV_300		4		/*Vitesse = 300 bauds*/
#define	VMV_600		5		/*Vitesse = 600 bauds*/
#define	VMV_1200		6		/*Vitesse = 1200 bauds*/
#define	VMV_2400		7		/*Vitesse = 2400 bauds*/
#define	VMV_4800		8		/*Vitesse = 4800 bauds*/
#define	VMV_9600		9		/*Vitesse = 9600 bauds*/
#define	VMV_19200	10		/*Vitesse = 19200 bauds*/
#define	VMV_38400	11		/*Vitesse = 38400 bauds*/


	/*Constantes utilisees pour  VMOD_DAT
	  ----------------------------------*/

#define	VMD_1BIT		1		/*Caractere =	1 bit*/
#define	VMD_2BIT		2		/*Caractere =	2 bits */
#define	VMD_3BIT		3		/*Caractere =	3 bits*/
#define	VMD_4BIT		4		/*Caractere =	4 bits*/
#define	VMD_5BIT		5		/*Caractere =	5 bits*/
#define	VMD_6BIT		6		/*Caractere =	6 bits*/
#define	VMD_7BIT		7		/*Caractere =	7 bits*/
#define	VMD_8BIT		8		/*Caractere =	8 bits*/
#define	VMD_9BIT		9		/*Caractere =	9 bits*/
#define	VMD_10BIT	10		/*Caractere = 10 bits*/
#define	VMD_11BIT	11		/*Caractere = 11 bits*/
#define	VMD_12BIT	12		/*Caractere = 12 bits*/
#define	VMD_13BIT	13		/*Caractere = 13 bits*/
#define	VMD_14BIT	14		/*Caractere = 14 bits*/
#define	VMD_15BIT	15		/*Caractere = 15 bits*/


	/*Constantes utilisees pour  VMOD_STB
	  ----------------------------------*/

#define	VMS_0			0		/*0 stop bit*/
#define	VMS_1			1		/*1 stop bit*/
#define	VMS_1DEMI	2		/*1,5 stop bit*/
#define	VMS_2			3		/*2 stop bits*/


	/*Constantes utilisees pour  VMOD_PAR
	  ----------------------------------*/

#define	VMP_SANS		0		/*Sans parite*/
#define	VMP_PAIRE	1		/*Parite paire*/
#define	VMP_IMPAIRE	2		/*Parite impaire*/



/*----------------
	TABLE DESLIEN :
  ----------------*/

		/*Valeurs prises par LPAR_TYP
		  ---------------------------*/

#define	L_INTERNE	0	/*DESLIEN non gere par CIMWAY*/
#define	L_MAITRE		1	/*DESLIEN gere en mode maitre*/
#define	L_ESCLAVE	2	/*DESLIEN gere en mode esclave*/


/*---------------
  TABLE DESMEM :
 ---------------*/

	/*Constantes utilisees pour TYPDATA
	 ----------------------------------*/


#define		MT_1BIT		0		/*Information codee sur 1 bit*/
#define		MT_8BIT		1		/*Information codee sur 8 bits */
#define		MT_16BIT		2		/*Information codee sur 16 bits	*/
#define		MT_32BITFL	3		/*Information codee sur 32 bits --> Reel IEEE*/
#define		MT_32BITFI	4		/*Information codee sur 32 bits --> Entier*/



/*---------------
  TABLE DESPAG :
 ---------------*/

		/*Valeurs prises par  CODLIG
		 --------------------------*/

#define		PCODL_BIN	1	/*Codage sur la ligne en binaire*/
#define		PCODL_ASC	2	/*Codage sur la ligne en ASCII*/
#define		PCODL_BCD	4	/*Codage sur la ligne en BCD compacte*/


		/* Flags utilises pour PETACOMP
		  ----------------------------*/
/* Flags utilises pour PETATCOMP quand PETAT = PETA_ERLIGN*/

#define	PETC_FRAM		 0x0001	/* Erreur de framing 							 */
#define	PETC_OVER		 0x0002	/* Erreur d'overrun                        */
#define	PETC_PARI		 0x0004	/* Erreur de parite								 */
#define	PETC_CHECKSUM	 0x0008	/* Erreur de check sum							 */
#define	PETC_BREAK		 0x0010	/* Erreur reception d'un break non attendu */
#define	PETC_ECHO		 0x0020	/* Erreur sur reception echo					 */
#define	PETC_EMIS		 0x0040	/* Erreur d'emission                       */

/*Flags utilises pour PETATCOMP quand PETAT = PETA_ERPROT*/

#define	PETC_FCTNEXIST  0x0001	 /*Fonction inconnue recue */
#define	PETC_FCTNGEREE  0x0002	 /*Fonction connue mais non geree*/
#define	PETC_FCTNACK	 0x0004	 /*Fonction emise non comprise par le destinataire*/
#define	PETC_FCTERR 	 0x0008	 /*Fonction recue dephasee / requete*/
#define	PETC_ERRNB		 0x0020	 /*Nbre d'informations incorrect*/
#define	PETC_ERRADR 	 0x0040	 /*Adresse incorrecte (inexistante ou inacessible ou differente / requete)*/
#define	PETC_ERRDON 	 0x0100	 /*Donnees incorrectes (non autorisees ou differentes / requete)*/
#define	PETC_PASPRET	 0x0400	 /*Destinataire non pret*/
#define	PETC_ERRNUMAP	 0x0800	 /*Numero du destinataire errone*/
#define	PETC_PROTSPE	 0x1000	 /*Butee pour erreurs specifiques aux protocoles*/

/*---------------
 TABLE DESDON :
 ---------------*/

		/*Flags utilises pour DPARA
		  -------------------------*/

#define		DPAR_RES		0x0FF	/*Reserve*/


		/*Parametres pour la gestion des horloges
		 ---------------------------------------*/

#define		SET_HRL		1				/*Activation de l'horloge concernee*/
#define		RESET_HRL	0				/*Desactivation de l'horloge concernee*/


		/*Parametres pour l'activation / desactivation de l'USART
		 -------------------------------------------------------*/

#define		SET_VOIE		0					/*Activation*/
#define		RESET_VOIE	! SET_VOIE		/*Desactivation*/


		/*===============================================

			CONSTANTES	GENERALES  UTILISEES  POUR
			_ Le JOURNAL CHRONOLOGIQUE
			_ Le JOURNAL d'INCIDENTS par RESEAU

		 ===============================================*/



		/*Nature des erreurs : champ NATURE
		 ---------------------------------*/

#define		ERR_CFG		1	/*Erreur de configuration*/
#define		ERR_COM		2	/*Erreur de communication*/
#define		ERR_INTERNE	3	/*Erreur interne*/


		/*Niveau des erreurs : champ NIVEAU
		 ---------------------------------*/

#define		NON_SENS		0	/*Erreur non correlee a un niveau particulier.*/

#define		NIV_RES		1	/*Erreur detectee au niveau reseau*/
#define		NIV_AP		2	/*Erreur detectee au niveau equipement*/
#define		NIV_ECH		3	/*Erreur detectee au niveau echange*/


		/*Codes des descripteurs : champ CODESC
		 -------------------------------------*/

#define	COD_DESCOM		1	/*Descripteur DESCOM*/
#define	COD_DESLIEN		2	/*Descripteur DESLIEN*/
#define	COD_DESMEM		3	/*Descripteur DESMEM*/
#define	COD_DESVOIE		4	/*Descripteur DESVOIE*/
#define	COD_DESAP		5	/*Descripteur DESAP*/
#define	COD_DESPAG		6	/*Descripteur DESPAG*/
#define	COD_DESDON		7	/*Descripteur DESDON*/


		/*==============================================

			CODIFICATION des ERREURS mises au
			JOURNAL CHRONOLOGIQUE.
			_________________________________

		===============================================*/


#define		CXT_NDISP		0	/*Contexte non disponible pour un DESVOIE*/
#define		PRT_NDISP		1	/*Port non disponible pour un DESVOIE*/
#define		PCL_N_EXIST		2	/*Codage ligne inconnu*/
#define		PA_NDEF			3	/*Pas d'action definie pour DESPAG*/
#define		PCAD_NDEF		4	/*Cadence non definie pour 1 cde autocadencee*/
#define		PLIEN_NCOM		5	/*DESLIEN devrait etre gere par CIMWAY (DESPAG)*/
#define		PLIEN_ADIF		6	/*Declaration autocad. differente dans DESLIEN (DESPAG)*/
#define		PLIEN_ALDIF		7	/*Mode d'autocad. different dans DESLIEN (DESPAG)*/
#define		PMEM_NCOM		8	/*DESMEM devrait etre gere par CIMWAY (DESPAG)*/
#define		TOV_NUL			9	/*Time out nul pour DESVOIE*/
#define		LVOIE_NEXIST	10	/*DESVOIE inexistant (DESLIEN)*/
#define		LPAG_NEXIST		11	/*DESPAG inexistant (DESLIEN)*/
#define		LMEM_NEXIST		12	/*DESMEM inexistant (DESLIEN)*/
#define		LMEM_NCOM		13	/*DESMEM devrait etre gere par CIMWAY (DESLIEN)*/
#define		MTYP_NEXIST		14	/*DESMEM avec type de donnee inconnu*/
#define		PRT_NEXIST		15	/*Port n'existe pas*/
#define		PRT_VITNEXIST	16	/*La vitesse n'existe pas*/
#define		PRT_DATNEXIST	17	/*Le nb de bits par caractere n'existe pas*/
#define		PRT_STBNEXIST	18	/*Le nb de stop bit par caractere n'existe pas*/
#define		PRT_PARNEXIST	19	/*Le type de parite n'existe pas*/
#define		MSIZPAG_ERR		20	/*Taille des donnees user et image lie au desmem trop grande*/
#define		PTYP_NEXIST		21	/*Type de donnee AP n'existe pas*/
#define		PCL_MTYPDON		22	/*Codage ligne non supporte pour le type de donnees du DESMEM*/
#define		VADEF_N_EXIST	23	/*Autocadence defini mais pas de DESPAG declare*/

		/* Code des erreurs sur erreur INTERNE*/
#define		ERR_RSCE_MEM		24	/*Plus de ressource memoire*/
#define		ERR_NUMREQ_NIV7	25	/*Numero de la requete de niveau 7 inconnu.*/
#define		ERR_NUMREQ_NIV2	26	/*Numero de la requete de niveau 2 inconnu.*/
#define		ERR_NUMREQ_NIV1	27	/*Numero de la requete de niveau 1 inconnu.*/
#define		ERR_NUMIRQ			28	/*Numero d'IRQ de communication incorrect*/
#define		VPAG_NAUTO			29	/*DESPAG devrait etre declare autocadence  */
#define		POFSAP_DIF			30	/*DESPAG ne pointe pas sur le bon desap  */



		/************************************************
		 -----------------------------------------------

						COMMUNICATION	INTER - COUCHES

		 -----------------------------------------------
		 ***********************************************/



/*---------------------------
  MESSAGE DE COMMUNICATION :
 ---------------------------*/

							/* --------------
								structure smsg
								-------------- */


	/* Valeurs prises par M_SOURCE et par M_DEST
	 -----------------------------------------*/

#define		NIV1		1	/*Couche 1*/
#define		NIV2		2	/*Couche 2*/
#define		NIV7		7	/*Couche 7*/

	/* Valeurs prises par M_CDE
	 ------------------------*/

		/* Emetteur = NIV7  et	destinataire = NIV2
		 ----------------------------------------*/

#define	REQ_LEC		 0x01	/*Requete de lecture 							 */
#define	REQ_ECR		 0x02	/*Requete d'ecriture                       */
#define	REQ_INIAP	 0x11	/*Requete d'init. d'un equipement          */
#define	REQ_FINAP	 0x12	/*Requete d'arret d'un equipement          */
#define	REQ_INIRES	 0x21	/*Requete d'init. d'un reseau              */
#define	REQ_FINRES	 0x22	/*Requete d'arret d'un reseau              */
#define	REQ_MAINTRES 0x23	/*Requete de maintien d'un reseau          */

#define	REQ_RESET	 0x31	/*Requete de reinitialisation d'un echange*/


		/*Emetteur = NIV2  et  destinataire = NIV7
		----------------------------------------*/

#define		IND_ACQ_POS		1	/*Indication d'acquittement positif*/
#define		IND_ACQ_NEG		2	/*Indication d'acquittement negatif*/
#define		IND_NON_GERE	3	/*Indication de commande non supportee*/
#define		IND_ERREUR		4	/*Indication d'erreur*/


		/*Emetteur = NIV2  et  destinaire = NIV1
		 --------------------------------------*/

#define	REQ_EMIS				1	/*Requete d'emission*/
#define	REQ_EMIS_ECHO		2	/*Requete d'emission avec echo*/
#define	REQ_RECEP			3	/*Requete de reception*/
#define	REQ_EMIS_RECEP		4	/*Requete d'emission-reception*/
#define	REQ_WAIT				5	/*Requete d'attente*/
#define	REQ_CONNECT			6	/*Requete de connexion*/
#define	REQ_DCONNECT		7	/*Requete de deconnexion*/
#define	REQ_ENTETE_L1		8	/*Requete d'emission de l'entete L1*/
#define	REQ_BRK_WAIT_EMI	9	/*Requete d'emis. d'un break puis attente puis emission*/
#define	REQ_DISPO			10	/*Requete de demande et/ou modification de*/
										/*disponibilite d'un equipement (LAC)*/
#define	REQ_RESET			0x31	/*Requete de reinitialisation (cte deja definie)*/


		/*Constantes associees au type d'emission
		 ---------------------------------------*/

#define		EMIS_BREAK		1	/*emission de break*/
#define		EMIS_CARACTERE	2	/*emission de caracteres*/


		/*Emetteur = NIV1  et  destinaire = NIV2
		--------------------------------------*/

/* 		IND_ACQ_POS		1	;Indication d'acquittement positif
			IND_ACQ_NEG		2	;Indication d'acquittement negatif
			IND_ERREUR		4	;Indication d'erreur
	CES 3 CONSTANTES SONT DEJA DEFINIES POUR LES COUCHES 2 -> 7 */


#define	IND_TOEMI_S		5	/*Indication de fin d'emission de signal*/
#define	IND_FINEMI_C	6	/*Indication de fin d'emission de carac.*/
#define	IND_TOEMI_C		7	/*Indication de fin d'emission calibree*/
#define	IND_TORECEP		8	/*Indication de fin de reception calibree*/
#define	IND_FINRCP_C	9	/*Indication de fin de reception de carac.*/
#define	IND_RECEP_S		10	/*Indication de reception de signal*/
#define	IND_TOWAIT		11	/*Indication de fin d'attente*/
#define	IND_STATUS		12	/*Indication de status*/
#define	IND_CONNECT		13	/*Compte-rendu de connexion*/
#define	IND_DCONNECT	14	/*Compte-rendu de deconnexion*/



	/*Valeurs prises par M_PARAM1
	 ---------------------------*/

		/*Pour une demande de reception (LAC)
		  -----------------------------------*/

#define		RECEP_COND	1	/*Reception conditionnelle (le protocole demande a la
									; couche 1 une reponse immediate, avec un code retour
									; PASOK si rien n'a ete recu, avec un code retour OK,
									; le descripteur et le tampon de reception mis a jour
									; si des donnees ont ete recues)*/
#define		RECEP_IMP	0	/*Reception imperative (le protocole, dans ce cas n'aura
									; de reponse que lorsque des donnees seront effectivement
									; recues)*/


		/*Pour une demande concernant la disponibilite AP (LAC)
		  -----------------------------------------------------*/

#define	DISPO_INIT	0	/*Valeur d'initialisation flag des purges*/
#define	DISPO_ON_C1	1	/*Acquittement a purger*/
#define	DISPO_ON_C2	2	/*Message a purger*/


	/*Valeurs prises par M_PARAM2*/
	/*---------------------------*/

		/*Pour une demande concernant la disponibilite AP (LAC)
		  -----------------------------------------------------*/

#define		DISPO_OFF	0	/*Commande non autorisee vers station*/
#define		DISPO_ON		1	/*Commande autorisee vers station*/

#define		ON_LINE		0	/*Station initialisee*/
#define		OFF_LINE		1	/*Station non initialisee*/
#define		NO_CHG_LINE	2	/*Pas de changement sur flag initialisation*/


							/*---------------
							  structure scxt
							  ---------------*/

		/*CONSTANTES UTILISEES POUR LA GESTION DE CONTEXTE*/
		/*------------------------------------------------*/

/*Champ	XCOMMANDE :*/
/*------------------*/

#define	XCOM_LEC			0x01		/*Commande de lecture*/
#define	XCOM_ECR			0x02		/*Commande d'ecriture*/

#define	XCOM_PAP			0x10		/*Butee debut des commandes de portee AP*/

#define	XCOM_INIAP		0x11		/*Commande Init de l'equipement*/
#define	XCOM_FINAP		0x12		/*Commande Arret de l'equipement*/

#define	XCOM_PRES		0x20		/*Butee debut des commandes de portee reseau*/

#define	XCOM_INIRES		0x21		/*Commande Init du Reseau*/
#define	XCOM_FINRES		0x22		/*Commande Arret du Reseau*/
#define	XCOM_MAINTRES	0x23		/*Commande Maintien du reseau*/


/*Champ	XCYCLE :*/
/*-------------- */

#define	XCYC_ANNUL	0	/*Commande annulee*/
#define	XCYC_APPLI	1	/*Commande application*/
#define	XCYC_AUTO	2	/*Commande autocadencee*/
#define	XCYC_PROT	3	/*Commande interne au protocole*/



		/*************************************************/
		/*-----------------------------------------------*/
		/*																 */
		/* 		CODIFICATION DES ERREURS TRANSMISES		 */
		/* 						A LA COUCHE 7					 */
		/*																 */
		/*-----------------------------------------------*/
		/*************************************************/



		/*Constantes utilisees pour M_PARAM1 avec la commande IND_ERREUR*/
		/*--------------------------------------------------------------*/

#define		ERR_NON_FATALE	1	/*Erreur non catastrophique pour l'echange*/
#define		ERR_FATALE		2	/*Erreur catastrophique pour l'echange*/
										/*Il n'y a pas de repetition d'effectuee*/
										/* pour ce type d'erreur.*/


		/*Constantes utilisees pour M_PARAM2 avec la commande IND_ERREUR*/
		/*--------------------------------------------------------------*/

#define		JOURNAL			1	/*Erreur mise au journal d'incidents du reseau*/
#define		SANS_JOURNAL	2	/*Erreur non mise au journal d'incidents du reseau*/

							/*-------------------
							 structure Serr_Niv7
							 --------------------*/

					 /*Constantes utilisees pour ER_PHASERR*/
					 /*------------------------------------*/

#define	PHASE_EMI		 1 		/*Erreur detectee en emission*/
#define	PHASE_RECEP 	 2 		/*Erreur detectee en reception*/
#define	PHASE_AUTRE 	 3 		/*L'erreur est detectee dans une phase indeterminee*/


					 /*Constantes utilisees pour ER_CODE*/
					 /*---------------------------------*/

		  /*Si ER_NIVEAU = NIV_RES, NIV_AP : */

#define	ERR_LIGN			1		  /*Erreur de transmission*/

		  /*Si ER_NIVEAU = NIV_ECH :*/

#define	ERR_PROT 		2		  /*Erreur de protocole 					 */
#define	ERR_RECUP		3		  /*Erreur signalee par le correspondant*/
#define	ERR_RESEAU		4		  /*Erreur reseau 							 */
#define	ERR_TO			5		  /*Time-out echu 							 */
#define	ERR_AUTRE		6		  /*Autre categorie d'erreur            */
#define	ERR_EMI			7		  /* erreur en emission 					 */
#define	ERR_RECEP		8		  /* erreur en reception					 */


					 /*Constantes utilisees pour ER_S_CODE1*/
					 /*------------------------------------*/

/****************************************************************************
  Si ER_CODE = ERR_LIGN :

  Les valeurs codees dans le champ ER_S_CODE1 sont les memes constantes
	qui sont utilisees pour le champ PETATCOMP (cf constantes de DESPAG)


  Si ER_CODE = ERR_PROT :

  Les valeurs codees dans le champ ER_S_CODE1 sont les memes constantes
	qui sont utilisees pour le champ PETATCOMP (cf constantes de DESPAG)


  Si ER_CODE = ERR_RECUP :

  Code d'erreur retourne par le correspondant


	  Si ER_CODE = ERR_RESEAU :
****************************************************************************/


#define	ERR_N10			 1 		/*Erreur du reseau N10		*/
#define	ERR_FACTOR		 2 		/*Erreur du reseau FACTOR	*/
#define	ERR_LAC			 3 		/*Erreur du reseau LAC		*/
#define	ERR_ETHERNET	 4 		/*Erreur du reseau ETHERNET*/
#define	ERR_MODBUS_PLUS 5 		/*Erreur du reseau MODBUS_PLUS*/


/***************************************************************************
Si ER_CODE = ERR_TO :	  =====>  Champ non significatif

Si ER_CODE = ERR_AUTRE :  =====>  Code d'erreur retourne par CIMWAY


					  Constantes utilisees pour ER_CODCDE
					  -----------------------------------

NON_SENS 		  0		 Aucune commande particuliere n'est
												 concernee par l'erreur detectee.

Les autres constantes correspondent aux codes des commandes transmises
  a la couche 2 par la couche 7.
Si l'erreur signalee concerne la requete de lecture, le champ ER_CODCDE
 contient la valeur REQ_LEC.
 *************************************************************************/


	/********************************************************/
	/*------------------------------------------------------*/
	/*																		  */
	/*				CONSTANTES COMMUNES aux COUCHES 1 et 2		  */
	/*				______________________________________		  */
	/*																		  */
	/*-------------------------------------------------------*/
	/*********************************************************/


		/*Constantes utilisees pour l'horloge 50ms et l'horloge rapide*/
		/*------------------------------------------------------------*/

#define	HRL_ARMEMENT		1	/*Armement de l'horloge concernee*/
#define	HRL_ARMEMENT_CAR	2	/*Armement de l'horloge (unite de temps = caractere)*/
#define	HRL_DESARMEMENT	3	/*Desarmement de l'horloge concernee*/
#define	HRL_TEL_QUE			4	/*Non modification de l'etat de l'horloge concernee*/


		/*Constante utilisee uniquement pour l'horloge 50ms*/
		/*-------------------------------------------------*/

#define	HRL_REARMEMENT		5	/*Rearmement de l'horloge concernee*/

							/* structure smsg */
							/*----------------*/

		/*Constantes utilisees pour M_PARAM1 avec la commande REQ_RESET*/
		/*-------------------------------------------------------------*/

#define		AVEC_STATUS	1	/*Demande a la couche 1 de retourner un*/
									/* accuse-reception : commande IND_STATUS*/
#define		SANS_STATUS	2	/*Demande a la couche 1 de ne retourner*/
									/* aucun accuse-reception.*/

		/*Param. d'entrees de la fct pointee par le champ M_@FCT_RCP*/
		/*----------------------------------------------------------*/

#define		PASDERR		0	/*Pas d'erreur detectee*/

/***	PETC_FRAM		0001H	Erreur de framing, deja defini*/
/***	PETC_OVER		0002H	Erreur d'overrun, deja defini*/
/***	PETC_PARI		0004H	Erreur de parite, deja defini*/
/***	PETC_CHECKSUM	0008H	Erreur de check sum, deja defini*/
/***	PETC_BREAK		0010H	Erreur reception d'un break non attendu, deja defini*/
/***	PETC_ECHO		0020H	Erreur sur reception echo, deja defini*/
/***	PETC_EMIS		0040H	Erreur d'emission, deja defini*/


					/*   STRUCTURE GENERALE */
					/*----------------------*/


struct sdatation
{
	OCTET			jj;				/*jour*/
	OCTET			mm;				/*mois*/
	OCTET			hh;				/*heure*/
	OCTET			mn;				/*minute*/
	MOT			msec;				/*seconde*/
};


	/*****************************************************************/
	/*---------------------------------------------------------------*/
	/*																					  */
	/*					Definition	des  STRUCTURES  du	NOYAU.			  */
	/*					_______________________________________			  */
	/*																					  */
	/*---------------------------------------------------------------*/
	/*****************************************************************/


/**/


		/*************************************************/
		/* INTERFACE ENTRE L'APPLICATION ET LE PROTOCOLE */
		/* --------------------------------------------- */

							/* Le descom */
							/* --------- */

struct	sdescom
{
	struct
	{
		MOT			cprimit;						/* Numero de primitive */
		OCTET			codret;						/* Code de retour */
		OCTET			cversion;					/* Version des descripteurs */
		MOT			cnolien;						/* Numero de deslien */
		MOT			cpara1;						/* Si cmd partielle alors = rang */
		MOT			cpara2;						/* Si cmd partielle alors = nb info */
		MOT			cpara3;						/* zone 3 de parametrage de la cde */
		MOT			cpara4;						/* zone 4 de parametrage de la cde */
		MOT			cpara5;						/* zone 5 de parametrage de la cde */
		MOT			cpara6;						/* zone 6 de parametrage de la cde */
	}param;
	MOT			cnblien;							/* nombre de deslien */
	struct	sdeslien		far *pf_desl1;		/* pointeur sur le 1er deslien */
	MOT			cnbmem;							/* nombre de desmem */
	struct	sdesmem		far *pf_desm1;		/* pointeur sur le 1er desmem */
	MOT			cnbvoie;							/* nombre de desvoie */
	struct	sdesvoie		far *pf_desv1;		/* pointeur sur l1er desvoie */
	MOT			cnblog;							/* nb de poste du journal */
	MOT			far *pf_log;					/* ptr sur le journal */
	struct
	{
		unsigned	horl		:2;					/* Type d'horloge rapide */
		unsigned	f_env		:1;					/* Adresse definie pour l'env.*/
		unsigned	f_ioenv	:1;					/* I/O definie pour l'environ.*/
		unsigned	f_irq		:1;					/* IRQ defini pour l'environ. */
		unsigned	reserve	:11;					/* Reserve */
	} cpar;											/* parametres	*/
	OCTET			codenv;							/* code de l'environnement */
	OCTET			cnumirq;							/* numero d'IRQ pour l'environnement */
	OCTET far	*ptrenv;							/* adresse memoire de l'environnement */
	MOT			cioenv;							/* adresse I/O de l'environnement */
   OCTET       cdyncfg[SIZCDYNCFG];       /* buffer pour parametre de cfg */
};

#define	SIZCOM	sizeof(struct sdescom)	/* Taille du descom en octet */
/**/


		/* Le deslien */
		/* ---------- */

struct	sdeslien
{
	MOT			lidesmem;			/* numero du desmem de cette action */
	MOT			luser1;				/* reserve prgm utilisateur */
	OCTET			luser2;				/* reserve prgm utilisateur */
	OCTET			lidvoie;				/* index du desvoie concerne par cette action */
	MOT			lidpag;				/* index du despag concerne par cette action */
	struct
	{
		unsigned	char lpar_typ		:2;	/* type d'enregistrement */
		unsigned	char lpar_act		:1;	/* activation de deslien */
		unsigned	char lpar_aut		:1;	/* autocadence declare */
		unsigned	char lpar_la		:1;	/* autocadence en lecture */
		unsigned	char lpar_tlis		:1;	/* tete de liste des donnees regroupees */
		unsigned	char reserve		:2;	/* reserve */
													/* MODIF JS - CW16 - 22/05/1996 */
		unsigned char reserv2      :8;   /* remplacement de OCTET lnolist */
	} lpara;
//	OCTET			lnolist;				/* numero de liste de donnees regroupees */
	MOT			lidmgroup;			/* index du deslien suivant du meme groupe */
											/* #MODIFDL 09/04/96 */
	MOT			lcptlecture;		/* nombre de lecture ok */
	MOT			lreserve1;			/* reserve */
	MOT			liduser;				/* identifiant utilisateur */
};

#define	SIZLIEN	sizeof(struct sdeslien)	/* Taille du deslien en octet */

/**/



		/* Le desvoie */
		/* ---------- */

struct	sdesvoie
{
	struct
	{
		unsigned	vmod_vit		:4;	/* Vitesse de la voie			*/
		unsigned	vmod_dat		:4;	/* Nombre de bits de donnee	*/
		unsigned	vmod_stb		:2;	/* Nombre de bits stop			*/
		unsigned	vmod_par		:2;	/* Parite							*/
		unsigned	vmod_serv		:1;	/* Gestion modem					*/
		unsigned	reserve		:3;	/* Reserve */
	} vmode;
	OCTET			vnovoie; 			/* numero de la voie */
	OCTET			vnoprotoc;			/* numero de protocole */
	struct
	{
		unsigned vpar_hs		:1;	/* reseau HS */
		unsigned vpar_cad		:1;	/* existence d'autocad configurees */
		unsigned vpar_vcad	:1;	/* autocad autorisees pour la voie */
		unsigned vpar_gaut	:1;	/* idem, dynamique */
		unsigned vpar_vact	:1;	/* reseau activ� */
		unsigned vpar_eri		:1;	/* erreur sur init reseau */
		unsigned vpar_erf		:1;	/* erreur sur fin reseau */
		unsigned vpar_erm		:1;	/* erreur sur maintien reseau */
		unsigned vpar_def		:1;	/* defaut lors de la derniere commande */
		unsigned vpar_niv2	:1;	/* couche 2 seulr utilisee pour ce reseau */
		unsigned vpar_val		:1;	/* reseau actif */
		unsigned vpar_mef		:1;	/* maintien reseau en file */
		unsigned vpar_res		:4;	/*  bits reserves */
	} vpara;
	MOT			vtimout;					/* timout d'echange par defaut */
	MOT			vnbap;					/* nombre de desap */
	struct sdesap far *pf_desa1;		/* pointeur sur le 1er desap de cette voie */
	MOT			vnbpag;					/* nombre de despag */
	struct sdespag far *pf_desp1;		/* pointeur sur le 1er despag pour cette voie */
	struct sdespag near *pn_auto1;	/* pointeur du 1er despag autocadence */
	MOT			vnbauto;					/* nombre d'autocadences actifs*/
	MOT			verreur;					/* compteur d'erreurs pour la voie */
	MOT			verligne;				/* compteur d'erreurs physiques pour la voie */
	MOT			vnbcdeabort;			/* nombre de cdes abandonnees */
	OCTET			vroutage;				/* valeur de routage de la voie */
	OCTET			vparaspe;				/* parametres specifiques */
	MOT			vspecifiq;				/* champ specifique */
	MOT			vres_niv1[5];			/* Champ reserve pour la couche 1 */
	MOT			vres_niv2[5];			/* Champ reserve pour la couche 2 */
	char        *pszResNiv2;
};

#define	SIZVOIE	sizeof(struct sdesvoie)	/* Taille du desvoie en octet */

/**/


		/* Le desmem */
		/* --------- */

struct	sdesmem
{
	MOT			midata;				/* index de la table de donnees dans le type */
	MOT		far	*pf_data;		/* Ptr far sur la page de donnees */
	MOT		far	*pf_image;		/* Ptr far sur la page image	  */
	MOT			mlongdata;			/* Taille de la page de donnees en mots */
	struct
	{
		unsigned	urg		:4;		/* priorite attribuee aux donnees */
		unsigned	typdata	:4;		/* Type de donnee */
		unsigned	ini		:1;		/* Donnees initialisees */
		unsigned	raf		:1;		/* Table image rafraichie */
		unsigned	sema		:1;		/* Semaphore d'acces aux donnees*/
		unsigned	com		:1;		/* Donnees de communication */
		unsigned	vid		:4;		/* Nombre de bits inutilises du dernier mot*/
	} mpar;
	struct
	{
		unsigned	xraf		:1;		/* Base image plusieurs fois rafraichie */
		unsigned	dext		:1;		/* Datation externe associee a la table */
		unsigned	reserve	:14;		/* Reserve */
	} para2;
	MOT			mcptmodify;			/* #MODIFDL 09/04/96 cpt de modifcation des donn�es */
	struct sdesmem near *pn_nraf;	/* pointeur sur la table rafraichie suivante */
	struct sdesmem near *pn_praf;	/* pointeur sur la table rafraichie precedente */
	struct sdatation	  raf_date; /* date de rafraichissement */
	MOT			midlien;				/* index du deslien de rafraichissement */
	MOT			miduser;				/* indentifiant utilisateur dans le type */
};

#define	SIZMEM	sizeof(struct sdesmem)	/* Taille du desmem en octet */

/**/

		/* Le despag */
		/* --------- */

struct	sdespag
{
	MOT			padrmemap;		/* adresse memoire dans l'ap */
	OCTET			ptypdon;			/* type de donnees pour le protocole */
	OCTET			pcodlig;			/* codage des donnees sur la ligne */
	struct
	{
	  unsigned	 par_lec  :1;	/*Lecture cpc autorisee */
	  unsigned	 par_lb	 :1;	/*Lecture cpc mode bloquant seulement */
	  unsigned	 par_ecr  :1;	/*Ecriture cpc autorisee */
	  unsigned	 par_aut  :1;	/*Autocadence defini*/
	  unsigned	 par_la	 :1;	/*Autocadence en lecture */
	  unsigned	 par_seq  :1;	/*Sequencement obligatoire */
	  unsigned	 par_vcad :1;	/*Autocadence autorise*/
	  unsigned	 par_aef  :1;	/*Autocadence en file d'attente*/
	  unsigned	 par_gaut :1;	/*Autocadence gere*/
	  unsigned	 par_val  :1;	/*Despag actif */
	  unsigned	 par_urg  :1;	/*Action prioritaire */
	  unsigned	 par_nxt  :1;	/*Chainage despag suivant valide*/
	  unsigned	 par_cad  :1;	/*Chainage autocad suivant valide*/
	  unsigned	 par_tlis :1;	/*Tete de liste de donnees regroupees*/
	  unsigned	 par_res  :2;	/*Reserve*/
	}	param;
	struct	sdesmem	near	*pn_desm1;		/* pointeur sur le desmem correspondant */
	struct	sdeslien near	*pn_desl1;		/* pointeur sur le deslien correspondant */
	struct	sdesap	near	*pn_desa1;		/* pointeur sur le desap correspondant */
	struct	sdespag	near	*pn_desp1;		/* pointeur sur le despag suivant pour le meme desap */
	struct	sdespag	near	*pn_desauto;	/* pointeur du desap autocadence suivant */
	MOT			pcadence;						/* cadence de traitement du despag	*/
	MOT			pcptauto;						/* compteur d'autocadencement       */
	MOT			perreur;							/* nbre d'erreurs pour ce despag    */
	struct
	{
	  unsigned	 defech	 :1;	/*defaut au cours du dernier echange */
	  unsigned	 reserve1 :2;	/* reserve */
	  unsigned	 erlign	 :1;	/* erreur de transmission */
	  unsigned	 erprot	 :1;	/* erreur de protocole */
	  unsigned	 erecup	 :1;	/* erreur signalee par le correspondant */
	  unsigned	 eres 	 :1;	/* erreur reseau */
	  unsigned	 erto 	 :1;	/* erreur time out */
	  unsigned	 fappli	 :1;	/* file d'appli pleine */
	  unsigned	 fauto	 :1;	/* file Autocadencee pleine */
	  unsigned	 fprio	 :1;	/* file prioritaire pleine */
	  unsigned	 reserve2 :1;	/* reserve */
	  unsigned	 execde	 :1;	/* derniere cde en cours de traitement */
	  unsigned	 reserve3 :1;	/* reserve */
	  unsigned	 aef		 :1;	/* echange autocadence reste en file */
	  unsigned	 reserve4 :1;	/* reserve */
	}	petat;
	MOT			petatcomp;						/* mot d'etat complementaire        */
	MOT			pnbcdeabort;					/* nombre de commandes abandonnees	*/
	MOT			preserv1;						/* champ reserve							*/
	OCTET			preserv2;						/* champ reserve							*/
	OCTET			paraspe;							/* parametres specifiques				*/
	MOT			pspecifiq;						/* champ specifique						*/
	MOT			pres_niv2[5];					/* Champ reserve pour la couche 2	*/
};

#define	SIZPAG	sizeof(struct sdespag)	/* Taille du despag en octet */

/**/

		/* Le desap */
		/* -------- */

struct	sdesap
{
	struct	sdespag	near	*pn_desp1;	/* pointeur sur 1ere despag pour cet ap */
	MOT		  anoap;							/* numero d'ap */
	struct
	{
		unsigned	ap_hs	 : 1;					/* AP HS */
		unsigned	ap_blq : 1;					/* AP occupe */
		unsigned	ap_dif : 1;					/* AP de diffusion */
		unsigned	ap_dr	 : 1;					/* delai de retournement actif */
		unsigned	ap_vact: 1;					/* equipement a activer */
		unsigned	ap_vcad: 1;					/* autocadence autorise */
		unsigned	ap_pag : 1;					/* despag declares */
		unsigned	ap_mod : 1;					/* desap modifiable */
		unsigned	ap_eri : 1;					/* erreur d'init de l'equipement */
		unsigned	ap_erf : 1;					/* erreur d'arret de l'equipement */
		unsigned	ap_def : 1;					/* derniere cde en defaut */
		unsigned	ap_val : 1;					/* equipement actif */
		unsigned	reserve: 4;					/* reserv� */
	} apara;
	OCTET			areserv1;					/* champ reserve */
	OCTET			atypap;						/* type de l'automate */
	MOT			atimout;						/* time out de l'echange */
	MOT			avaldr;						/* valeur du delai de retournement */
	MOT			acptdr;						/* compteur de delai de retournement */
	MOT			aerreur;						/* compteur d'erreur pour l'ap */
	MOT			aerligne;					/* compteur d'erreur de transmission */
	MOT			anbcdeabort;				/* compteur de cde abortee */
	MOT			anbauto;						/* nbre d'autocadence actif */
	MOT			aspecifiq;					/* champ specifique */
	OCTET			aparaspe;					/* parametre specifique */
	OCTET			anbdon;						/* nbre de desdon pour l'ap */
	struct	sdesdon	far	*pf_desd1;	/* pointeur du 1er desdon de l'ap */
	MOT			aroutage;					/* valeur de routage pour l'ap */
	MOT			ares_niv1[5];				/* champ reserve a la couche 1 */
	MOT			ares_niv2[5];				 /* champ reserve a la couche 2 */
};

#define	SIZAP	 sizeof(struct sdesap)	/* Taille du desap en octet */

/**/

		/* Le desdon */
		/* --------- */

struct	sdesdon
{
	OCTET			dtype;							/* type interne de donnees */
	OCTET			dpara;							/* parametre reserve */
	MOT			dadrdebut;						/* adresse de depart des datas vers l'exterieur */
	MOT			dadrfin; 						/* adresse de fin 										*/
	MOT			dnbpag;							/* nbre de despag concernes */
	struct		sdespag	near	*pn_desp1;	/* pointeur sur le 1er despag concerne */
	MOT			dreserve[3];					/* champ reserve */
};

#define	SIZDON	sizeof(struct sdesdon)	/* Taille du desdon en octet */

/**/
	/*=====================================================

			Description du contexte de commande associe
			aux echanges entre les couches 7 et 2.
			___________________________________________

	=======================================================*/


struct scxt 			/*CONTEXTE COURANT DE COMMANDE*/
{
	MOT	xcommande;					/*	Code de la commande	*/
	struct sdesap	near	*ptrap;	/*	Offset du desap  concerne */
	struct sdespag	near *ptrpag;	/*	Offset du despag concerne */
	struct sdesmem	near	*ptrmem;	/* Offset du desmem concerne */
	MOT	xnoap		;					/* Numero de l'AP */
	MOT	xtypap	;					/* Type d'AP*/
	MOT	xtimout	;					/* Time out pour l'echange*/
	MOT	xadrmemap;					/* Adresse dans la memoire de l'AP*/
	OCTET xcodlig	;					/* Codage des donnees sur la ligne*/
	MOT	xtypdon	;					/* Type logique pour le protocole specifique*/
	MOT	xrang		;					/* Rang de la 1ere information concernee*/
	MOT	xnbre		;					/* nombre d'informations concernees*/
	struct
	{
		unsigned	par_b : 1;		/* cde bloquante */
		unsigned	par_d : 1;		/* mode direct */
		unsigned	par_p : 1;		/* cde prioritaire */
		unsigned	par_r : 1;		/* cde de diffusion su le reseau */
		unsigned	par_s : 1;		/* cde avec sequencement obligatoire */
		unsigned	par_g : 1;		/* cde groupee  */
		unsigned	par_c : 1;		/* cde conditionnelle */
		unsigned	par_i : 1;		/* cde immediate */
	} xpara;
	MOT	xcycle;					/* provenance de la commande*/
	MOT	xnumfil	;				/* Num de la file d'origine de la commande*/
	MOT	xdisptst	;				/* Adr. fct de test de disponibilite du dest.*/
	MOT	xdispraz	;				/* Adr. fct de mise en indisponibilite du dest.*/
};


#define		SIZCXT	SIZE	SCXT

/**/

	/*==============================================================

		Description des messages echanges entre les couches
		___________________________________________________

	===============================================================*/


struct	smsg
{
	OCTET	m_source;			/* Emetteur du message */
	OCTET	m_dest;				/* Destinataire du message */
	MOT	m_cde;				/* Code de la commande */
	MOT	m_param1;			/* Parametre eventuel associe a la commande */
	MOT	m_param2;			/* Parametre eventuel associe a la commande */
	OCTET near *m_buf;		/* Adresse eventuelle d'un tampon (Offset) */
};

#define	SIZSMSG			SIZE	SMSG

/**/

	/*=======================================================

		Structure utilisee pour notifier une erreur
		au journal des incidents.
		____________________________________________

	=======================================================*/



struct	senr_jvoie
{
	struct sdatation jvdatation;	/*Datation de l'erreur*/
	OCTET	jv_nature;						/*Nature de l'erreur (config., com., interne)*/
	OCTET	jv_niveau;						/*Niveau caracterisant l'erreur (reseau, AP, echange, NON_SENS)*/
	MOT	jv_code	;						/*Code de l'erreur detectee*/
	MOT	jv_s_code1;						/*Sous-code eventuel definissant l'erreur*/
	MOT	jv_s_code2;						/*Sous-code eventuel definissant l'erreur*/
	MOT	jv_s_code3;						/*Sous-code eventuel definissant l'erreur*/
	MOT	jv_codesc;						/*Code du descripteur eventuel concerne par l'erreur*/
	void	near	*ptjvdesc;				/*Offset du descripteur concerne par l'erreur*/
	MOT	jv_codcde;						/*Type de commande concernee par l'erreur*/
};


#define	SIZSJVOIE		SIZE	SENR_JVOIE
/**/
		  /*======================================================*/
		  /*																		 */
		  /*		 Description du tampon utilise par la couche 2	 */
		  /*		 pour signifier une erreur a la couche 7. 		 */
		  /*		 _____________________________________________	 */
		  /*																		 */
		  /*======================================================*/


struct	sErrNiv7
{
	OCTET 	niveau;		/* Niveau caracterisant l'erreur (reseau, AP, echange, NON_SENS)*/
	OCTET 	phaserr; 	/* Phase associee a l'erreur (emission, reception, autre)       */
	MOT		code; 		/*	Code de l'erreur detectee                                    */
	MOT		s_code1; 	/* Sous-code eventuel definissant l'erreur                      */
	MOT		s_code2;		/* Sous-code eventuel definissant l'erreur                      */
	MOT		s_code3; 	/* Sous-code eventuel definissant l'erreur                      */
	// void near *ptrdesc;	/* Offset du descripteur concerne par l'erreur                  */
	MOT      ptrdesc;	/* Offset du descripteur concerne par l'erreur                  */
	MOT		codcde;		/* Type de commande concernee par l'erreur                      */
};

/**/


	/*=====================================================

		Description du tampon utilise par la couche 1
		pour signifier une erreur a la couche 2.
		_____________________________________________

	=======================================================*/


struct	sbuffer1_msg
{
	MOT	m_typerr;	/*Type de l'erreur*/
	MOT	m_coderr;	/*Code de l'erreur detectee*/
	MOT	m_phaserr;	/*Phase associee a l'erreur (emission, reception, autre)*/
};


			/*  Valeur prise par le champ M_TYPERR
				 ----------------------------------   */

/**	ERR_LIGN	1	;Erreur de transmission ( Cste deja definie )*/

#define	  ERR_RESEAU_LAC	2	/* Erreur sur le reseau LAC*/

/**/

	/*=======================================================

		Description du tampon de communication qui
		est transmis par la couche 2 a la couche 1.
		___________________________________________

	=======================================================*/


struct	sbuffer2_msg
{
	void near *m_desbuf_emi;		/*Offset du descripteur de tampon d'emission*/
	void near *m_desbuf_rcp;		/*Offset du descripteur de tampon de reception*/
	void ( near *m_fct_rcp )();	/*Offset de la fct. de reception de caractere*/
	MOT	m_emis_type;				/*Type de l'emission,caractere ou signal*/
	MOT	m_cde_timer;				/*Etat du timer de synchro. ou de calibrage*/
	MOT	m_valtim_emi;				/*Nombre d'unites de temps pour l'emission*/
	MOT	m_valtim_rcp;				/*Nombre d'unites de temps pour la reception*/
	MOT	m_valtim_wait;				/*Nombre d'unites de temps pour l'attente*/
	struct sdesap far *ptrdesap;	/* adresse du descripteur associe au correspondant */
	void far *m_ofs_rcvsi;				/* Adresse de la SI de reception du protocole */
	MOT	m_seg_prot;				/* Segment de donn�es du protocole */
};

/**/


	/*===============================================================

		Description des tampons utilises durant un echange
		__________________________________________________

	===============================================================*/


struct	sdesbuf
{
	OCTET far *ptrdon	;		/* adresse du tampon de donnees	 */
	MOT	blgmax	;			/* Longueur maximum du tampon*/
	MOT	bidmax	;			/* Butee des infos a traiter*/
	MOT	bidcou	;			/* Index courant dans le tampon*/
};

#define	SIZDESBUF	SIZE	SDESBUF

/**/

	/*=============================================================

		Contexte utilise durant la gestion des bases de donnees
		_______________________________________________________

	===============================================================*/


struct	sgdata
{
	struct sdesmem near	*ptrmem;	/*Offset du desmem concerne*/
	MOT	gappli_rang;				/*Rang dans la base de l'appli.*/
	MOT	gnbre;						/*Nbre d'infos ( bit / carac / mot / reel / ... )*/
	void (near *ptfctspe)();		/*Adr de la fct specifique de gestion de donnees*/
	MOT	gprot_rang;					/*Rang dans le tampon du protocole*/
	OCTET	far *ptrprot;				/*adresse  du tampon concerne*/
	struct
	{
		unsigned	par_don	: 1;		/* table de donnee concernee */
		unsigned	par_v_ap	: 1;		/* transfert d'info vers l'ap */
		unsigned	par_draf	: 1;		/* donnees rafraichies (var de travail)*/
		unsigned	par_datext : 2;	/* datation externe	*/
		unsigned	par_global : 1;	/* transfert global a effectuer par GERDON */
		unsigned	par_reserv : 1;	/* reservee  */
	} gpara;
	OCTET	gcodlig;						/*Codage des donnees sur la ligne*/
	struct sdatation	gdat;			/*date associee aux donnees protocole */
};

#ifdef __cplusplus
	}
#endif

#pragma pack()

