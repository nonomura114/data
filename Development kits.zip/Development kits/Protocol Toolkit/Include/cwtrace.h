
#ifndef _CWTRACE_H_

	#define _CWTRACE_H_

	extern char 			G_CwNamePipe[];
	extern _CriticalSection G_CwTraceCS;

	#define CWTRACE_LOCK	G_CwTraceCS.Lock();
	#define CWTRACE_UNLOCK	G_CwTraceCS.Unlock();

	#define SCR 	1  // envoi vers l'ecran
	#define FIL 	2  // envoi vers fichier
	#define IMP 	4  // envoi vers imprimante
	#define COM 	8  // envoi vers lep port de communication	 
	#define SEG 	16 // envoi vers un segment m�moire 
	#define COM1	32 // envoi vers lep port de communication	 
	#define COM2	64 // envoi vers lep port de communication	 
	
	// Define par d�faut du type de destination des traces de DEBUG
	#define CWDEST	SEG

	//
	// Define des gestionnaires CIMWAY
	//
	#define PUS_CW32		0x00000001
	#define PUS_CWTOOLS 	0x00000002
	#define PUS_CWIO		0x00000004
	#define PUS_FREE3		0x00000008
	#define PUS_FREE4		0x00000010
	#define PUS_FREE5		0x00000020
	#define PUS_FREE6		0x00000040
	#define PUS_CWINTF		0x00000080
	
	#define PUS_CWDRV		0x00000100
	#define PUS_CWDRVNG		0x00000200
	#define PUS_FREE10		0x00000400
	#define PUS_FREE11		0x00000800
	#define PUS_FREE12		0x00001000
	#define PUS_FREE13		0x00002000
	#define PUS_FREE14		0x00004000
	#define PUS_AUDIT		0x00008000
	
	#define PUS_PROTOC1		0x00010000
	#define PUS_PROTOC2		0x00020000
	#define PUS_PROTOC3		0x00040000
	#define PUS_PROTOC4		0x00080000
	#define PUS_PROTOC5		0x00100000
	#define PUS_PROTOC6		0x00200000
	#define PUS_PROTOC7		0x00400000
	#define PUS_PROTOC8		0x00800000
	
	#define PUS_USER1		0x01000000
	#define PUS_USER2		0x02000000
	#define PUS_USER3		0x04000000
	#define PUS_USER4		0x08000000
	#define PUS_USER5		0x10000000
	#define PUS_USER6		0x20000000
	#define PUS_USER7		0x40000000
	#define PUS_USER8		0x80000000
	

	//
	// Define des masques de trace pour le PUS_CW32
	//
	#define LVL_KRN 		0x00000001
	#define LVL_OBJ 		0x00000002
	#define LVL_TIMER		0x00000004
	#define LVL_API 		0x00000008
	#define LVL_INTF		0x00000010
	#define LVL_CMD 		0x00000020
	#define LVL_CMDLST		0x00000040
	#define LVL_CYCLIC 		0x00000080
	
	#define LVL_BRD 		0x00000100
	#define LVL_NET 		0x00000200
	#define LVL_EQT 		0x00000400
	#define LVL_FRM 		0x00000800
	#define LVL_DATA		0x00001000
	#define LVL_LINK		0x00002000
	#define LVL_ITEM		0x00004000
	#define LVL_FREE15		0x00008000
	
	#define LVL_BKBRD		0x00010000
	#define LVL_BKNET		0x00020000
	#define LVL_BKEQT		0x00040000
	#define LVL_BKFRM		0x00080000
	#define LVL_BKDATA		0x00100000
	#define LVL_BKLINK		0x00200000
	#define LVL_BKFREE22	0x00400000
	#define LVL_BKSERV		0x00800000
	
	#define LVL_WRITE		0x01000000
	#define LVL_READ		0x02000000
	#define LVL_BKFREE26	0x04000000
	#define LVL_BKFREE27	0x08000000
	#define LVL_BKFREE28	0x10000000
	#define LVL_BKFREE29	0x20000000
	#define LVL_BKFREE30	0x40000000
	#define LVL_BKFREE31	0x80000000


	//
	// Define des masques de trace pour le PUS_CWTOOLS
	//
	#define LVL_AD			0x00000001
	#define LVL_LNKLST		0x00000002
	#define LVL_TIMDAT		0x00000004
	#define LVL_CONV		0x00000008
	#define LVL_SYS 		0x00000010
	#define LVL_TRACE		0x00000020
	#define LVL_THREAD		0x00000040
	#define LVL_SYNC		0x00000080
	

	//
	// Define des masques de trace pour le PUS_CWIO
	//
	#define LVL_KRNL		0x00000001
	#define LVL_SER			0x00000002
	#define LVL_BKSER		0x00000004
	#define LVL_NGSER		0x00000008
	#define LVL_TCPIP		0x00000010
	#define LVL_TAPI		0x00000020
	

	//
	// Define des masques de trace pour PROTOC et USER
	//
	#define LVL_BIT0		0x0001
	#define LVL_BIT1		0x0002
	#define LVL_BIT2		0x0004
	#define LVL_BIT3		0x0008
	#define LVL_BIT4		0x0010
	#define LVL_BIT5		0x0020
	#define LVL_BIT6		0x0040
	#define LVL_BIT7		0x0080
	#define LVL_BIT8		0x0100
	#define LVL_BIT9		0x0200
	#define LVL_BIT10		0x0400
	#define LVL_BIT11		0x0800
	#define LVL_BIT12		0x1000
	#define LVL_BIT13		0x2000
	#define LVL_BIT14		0x4000
	#define LVL_BIT15		0x8000
	#define LVL_BIT16	   0x10000
	#define LVL_BIT17	   0x20000
	#define LVL_BIT18	   0x40000
	#define LVL_BIT19	   0x80000
	#define LVL_BIT20	  0x100000
	#define LVL_BIT21	  0x200000
	#define LVL_BIT22	  0x400000
	#define LVL_BIT23	  0x800000
	#define LVL_BIT24	 0x1000000
	#define LVL_BIT25	 0x2000000
	#define LVL_BIT26	 0x4000000
	#define LVL_BIT27	 0x8000000
	#define LVL_BIT28	0x10000000
	#define LVL_BIT29	0x20000000
	#define LVL_BIT30	0x40000000
	#define LVL_BIT31	0x80000000

	
	#ifndef BIT0
		#define BIT0		0x0001
		#define BIT1		0x0002
		#define BIT2		0x0004
		#define BIT3		0x0008
		#define BIT4		0x0010
		#define BIT5		0x0020
		#define BIT6		0x0040
		#define BIT7		0x0080
		#define BIT8		0x0100
		#define BIT9		0x0200
		#define BIT10		0x0400
		#define BIT11		0x0800
		#define BIT12		0x1000
		#define BIT13		0x2000
		#define BIT14		0x4000
		#define BIT15		0x8000
		#define BIT16	   0x10000
		#define BIT17	   0x20000
		#define BIT18	   0x40000
		#define BIT19	   0x80000
		#define BIT20	  0x100000
		#define BIT21	  0x200000
		#define BIT22	  0x400000
		#define BIT23	  0x800000
		#define BIT24	 0x1000000
		#define BIT25	 0x2000000
		#define BIT26	 0x4000000
		#define BIT27	 0x8000000
		#define BIT28	0x10000000
		#define BIT29	0x20000000
		#define BIT30	0x40000000
		#define BIT31	0x80000000
	#endif


	#ifdef CWDEBUG
		#define CWTRACE			Cw_Trace
		#define CWGETLASTERROR	Cw_GetLastError
		#define CWAUDIT			Cw_Audit
	#else
		#define CWTRACE			Cw_Trace
		#define CWGETLASTERROR	Cw_GetLastError
		#define CWAUDIT			Cw_Audit
	#endif


	CW_IMPORT_EXPORT void Cw_Trace( 		// Old version
		unsigned long, char *, ... );

	CW_IMPORT_EXPORT void Cw_NoTrace(		// Old version
		unsigned long, char *, ... );

	CW_IMPORT_EXPORT void Cw_Trace( 		// New version
		unsigned long, unsigned long, const char *, ... );

	CW_IMPORT_EXPORT void Cw_NoTrace(		// New version
		unsigned long, unsigned long, char *, ... );

	CW_IMPORT_EXPORT DWORD Cw_GetLastError(
		unsigned long, unsigned long, char *format, ...);
	
	CW_IMPORT_EXPORT void Cw_TraceSetMasq(
		unsigned long ulMasq);

	CW_IMPORT_EXPORT void Cw_TraceClearMasq(
		unsigned long ulMasq);

	CW_IMPORT_EXPORT void Cw_Audit(
		unsigned long, unsigned long, char *, ... );

	CW_IMPORT_EXPORT void Cw_Audit(
		unsigned long, unsigned long, char *, ... );

	CW_IMPORT_EXPORT CW_BOOL Cw_OpenNP(
		void);

	CW_IMPORT_EXPORT void Cw_WriteNP(
		char *BufferWrite);

	CW_IMPORT_EXPORT void Cw_ReadNP( 
		void);

	CW_IMPORT_EXPORT void RecordError(
		CW_ULONG ulError,
		CW_USHORT usLevel,
		CW_USHORT usDest,
		CW_LPC_CHAR pszParam1 = "",
		CW_LPC_CHAR pszParam2 = "");

	//#MODIFJS 25/03/98
	CW_IMPORT_EXPORT void DisplayLastError(
		void);

	CW_IMPORT_EXPORT void Cw_Trace_LastError(
		unsigned long ulPus, unsigned long ulFlag);

	//#MODIFJS 22/07/98
	void ResetTraceHandles( void);
	void CloseTraceHandles( CW_BOOL bFullStop);

#endif // _CWTRACE_H_
