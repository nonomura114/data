#pragma once

////////////////////////////////////////////////////////////////////////////////
// Interface pointer to the manager toolkit API

extern IAPIMgr* svmgrAPI;

//////////////////////////////////////////////////////////////////////////////
// Timer used to do the update task

class TimerElapsed
{
    int m_nMillisec;

public:
    TimerElapsed()
    {
    }

    void SetT(int nNewMillisec)
    {
        m_nMillisec = nNewMillisec;
    }

    void CallTimer()
    {
        svmgrAPI->SetTimer(m_nMillisec, 0);
    }
};

//////////////////////////////////////////////////////////////////////////////
// Class Variable

class Variable
{
protected:
    CString m_strVarName;       // Variable that will be read to after update
    CString m_strVarToUpdate;   // Variable that will be updated (could be the same that is in m_sVarName)

public:
    Variable()
    {
    }

    CString GetVarName()
    {
        return m_strVarName;
    }

    CString GetVarToUpdate()
    {
        return m_strVarToUpdate;
    }

    void VarRead(LPCSTR pszVarToRead, LPCSTR pszVarToUpdate);
    void OnReadCompleted(double dValue, _svmgrVarStatus status);
};
