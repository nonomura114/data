#include "stdafx.h"
#include "usrmgrRefreshDataImpl.h"
#include "svmgrDefaultImpl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

////////////////////////////////////////////////////////////////////////////////

#define QTY_VAR 10

TimerElapsed T1;
Variable g_VarsToRefresh[QTY_VAR];

// Following variables will be wrote each time to g_aszNameVarsToUpdate
LPCSTR g_aszVarsToRefresh[QTY_VAR] =
{
    "VARS.V1", "VARS.V2", "VARS.V3", "VARS.V4", "VARS.V5",
    "VARS.V6", "VARS.V7", "VARS.V8", "VARS.V9", "VARS.V10"
};

// To rest the write state to another variables
LPCSTR g_aszVarsToUpdate[QTY_VAR] =
{
    "VARS.V1_B", "VARS.V2_B", "VARS.V3_B", "VARS.V4_B", "VARS.V5_B",
    "VARS.V6_B", "VARS.V7_B", "VARS.V8_B", "VARS.V9_B", "VARS.V10_B"
};

////////////////////////////////////////////////////////////////
// Class Variable

void Variable::VarRead(LPCSTR pszVarToRead, LPCSTR pszVarToUpdate)
{
    svmgrAPI->VarRead(pszVarToRead, (ULONG)this);
    m_strVarName = pszVarToRead;
    m_strVarToUpdate = pszVarToUpdate;
}

void Variable::OnReadCompleted(double dValue, _svmgrVarStatus status)
{
    FILETIME ftNow;
    ::GetSystemTimeAsFileTime(&ftNow);

    _svmgrDataSet dataSet;
    dataSet.szVariableName = m_strVarToUpdate;
    VariantInit(&dataSet.vValue);
    V_VT(&dataSet.vValue) = VT_R8;              // Variable type: Real R8
    V_R8(&dataSet.vValue) = dValue;

    if (status.IsValidState() == TRUE)
        dataSet.qQuality = svmgrQuality_Good;
    else if (status.Status.State.bits.BadFormat)
        dataSet.qQuality = svmgrQuality_Bad_BadFormattingValue;
    else if (status.Status.State.bits.HighLimitExceeded)
        dataSet.qQuality = svmgrQuality_Bad_HighLimitExceeded;
    else if (status.Status.State.bits.LowLimitExceeded)
        dataSet.qQuality = svmgrQuality_Bad_LowLimitExceeded;
    else if (status.Status.State.bits.NonAccessible)
        dataSet.qQuality = svmgrQuality_Bad_CommunicationFailure;
    else 
        dataSet.qQuality = svmgrQuality_Bad;

    dataSet.ftTimestamp = ftNow;                // Set the new timestamp  

    BOOL bResult = svmgrAPI->SetDataSet(1, &dataSet, (ULONG)this);

    VariantClear(&dataSet.vValue);
}

////////////////////////////////////////////////////////////////////////////////
// Implementation of the ISVMgr interface

struct IUsrMgr : public ISVMgr
{
    void __stdcall StartProject()
    {
        // Default set, the first state of timer is 0, is necessary to set any value
        T1.SetT(20000);
        T1.CallTimer();

        // If the variable "VARS.TIMER" change, it is needed to be advised (Update the new value)
        svmgrAPI->VarAdvise("VARS.TIMER", 0);
    }

    BOOL __stdcall OnReadCompleted2(
        DWORD dwCount,
        ULONG* pulClientHandles,
        BOOL* pbResults,
        _svmgrVarValue2** pValues,
        FILETIME* pftTimestamps,
        _svmgrVarStatus* pStatus)
    {
        for (DWORD n = 0; n < dwCount; n++)
        {
            // Get the pointer to the variable that made the call
            Variable * pVar = (Variable *)pulClientHandles[n];
            _svmgrVarValue2 * pValue = pValues[n];
            _svmgrVarStatus   status = pStatus[n];
            // Call to the function that set up the variable, it is necessary to update the DataBase
            pVar->OnReadCompleted(pValue->dAna(), status);
        }

        return TRUE;
    }

    BOOL __stdcall OnDataChange2(
        DWORD dwCount,
        ULONG* pulClientHandles,
        BOOL* pbResults,
        _svmgrVarValue2** pValues,
        FILETIME* pftTimestamps,
        _svmgrVarStatus* pStatus)
    {
        for (DWORD n = 0; n < dwCount; n++)
        {
            _svmgrVarValue2 * pValue = pValues[n];

            if (pValue->dAna() > 0)
            {
                // We update the timer writed in SV
                T1.SetT((int)pValue->dAna());
                svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, "Timer updated to: %d millisec", (int)pValue->dAna());
                T1.CallTimer();
                svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, "Timer called");
            }
        }

        return TRUE;
    }

    void __stdcall OnTimerElapsed(ULONG ulClientHandle)
    {
        // Only ask the read variable, but doesn't have the value response. It is OnReadCompleted
        for (int k = 0; k < QTY_VAR; k++)
        {
            g_VarsToRefresh[k].VarRead (g_aszVarsToRefresh[k], g_aszVarsToUpdate[k]);
        }

        // New call to timer
        T1.CallTimer();
    }

};

////////////////////////////////////////////////////////////////////////////////
// The one and only IUsrMgr object instance

IUsrMgr theIUsrMgr;

////////////////////////////////////////////////////////////////////////////////
// Interface pointer to the manager toolkit API

IAPIMgr* svmgrAPI = NULL;

////////////////////////////////////////////////////////////////////////////////
// Exchanges the User DLL and manager toolkit interface pointers

HRESULT WINAPI svmgrExchangeInterface(LPVOID* ppvInterface, IAPIMgr* pSvAPI)
{
    *ppvInterface = &theIUsrMgr;
    svmgrAPI = pSvAPI;
    return S_OK;
}
