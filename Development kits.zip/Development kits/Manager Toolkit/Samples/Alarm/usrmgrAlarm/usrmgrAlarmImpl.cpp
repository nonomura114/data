#include "stdafx.h"
#include "usrmgrAlarm.h"
#include "usrmgrAlarmImpl.h"
#include "svmgrDefaultImpl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

////////////////////////////////////////////////////////////////////////////////
// Implementation of the ISVMgr interface

struct IUsrMgr : public ISVMgr
{
    void __stdcall StartProject()
    {
        ::StartProject();
    }

    void __stdcall StopProject()
    {
        ::StopProject();
    }

    void __stdcall OnSetAlarmAttribute(BOOL bResult, ULONG ulClientHandle)
    {
        ::OnSetAlarmAttribute(bResult, ulClientHandle);
    }

    BOOL __stdcall OnDataChange2(
        DWORD dwCount,
        ULONG* pulClientHandles,
        BOOL* pbResults,
        _svmgrVarValue2** pValues,
        FILETIME* pftTimestamps,
        _svmgrVarStatus* pStatus)
    {
        ::OnDataChange2(dwCount, pulClientHandles, pbResults, pValues, pftTimestamps, pStatus);
        return TRUE;
    }
};

////////////////////////////////////////////////////////////////////////////////
// The one and only IUsrMgr object instance

IUsrMgr theIUsrMgr;

////////////////////////////////////////////////////////////////////////////////
// Interface pointer to the manager toolkit API

IAPIMgr* svmgrAPI = NULL;

////////////////////////////////////////////////////////////////////////////////
// Exchanges the User DLL and manager toolkit interface pointers

HRESULT WINAPI svmgrExchangeInterface (LPVOID* ppvInterface, IAPIMgr* pSvAPI)
{
    *ppvInterface = &theIUsrMgr;
    svmgrAPI = pSvAPI;
    return S_OK;
}
