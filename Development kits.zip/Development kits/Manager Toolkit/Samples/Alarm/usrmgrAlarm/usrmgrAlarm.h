#pragma once

void StartProject();
void StopProject();
void OnSetAlarmAttribute(BOOL bResult, ULONG ulClientHandle);
void OnDataChange2(DWORD dwCount, ULONG* pulClientHandles, BOOL* pbResults, _svmgrVarValue2** pValues, FILETIME* pftTimestamps, _svmgrVarStatus* pStatus);

////////////////////////////////////////////////////////////////////////////////

class _Var: public CObject
{
    DECLARE_DYNAMIC(_Var)

protected:

    CString m_csVarName;

public:

    _Var(LPCTSTR lpszVarName): m_csVarName(lpszVarName) {}
    CString& GetName(void) { return m_csVarName; }
};

////////////////////////////////////////////////////////////////////////////////

class _AdvisedVar: public _Var
{
    DECLARE_DYNAMIC(_AdvisedVar)

public:

    _AdvisedVar(LPCTSTR lpszVarName): 
    _Var(lpszVarName) {}

    BOOL Advise(void);

    virtual void OnDataChange(BOOL bResult, _svmgrVarValue2* pValue, CTime& ctTimeStamp, _svmgrVarStatus status) = 0;
    virtual void OnBinaryExtentedAttributeChange(_svmgrExtBinaryAttributeValue uExtBinaryValue) {}
    virtual void OnStringExtentedAttributeChange(_svmgrExtStringAttributeIds eExtAttributeId, LPCSTR szExtAttributeValue) {}
};

////////////////////////////////////////////////////////////////////////////////

class _AdvisedAnaVar: public _AdvisedVar
{
    DECLARE_DYNAMIC(_AdvisedAnaVar)

    int m_AlarmLevel;

public:

    _AdvisedAnaVar(LPCTSTR lpszVarName) :
    _AdvisedVar( lpszVarName) { m_AlarmLevel = 0; }

    virtual void OnDataChange(BOOL bResult, _svmgrVarValue2* pValue, CTime& ctTimeStamp, _svmgrVarStatus status);
};
