#include "stdafx.h"
#include "usrmgrAlarm.h"
#include "usrmgrAlarmImpl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// Declaration of linked list variables used for the variables storage
CList <_AdvisedVar*, _AdvisedVar*> g_AdvisedVarList;
CList <_Var*, _Var*> g_VarList;

/*******************************************************************************
**
** function StartProject
**
** This function advise all variables configured to be advised by this user
** program. 
**
** We enumerate all the variables on the system and check the name of these
** variables and then advise them or not.
**
*******************************************************************************/
void StartProject()
{
    HANDLE hEnum;               // Handle of the enumerator.

    // First, we must create the enumerator.
    svmgrAPI->CreateVarEnum(hEnum);

    _svmgrVarEnum peVar[100];   // Buffer of enumerated variables
    ULONG ulNbVar;              // Number of enumerated variables
    BOOL bResult;               // if FALSE, no more variables to enumerate
    _AdvisedVar* pAvisedVar;

    do
    {
        // we ask for the next 100 variables
        bResult = svmgrAPI->VarEnum(hEnum, 100, peVar, &ulNbVar);

        // we check all the enumerated variables...
        for (ULONG ulCmpt = 0; ulCmpt < ulNbVar; ulCmpt++)
        {
            pAvisedVar = NULL;

            CString szName = peVar[ulCmpt].szName;
            szName.MakeUpper();

            if (szName == "SYS.BLK.ALARMLEVEL")
            {
                pAvisedVar = new _AdvisedAnaVar(peVar[ulCmpt].szName);
            }
            else if (_stricmp(peVar[ulCmpt].szAttrib[0], "Alarm") == 0)
            {
                _Var* pVar = new _Var(peVar[ulCmpt].szName);
                g_VarList.AddTail(pVar);
            }

            if (pAvisedVar)
            {
                // We declare an _AdvisedVar object to buffer this advise. This address of this object
                // is passed as a client handle in the function svmgrVarAdvise'

                // We advise this variable
                if (!pAvisedVar->Advise())
                {
                    // if the advise failed, we discard it.
                    delete pAvisedVar;
                }
            }
        }

        // Before asking the next 100 variables or quit the loop, we must clear the memory used for the current enum.
        svmgrAPI->ClearVarEnum(ulNbVar, peVar);
    }
    // continue while bResult is different from FALSE,
    // meaning that there are no more variables to enumerate
    while (bResult);

    // Last, we must destroy the enumerator.
    svmgrAPI->CloseVarEnum(hEnum);
}

/*******************************************************************************
**
** function StopProject
**
** This function stop the advises on all advised variables.
**
*******************************************************************************/
void StopProject()
{
    while (!g_AdvisedVarList.IsEmpty())
    {
        _AdvisedVar* pVar = g_AdvisedVarList.RemoveHead();

        svmgrAPI->VarUnadvise(pVar->GetName().GetBuffer(0), (ULONG)pVar);
        delete pVar;
    }

    g_VarList.RemoveAll();
}

/*******************************************************************************
**
** class _Var
**
** Basic class for variables storage.
**
*******************************************************************************/
IMPLEMENT_DYNAMIC(_Var, CObject)

/*******************************************************************************
**
** class _AdvisedVar
**
** derived from _Var
**
** Class for advised variables storage.
**
*******************************************************************************/
IMPLEMENT_DYNAMIC(_AdvisedVar, _Var)

/*******************************************************************************
**
** method Advise
**
** Advise a variable and buffer the command.
**
*******************************************************************************/
BOOL _AdvisedVar::Advise(void)
{
    // We advise this variable with function IAPIMgr::VarAdvise 
    // Note we use the 'this' as client handle in the advise function
    if (!svmgrAPI->VarAdvise(m_csVarName, (ULONG)this))
        return FALSE;

    // If the advise succeeded, we add it in the linked list containing all the advises.
    g_AdvisedVarList.AddTail(this);

    return TRUE;
}

/*******************************************************************************
**
** class _AdvisedAnaVar
**
** derived from _AdvisedVar
**
** Class for write in frame buffer.
**
*******************************************************************************/
IMPLEMENT_DYNAMIC(_AdvisedAnaVar, _AdvisedVar)

/*******************************************************************************
**
** method OnDataChange
**
** If the parameter is TRUE, the command has succeeded, else failed.
**
*******************************************************************************/
void _AdvisedAnaVar::OnDataChange(BOOL bResult, _svmgrVarValue2* pValue, CTime& ctTimeStamp, _svmgrVarStatus status)
{
    if (bResult)
    {
        switch (pValue->vt)
        {
            case svmgr_vtANA:
            // analogic value
            if (status.IsValidState())
            {
                m_AlarmLevel = (int)pValue->dAna();

                if (m_AlarmLevel < 0 || m_AlarmLevel > 29)
                {
                    svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, "SetAlarmLevel out of order %d", m_AlarmLevel);
                    return;
                }

                svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, "SetAlarmLevel %d", m_AlarmLevel);

                POSITION pos = g_VarList.GetHeadPosition();
                while (pos != NULL)
                {
                    _Var* pVar = g_VarList.GetNext(pos);

                    svmgrAPI->SetAlarmAttribute(
                        pVar->GetName(),
                        svmgrAlarmAttribute_AlarmLevel,
                        m_AlarmLevel,
                        (ULONG)pVar);

                    svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, "SetAlarmLevel %s", pVar->GetName());
                }
            }
            break;

            default :
            svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, "_AdvisedAnaVar::OnDataChange %s Only anologic variable is treated", GetName());
        }
    }
}

/*******************************************************************************
**
** function OnDataChange2
**
** The blank manager signals that varaible has changed value.
**
*******************************************************************************/
void OnDataChange2(
    DWORD dwCount,
    ULONG* pulClientHandles,
    BOOL* pbResults,
    _svmgrVarValue2** pValues,
    FILETIME* pftTimestamps,
    _svmgrVarStatus* pStatus)
{
    for (DWORD dwCmpt = 0; dwCmpt < dwCount; dwCmpt++)
    {
        _AdvisedVar* pVar = (_AdvisedVar*)pulClientHandles[dwCmpt];
        CTime ctTimeStamp(pftTimestamps[dwCmpt]);
        BOOL bResult = pbResults[dwCmpt];
        _svmgrVarValue2* pVarValue = pValues[dwCmpt];
        _svmgrVarStatus status = pStatus[dwCmpt];
        pVar->OnDataChange(bResult, pVarValue, ctTimeStamp, status);
    }
}

/*******************************************************************************
**
** function OnSetAlarmAttribute
**
** The blank manager signals that Attribute (Alarm) has changed value.
**
*******************************************************************************/
void OnSetAlarmAttribute(BOOL bResult, ULONG ulClientHandle)
{
    _Var* pVar = (_Var*)ulClientHandle;

    if (bResult)
        svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, "OnSetAlarmAttribute OK %s", pVar->GetName());
    else
        svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, "OnSetAlarmAttribute Error %s", pVar->GetName());
}
