#include "stdafx.h"
#include "SvObjects.h"

////////////////////////////////////////////////////////////////////////////////
// _Var

_Var::_Var(LPCTSTR pszName)
{
    m_strName = pszName;
}

_Var::~_Var()
{
    Unadvise();
}

void _Var::Advise()
{
    svmgrAPI->VarAdvise(m_strName, (ULONG)this);
}

void _Var::Unadvise()
{
    svmgrAPI->VarUnadvise(m_strName, (ULONG)this);
}

////////////////////////////////////////////////////////////////////////////////
// _VarAdvised

_VarAdvised::_VarAdvised(LPCTSTR pszName) : _Var(pszName)
{
    Advise();
}

_VarAdvised::~_VarAdvised()
{

}

void _VarAdvised::OnChange(_svmgrVarValue2* pVarValue, _svmgrVarStatus varStatus)
{
    if (varStatus.IsValidState())
    {
        switch (pVarValue->vt)
        {
        case svmgr_vtLOG:
        case svmgr_vtALARM:
            m_strValue = pVarValue->bLog() ? _T("1") : _T("0");
            break;
        case svmgr_vtANA:
            m_strValue.Format(_T("%f"), pVarValue->dAna());
            break;
        case svmgr_vtTXT:
            m_strValue.Format(_T("'%s'"), pVarValue->szTxt());
            break;
        default:
            m_strValue = _T("NULL");
            break;
        }
    }
    else
    {
        m_strValue = _T("NULL");
    }
}

////////////////////////////////////////////////////////////////////////////////
// _VarTrigger

_VarTrigger::_VarTrigger(LPCTSTR pszName, _Group* pGroup) : _Var(pszName)
{
    m_pGroup = pGroup;
    Advise();
}

_VarTrigger::~_VarTrigger()
{
}

void _VarTrigger::OnChange(_svmgrVarValue2* pVarValue, _svmgrVarStatus varStatus)
{
    if (pVarValue->bLog())
    {
        m_pGroup->OnTriggerVariable(this);
    }
}

////////////////////////////////////////////////////////////////////////////////
// _Group

_Group::_Group(LPCTSTR pszName, LPCTSTR pszCnx, LPCTSTR pszTableName, LPCTSTR pszReadTriggerVarName, LPCTSTR pszWriteTriggerVarName, int iPeriod, int iUseUtc)
{
    m_strName = pszName;
    m_strDbConnectCnx = pszCnx;
    m_strTableName = pszTableName;
    m_iTimerPeriodSec = iPeriod;
    m_bUseUTC = iUseUtc == 0 ? false : true;
    m_strReadTriggerVarName = pszReadTriggerVarName;
    m_strWriteTriggerVarName = pszWriteTriggerVarName;
}

_Group::~_Group()
{
    svmgrAPI->SqlConnectionStop(m_strDbConnectCnx);

    if (m_pVarTriggerRead)
        delete m_pVarTriggerRead;

    if (m_pVarTriggerWrite)
        delete m_pVarTriggerWrite;

    for (std::map<_VarAdvised*, CString>::iterator it = mapVariables.begin(); it != mapVariables.end(); it++)
    {
        _VarAdvised* pVarAdvised = (*it).first;
        delete pVarAdvised;
    }
}

ULONG _Group::GetTimerPeriod()
{
    return (ULONG)1000 * m_iTimerPeriodSec;
}

void _Group::AddVariable(CString strVarName, CString strColumnName)
{
    strColumnName.Replace(_T("."), _T("_"));
    mapVariables[new _VarAdvised(strVarName)] = strColumnName;
}

void _Group::Init()
{
    // Startup is synchronous => DBConnect must be ready when StartProject event is fired.
    PrepareTables();
    StartAcquisition();
}

void _Group::PrepareTables()
{
    if (!svmgrAPI->SqlConnectionStart(m_strDbConnectCnx))
    {
        svmgrAPI->LogMessage(SVMGR_LVL_WARNING, SVMGR_DEST_VIEWER, _T("[DB Connect] %s ERROR Start Connection '%s'"), m_strName, m_strDbConnectCnx);
        return;
    }

    CString strSQLRequest;
    CString strColumnsCreate;
    CString strColumnsAlter;

    // Generate SQL script for Columns creation
    for (std::map<_VarAdvised*, CString>::iterator it = mapVariables.begin(); it != mapVariables.end(); it++)
    {
        CString strCol = (*it).second;
        strColumnsCreate += _T(",") + strCol + _T(" nvarchar(255) ");
    }

    // Generate SQL script for Table creation
    strSQLRequest.Format(_T("CREATE TABLE %s (TS datetime not null %s)"), m_strTableName, strColumnsCreate);

    // If table already exists => SQL will send an error
    BOOL bOK = svmgrAPI->SqlCmdExecuteNonQuery((ULONG)this, m_strDbConnectCnx, strSQLRequest);

    if (bOK)
    {
        svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER, _T("[%s] Table Creation Request: %s "), m_strName, strSQLRequest);

        svmgrAPI->Trace(SVMGR_FLAG_BIT1, _T("[%s] Init: Send NonQuery '%s'"), m_strName, m_strDbConnectCnx);
        svmgrAPI->Trace(SVMGR_FLAG_BIT1, _T("[%s] Init: Request: %s"), m_strName, strSQLRequest);
    }
    else
    {
        svmgrAPI->LogMessage(SVMGR_LVL_WARNING, SVMGR_DEST_VIEWER, _T("[%s] Unable to send Request for creating table to '%s'"), m_strName, m_strDbConnectCnx);
    }
}

void _Group::StartAcquisition()
{
    // Start Timer if a period exists
    if (m_iTimerPeriodSec > 0)
    {
        ULONG ulPeriod = 1000 * m_iTimerPeriodSec;;
        
        // In order to be synchronized with system timestamp
        if (60 % m_iTimerPeriodSec == 0)
        {
            int iSecToAdd;
            SYSTEMTIME st;
            GetSystemTime(&st);
            iSecToAdd = m_iTimerPeriodSec - (st.wSecond - (st.wSecond / m_iTimerPeriodSec) * m_iTimerPeriodSec);
            ulPeriod = 1000 * (m_iTimerPeriodSec + iSecToAdd);
        }

        // Start Timer with synchronisation offset
        svmgrAPI->SetTimer(ulPeriod, (ULONG)this);
        svmgrAPI->Trace(SVMGR_FLAG_BIT2, _T("[%s] Init: Start Timer Period=%ds"), m_strName, m_iTimerPeriodSec);
    }

    // Start Trigger variable if exists
    if (!m_strReadTriggerVarName.IsEmpty())
    {
        svmgrAPI->Trace(SVMGR_FLAG_BIT2, _T("[%s] Init: Trigger Subscription for reading (%s)"), m_strName, m_strReadTriggerVarName);
        m_pVarTriggerRead = new _VarTrigger(m_strReadTriggerVarName, this);
    }

    if (!m_strWriteTriggerVarName.IsEmpty())
    {
        svmgrAPI->Trace(SVMGR_FLAG_BIT2, _T("[%s] Init: Trigger Subscription for writing (%s)"), m_strName, m_strWriteTriggerVarName);
        m_pVarTriggerWrite = new _VarTrigger(m_strWriteTriggerVarName, this);
    }
}

void _Group::OnTriggerVariable(_VarTrigger* pVarTrigger)
{
    if (pVarTrigger == m_pVarTriggerRead)
    {
        DbRead();
    }
    else if (pVarTrigger == m_pVarTriggerWrite)
    {
        DbWrite();
    }
}

void _Group::OnTimer()
{
    DbWrite();
}

void _Group::OnSqlCmdExecuteNonQueryCompleted(BOOL bResult, LPCTSTR pszErrorMsg, _svmgrSqlCmdExecuteNonQueryResult* pResult)
{
    if (bResult == FALSE)
    {
        svmgrAPI->LogMessage(SVMGR_LVL_WARNING, SVMGR_DEST_VIEWER, _T("[%s] NonQuery Callback ERROR: %s"), m_strName, pszErrorMsg);
    }
    else if (pResult->cmdStatus != svmgrSqlCmdStatus_Success)
    {
        svmgrAPI->LogMessage(SVMGR_LVL_WARNING, SVMGR_DEST_VIEWER, _T("[%s] NonQuery Callback UNSUCCESS: Status=%d Error: %s"), m_strName, (pResult->cmdStatus), pszErrorMsg );
    }
    else
    {
        svmgrAPI->Trace(SVMGR_FLAG_BIT0, _T("[%s] NonQuery Succeeded. Response: %d"), m_strName, pResult->iValue);
    }
}

void _Group::OnSqlCmdExecuteDataReaderCompleted(BOOL bResult, LPCTSTR pszErrorMsg, _svmgrSqlCmdExecuteDataReaderResult* pResult)
{
    if (bResult == FALSE)
    {
        svmgrAPI->LogMessage(SVMGR_LVL_WARNING, SVMGR_DEST_VIEWER, _T("[%s] DataReader Callback ERROR: %s"), m_strName, pszErrorMsg);
    }
    else if (pResult->cmdStatus != svmgrSqlCmdStatus_Success)
    {
        svmgrAPI->LogMessage(SVMGR_LVL_WARNING, SVMGR_DEST_VIEWER, _T("[%s] DataReader Callback UNSUCCESS: Status=%d Error: %s"), m_strName, (pResult->cmdStatus), pszErrorMsg);
    }
    else
    {
        CString strMessage;

        for (ULONG ul = 0; ul < pResult->ulFieldCount; ul++)
        {
            CString strData = _Tools::StringFromVariant(pResult->ppValues[pResult->ulRowCount - 1][ul]);

            if (ul == 0)
                strMessage.Format(_T("%s"), strData);
            else
                strMessage.Format(_T("%s,%s"), strMessage, strData);
        }

        svmgrAPI->LogMessage(SVMGR_LVL_INFO, SVMGR_DEST_VIEWER,  _T("[%s] DataReader Succeeded. %d Rows, %d Fields"), m_strName, pResult->ulRowCount, pResult->ulFieldCount);
        svmgrAPI->Trace(SVMGR_FLAG_BIT1, _T("[%s] DataReader (last data) :  %s"), m_strName, strMessage);
    }
}

void _Group::DbWrite()
{
    CString strSQLRequest;
    CString strColumnsInsert(_T("TS , "));
    CString strColumnsValues;

    SYSTEMTIME stUtc, stLoc;
    GetSystemTime(&stUtc);
    SystemTimeToTzSpecificLocalTime(NULL, &stUtc, &stLoc);

    if (m_bUseUTC)
        strColumnsValues.Format(_T("'%d-%.2d-%.2d %.2d:%.2d:%.2d' , "), stUtc.wYear, stUtc.wMonth, stUtc.wDay, stUtc.wHour, stUtc.wMinute, stUtc.wSecond);
    else
        strColumnsValues.Format(_T("'%d-%.2d-%.2d %.2d:%.2d:%.2d' , "), stLoc.wYear, stLoc.wMonth, stLoc.wDay, stLoc.wHour, stLoc.wMinute, stLoc.wSecond);

    for (std::map<_VarAdvised*, CString>::iterator it = mapVariables.begin(); it != mapVariables.end(); it++)
    {
        _VarAdvised* pVarAdvised = (*it).first;
        CString strCol = (*it).second;

        strColumnsInsert += strCol + _T(",");
        strColumnsValues += pVarAdvised->m_strValue + _T(",");
    }

    strColumnsInsert.TrimRight(',');
    strColumnsValues.TrimRight(',');

    strSQLRequest.Format(_T("INSERT INTO %s (%s) VALUES (%s)"), m_strTableName, strColumnsInsert, strColumnsValues);
    svmgrAPI->SqlCmdExecuteNonQuery((ULONG)this, m_strDbConnectCnx, strSQLRequest);

    svmgrAPI->Trace(SVMGR_FLAG_BIT1, _T("[%s] Send NonQuery Request: %s"), m_strName, strSQLRequest);
}

void _Group::DbRead()
{
    CString strSQLRequest;
    strSQLRequest.Format(_T("SELECT * FROM %s"), m_strTableName);

    svmgrAPI->SqlCmdExecuteDataReader((ULONG)this + 1, m_strDbConnectCnx, strSQLRequest);
    svmgrAPI->Trace(SVMGR_FLAG_BIT1, _T("[%s] Send DataReader Request: %s"), m_strName, strSQLRequest);
}

////////////////////////////////////////////////////////////////////////////////
// _Tools

CString _Tools::StringFromVariant(const VARIANT& vr)
{
    CString str;

    if (vr.vt == VT_NULL)
    {
        str = _T("<NULL>");
    }
    else if (vr.vt == VT_BOOL)
    {
        str = vr.boolVal == VARIANT_TRUE ? _T("1") : _T("0");
    }
    else
    {
        VARIANT vTemp;
        VariantInit(&vTemp);
        VariantChangeType(&vTemp, &vr, 0, VT_BSTR);
        str = (CString)vTemp.bstrVal;
        VariantClear(&vTemp);
    }

    return str;
}

std::vector<CString> _Tools::Split(const CString& str, LPCTSTR pszDelimiter)
{
    int iStart = 0;
    int iPos = str.Find(pszDelimiter, iStart);

    std::vector<CString> v;

    while (iPos >= 0)
    {
        if (iPos > 0)
            v.push_back(str.Mid(iStart, iPos - iStart));
        iStart = iPos + 1;
        iPos = str.Find(pszDelimiter, iStart);
    }
    v.push_back(str.Mid(iStart));

    return v;
}
