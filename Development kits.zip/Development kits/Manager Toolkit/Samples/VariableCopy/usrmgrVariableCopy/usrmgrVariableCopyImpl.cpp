#include "stdafx.h"
#include "usrmgrVariableCopyImpl.h"
#include "svmgrDefaultImpl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

////////////////////////////////////////////////////////////////////////////////

class CAdvisedVar : public CObject
{
    DECLARE_DYNAMIC(CAdvisedVar)

    CString m_strAdviseChange;
    CString m_strVarToChange;

public:

    CAdvisedVar(LPCSTR pszAdviseChange, LPCSTR pszVarToChange)
    {
        // pszAdviseChange: Name of the variable to read
        // pszVarToChange:  Name of the variable to write with the value of the read variable

        m_strAdviseChange = pszAdviseChange;
        m_strVarToChange = pszVarToChange;

        // Inside the constructor we advise the variable
        // Is not necessary does it here, you could call this function in another function

        svmgrAPI->VarAdvise(pszAdviseChange, (ULONG)this);
    }

    CString NameVar()
    {
        return m_strAdviseChange;
    }

    CString VarToChange()
    {
        return m_strVarToChange;
    }
};

IMPLEMENT_DYNAMIC(CAdvisedVar, CObject)

CAdvisedVar * g_pVar1 = NULL;

////////////////////////////////////////////////////////////////////////////////
// Implementation of the ISVMgr interface

struct IUsrMgr : public ISVMgr
{
    void __stdcall StartProject()
    {
        g_pVar1 = new CAdvisedVar("VARS.V1", "VARS.V2");
    }

    void __stdcall StopProject()
    {
        svmgrAPI->VarUnadvise(g_pVar1->NameVar(), (ULONG)g_pVar1);
        delete g_pVar1;
    }

    BOOL __stdcall OnDataChange2(
        DWORD dwCount,
        ULONG* pulClientHandles,
        BOOL* pbResults,
        _svmgrVarValue2** pValues,
        FILETIME* pftTimestamps,
        _svmgrVarStatus* pStatus)
    {
        for (DWORD n = 0; n < dwCount; n++)
        {
            CAdvisedVar* pVar = (CAdvisedVar*)pulClientHandles[n];
            _svmgrVarValue2* pValue = pValues[n];

            if (!pVar->VarToChange().IsEmpty()) // Do nothing if the variable name to write is empty
                svmgrAPI->AnaVarWrite(pVar->VarToChange(), pValue->dAna(), 0);
        }

        return TRUE;
    }
};

////////////////////////////////////////////////////////////////////////////////
// The one and only IUsrMgr object instance

IUsrMgr theIUsrMgr;

////////////////////////////////////////////////////////////////////////////////
// Interface pointer to the manager toolkit API

IAPIMgr* svmgrAPI = NULL;

////////////////////////////////////////////////////////////////////////////////
// Exchanges the User DLL and manager toolkit interface pointers

HRESULT WINAPI svmgrExchangeInterface(LPVOID* ppvInterface, IAPIMgr* pSvAPI)
{
    *ppvInterface = &theIUsrMgr;
    svmgrAPI = pSvAPI;
    return S_OK;
}
