# BarcodeReader Sample
![BarcodeReaderSample_image1](https://user-images.githubusercontent.com/45218829/90317915-94d78800-df67-11ea-9d15-80aedcc9213f.png)
